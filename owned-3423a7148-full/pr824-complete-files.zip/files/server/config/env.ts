import { z } from "zod";
import {
  resolveXiaozeLlmConfig,
  type ResolvedXiaozeLlmConfig
} from "./xiaozeLlmConfig";

const rawEnvSchema = z.object({
  NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
  HOST: z.string().min(1).default("127.0.0.1"),
  PORT: z.coerce.number().int().positive().default(8787),
  AUTH_MODE: z.enum(["development", "production"]).default("development"),
  AUTH_PROVIDER: z.enum(["hmac", "oidc", "local"]).default("local"),
  AUTH_TOKEN_ISSUER: z.string().optional(),
  AUTH_TOKEN_HMAC_SECRET: z.string().optional(),
  AUTH_OIDC_ISSUER: z.string().optional(),
  AUTH_OIDC_AUDIENCE: z.string().optional(),
  AUTH_OIDC_JWKS_URI: z.string().optional(),
  AUTH_LOCAL_SELF_REGISTER: z
    .enum(["true", "false"])
    .default("true")
    .transform((value) => value === "true"),
  AUTH_LOCAL_AUTH_MAX_ATTEMPTS: z.coerce.number().int().positive().default(10),
  AUTH_LOCAL_AUTH_WINDOW_MS: z.coerce.number().int().positive().default(60_000),
  DATABASE_URL: z.string().optional(),
  CATALOG_GOVERNANCE_DATABASE_URL: z.string().optional(),
  OBJECT_STORE_MODE: z.enum(["local", "s3"]).default("local"),
  OBJECT_STORE_ROOT: z.string().default(".wiseeff-object-store"),
  OBJECT_STORAGE_ENDPOINT: z.string().optional(),
  OBJECT_STORAGE_BUCKET: z.string().optional(),
  OBJECT_STORAGE_ACCESS_KEY_ID: z.string().optional(),
  OBJECT_STORAGE_SECRET_ACCESS_KEY: z.string().optional(),
  OBJECT_STORAGE_REGION: z.string().optional(),
  DEBUG_DEVICE_GATEWAY_MODE: z.enum(["simulator", "hdc", "adb", "multi"]).default("multi"),
  HDC_TIMEOUT_MS: z.coerce.number().int().positive().default(5000),
  ADB_TIMEOUT_MS: z.coerce.number().int().positive().default(5000),
  DEVICE_GATEWAY_ALLOW_SIMULATOR_IN_PRODUCTION: z
    .enum(["true", "false"])
    .default("false")
    .transform((value) => value === "true"),
  AGENT_API_TIMEOUT_MS: z.coerce.number().int().positive().default(5000),
  EMBEDDING_API_BASE_URL: z.string().optional(),
  EMBEDDING_MODEL: z.string().optional(),
  EMBEDDING_API_KEY: z.string().optional(),
  EMBEDDING_API_TIMEOUT_MS: z.coerce.number().int().positive().default(10000),
  KNOWLEDGE_INDEX_WORKER_ENABLED: z
    .enum(["true", "false"])
    .default("true")
    .transform((value) => value === "true"),
  LOG_WORKER_ENABLED: z
    .enum(["true", "false"])
    .default("true")
    .transform((value) => value === "true"),
  LOG_ANALYSIS_API_BASE_URL: z.string().optional(),
  LOG_ANALYSIS_MODEL: z.string().optional(),
  LOG_ANALYSIS_API_KEY: z.string().optional(),
  LOG_ANALYSIS_API_TIMEOUT_MS: z.coerce.number().int().positive().default(30_000),
  LOG_ANALYSIS_TOKEN_BUDGET: z.coerce.number().int().positive().default(8000),
  LOG_ANALYSIS_DETERMINISTIC: z
    .enum(["true", "false"])
    .default("false")
    .transform((value) => value === "true"),
  LOG_ANALYSIS_KERNEL: z.enum(["loop", "single-shot"]).default("loop"),
  LOG_ANALYSIS_MAX_STEPS: z.coerce.number().int().positive().default(6),
  LOG_ANALYSIS_JUDGE_API_BASE_URL: z.string().optional(),
  LOG_ANALYSIS_JUDGE_MODEL: z.string().optional(),
  LOG_ANALYSIS_JUDGE_API_KEY: z.string().optional(),
  LOG_ANALYSIS_JUDGE_API_TIMEOUT_MS: z.coerce.number().int().positive().default(30_000),
  LOG_ANALYSIS_JUDGE_SAMPLE_RATE: z.coerce.number().min(0).max(1).default(0.2),
  LOG_WEBHOOK_TIMEOUT_MS: z.coerce.number().int().positive().default(5000),
  LOG_WEBHOOK_MAX_ATTEMPTS: z.coerce.number().int().positive().default(3),
  LOG_WEBHOOK_RETRY_BASE_DELAY_MS: z.coerce.number().int().positive().default(1000),
  LOG_WEBHOOK_ALLOW_INSECURE_LOCAL: z
    .enum(["true", "false"])
    .default("false")
    .transform((value) => value === "true"),
  LOG_WEBHOOK_DELIVERY_RETENTION_ENABLED: z
    .enum(["true", "false"])
    .default("true")
    .transform((value) => value === "true"),
  LOG_WEBHOOK_DELIVERY_RETENTION_PER_DOMAIN: z.coerce.number().int().min(1).max(1_000_000).default(10_000),
  LOG_ANALYSIS_QUEUE_MODE: z.enum(["polling", "durable"]).default("polling"),
  REDIS_URL: z.string().optional(),
  LOG_ANALYSIS_QUEUE_PREFIX: z.string().default("wiseeff"),
  LOG_ANALYSIS_QUEUE_ATTEMPTS: z.coerce.number().int().positive().default(4),
  LOG_ANALYSIS_QUEUE_BACKOFF_MS: z.coerce.number().int().positive().default(1000),
  LOG_ANALYSIS_QUEUE_CONCURRENCY: z.coerce.number().int().positive().default(1),
  NOTIFICATION_WORKER_ENABLED: z
    .enum(["true", "false"])
    .default("true")
    .transform((value) => value === "true"),
  NOTIFICATION_DELIVERY_MODE: z.enum(["sync", "async"]).default("sync"),
  NOTIFICATION_QUEUE_MODE: z.enum(["polling", "durable"]).default("polling"),
  NOTIFICATION_QUEUE_PREFIX: z.string().default("wiseeff"),
  NOTIFICATION_QUEUE_ATTEMPTS: z.coerce.number().int().positive().default(4),
  NOTIFICATION_QUEUE_BACKOFF_MS: z.coerce.number().int().positive().default(1000),
  NOTIFICATION_QUEUE_CONCURRENCY: z.coerce.number().int().positive().default(1),
  DEVICE_BRIDGE_ARTIFACT_ROOT: z.string().default("ops/self-hosted/bridge-artifacts"),
  DEVICE_BRIDGE_TOOL_ARTIFACT_ROOT: z.string().default("ops/self-hosted/bridge-tool-artifacts"),
  DEVICE_BRIDGE_PAIRING_TTL_SECONDS: z.coerce.number().int().positive().default(1800),
  DEVICE_BRIDGE_TOKEN_TTL_DAYS: z.coerce.number().int().positive().default(90),
  DEVICE_BRIDGE_WS_PATH: z.string().default("/api/v1/device-bridges/ws"),
  XIAOZE_PROACTIVE_ENABLED: z
    .enum(["true", "false"])
    .default("false")
    .transform((value) => value === "true"),
  XIAOZE_REASONING_FALLBACK_HEURISTIC: z
    .enum(["true", "false"])
    .default("false")
    .transform((value) => value === "true"),
  XIAOZE_CHECKPOINTER: z.enum(["memory", "postgres"]).default("memory")
});

type ParsedServerEnv = z.infer<typeof rawEnvSchema>;

export type ServerEnv = ParsedServerEnv & {
  XIAOZE_LLM_CONFIG: ResolvedXiaozeLlmConfig;
};

export function loadServerEnv(raw: NodeJS.ProcessEnv): ServerEnv {
  const env = rawEnvSchema.parse(raw);
  const xiaozeLlmConfig = resolveXiaozeLlmConfig(raw);

  if (env.NODE_ENV === "production" && !env.DATABASE_URL) {
    throw new Error("DATABASE_URL is required in production");
  }
  if (env.NODE_ENV === "production" && env.OBJECT_STORE_MODE !== "s3") {
    throw new Error("OBJECT_STORE_MODE=s3 is required when NODE_ENV=production");
  }
  if (
    env.OBJECT_STORE_MODE === "s3" &&
    (!env.OBJECT_STORAGE_ENDPOINT?.trim() ||
      !env.OBJECT_STORAGE_BUCKET?.trim() ||
      !env.OBJECT_STORAGE_ACCESS_KEY_ID?.trim() ||
      !env.OBJECT_STORAGE_SECRET_ACCESS_KEY?.trim())
  ) {
    throw new Error(
      "OBJECT_STORAGE_ENDPOINT, OBJECT_STORAGE_BUCKET, OBJECT_STORAGE_ACCESS_KEY_ID, and OBJECT_STORAGE_SECRET_ACCESS_KEY are required when OBJECT_STORE_MODE=s3"
    );
  }
  if (env.NODE_ENV === "production" && env.AUTH_MODE !== "production") {
    throw new Error("AUTH_MODE=production is required when NODE_ENV=production");
  }
  if (env.NODE_ENV === "production" && env.AUTH_PROVIDER !== "oidc" && env.AUTH_PROVIDER !== "local") {
    throw new Error("AUTH_PROVIDER=oidc or AUTH_PROVIDER=local is required when NODE_ENV=production");
  }
  if (
    env.NODE_ENV === "production" &&
    !["hdc", "adb", "multi"].includes(env.DEBUG_DEVICE_GATEWAY_MODE) &&
    !env.DEVICE_GATEWAY_ALLOW_SIMULATOR_IN_PRODUCTION
  ) {
    throw new Error(
      "DEBUG_DEVICE_GATEWAY_MODE=hdc, adb, or multi is required when NODE_ENV=production. Set DEVICE_GATEWAY_ALLOW_SIMULATOR_IN_PRODUCTION=true only for non-customer staging environments that intentionally run the simulator."
    );
  }
  if (env.AUTH_MODE === "production" && env.AUTH_PROVIDER === "hmac" && (!env.AUTH_TOKEN_ISSUER?.trim() || !env.AUTH_TOKEN_HMAC_SECRET?.trim())) {
    throw new Error("AUTH_TOKEN_ISSUER and AUTH_TOKEN_HMAC_SECRET are required when AUTH_MODE=production");
  }
  if (env.AUTH_MODE === "production" && env.AUTH_PROVIDER === "hmac" && env.NODE_ENV !== "test" && (env.AUTH_TOKEN_HMAC_SECRET?.length ?? 0) < 32) {
    throw new Error("AUTH_TOKEN_HMAC_SECRET must be at least 32 characters outside tests");
  }
  if (env.AUTH_MODE === "production" && env.AUTH_PROVIDER === "oidc" && (!env.AUTH_OIDC_ISSUER?.trim() || !env.AUTH_OIDC_AUDIENCE?.trim())) {
    throw new Error("AUTH_OIDC_ISSUER and AUTH_OIDC_AUDIENCE are required when AUTH_PROVIDER=oidc");
  }
  if (env.LOG_ANALYSIS_QUEUE_MODE === "durable" && !env.REDIS_URL?.trim()) {
    throw new Error("REDIS_URL is required when LOG_ANALYSIS_QUEUE_MODE=durable");
  }
  if (env.NOTIFICATION_QUEUE_MODE === "durable" && !env.REDIS_URL?.trim()) {
    throw new Error("REDIS_URL is required when NOTIFICATION_QUEUE_MODE=durable");
  }
  if (env.NODE_ENV === "production" && (env.XIAOZE_CHECKPOINTER !== "postgres" || !env.DATABASE_URL?.trim())) {
    throw new Error("XIAOZE_CHECKPOINTER=postgres and DATABASE_URL are required in production");
  }
  if (env.NODE_ENV === "production" && env.LOG_WEBHOOK_ALLOW_INSECURE_LOCAL) {
    throw new Error("LOG_WEBHOOK_ALLOW_INSECURE_LOCAL is a local-development flag and must stay false in production");
  }

  return {
    ...env,
    XIAOZE_LLM_CONFIG: xiaozeLlmConfig
  };
}
