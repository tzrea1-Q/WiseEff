import { claimJobById, claimNextJob, failJob, getJobSnapshot, markJobDeadLettered, markJobRetryScheduled, updateJobProgress } from "../jobs/repository";
import type { ClaimedLogAnalysisJobDto } from "../jobs/types";
import type { Database } from "../../shared/database/client";
import { decideRetry } from "../jobs/retryPolicy";
import type { LogAnalysisJobFailureReason, MetricsRegistry } from "../../observability/metrics";
import type { TracingBoundary } from "../../observability/tracing";
import { createRuleBasedLogAnalyzer, type AnalyzeLogInput, type AnalyzeLogOutput, type LogAnalysisAdapter } from "./analyzer";
import { LogAnalysisProviderError, LOG_ANALYSIS_PROMPT_VERSION } from "./analyzer/llmAnalyzer";
import { readStoredLogFormatProfile } from "./formatProfile";
import type { ObjectStore } from "./objectStore";
import { parseLogText } from "./parser";
import {
  completeLogAnalysisJobWithReport,
  failRun,
  getLogWorkerRunSnapshot as getActiveLogWorkerRunSnapshot,
  updateRunStageProgress
} from "./repository";
import { notifyLogAnalysisCompleted, notifyLogAnalysisFailed } from "../notifications/producers";
import type { LogWebhookDeliverer } from "./webhookDelivery";
import type { LogStage } from "./status";

type LogWorkerMetrics = Pick<MetricsRegistry, "recordLogAnalysisJobResult"> &
  Partial<Pick<MetricsRegistry, "recordLogAnalysisDegraded">>;

/** Best-effort result-webhook hook; the worker never awaits or fails on it (P3b). */
export type LogWorkerWebhooks = Pick<LogWebhookDeliverer, "notifyAnalysisTerminal">;

export type ProcessLogWorkerOptions = {
  db: Database;
  objectStore: ObjectStore;
  analyzer?: LogAnalysisAdapter;
  workerId?: string;
  leaseTtlMs?: number;
  maxAttempts?: number;
  retryBaseDelayMs?: number;
  now?: () => Date;
  metrics?: LogWorkerMetrics;
  tracing?: Pick<TracingBoundary, "withSpan">;
  webhooks?: LogWorkerWebhooks;
};

export type ProcessLogWorkerByIdOptions = ProcessLogWorkerOptions & {
  jobId: string;
};

export type ProcessLogWorkerResult =
  | { status: "processed" }
  | { status: "idle" }
  | { status: "retry"; reason: string }
  | { status: "dead-lettered"; reason: string };

type StageStatus = "processing" | "complete" | "failed";

class JobLeaseLostError extends Error {
  constructor() {
    super("Log analysis job lease was lost before the worker write completed.");
  }
}

async function traceLogAnalysisJob(
  tracing: Pick<TracingBoundary, "withSpan"> | undefined,
  trigger: "polling" | "queue",
  fn: () => Promise<ProcessLogWorkerResult>
): Promise<ProcessLogWorkerResult> {
  const attributes: Record<string, string | number | boolean> = { trigger };
  const execute = async () => {
    try {
      const result = await fn();
      attributes.status = result.status;
      return result;
    } catch (error) {
      attributes.status = "failed";
      attributes.errorType = error instanceof Error ? error.name : "unknown";
      throw error;
    }
  };

  return tracing ? tracing.withSpan("log_analysis.job", attributes, execute) : execute();
}

function assertActiveJobLease(updated: boolean) {
  if (!updated) {
    throw new JobLeaseLostError();
  }
}

async function markProgress(
  options: ProcessLogWorkerOptions,
  input: {
    organizationId: string;
    jobId: string;
    runId: string;
    stage: LogStage;
    status: StageStatus;
    progress: number;
    message: string;
    leaseOwner: string;
  }
) {
  assertActiveJobLease(
    await updateJobProgress(options.db, {
      organizationId: input.organizationId,
      jobId: input.jobId,
      progress: input.progress,
      currentStage: input.stage,
      leaseOwner: input.leaseOwner
    })
  );
  await updateRunStageProgress(options.db, {
    organizationId: input.organizationId,
    runId: input.runId,
    status: input.status === "failed" ? "failed" : "processing",
    stageStatus: input.status === "failed" ? "failed" : input.status,
    stage: input.stage,
    progress: input.progress,
    message: input.message
  });
}

function readableError(error: unknown) {
  return error instanceof Error ? error.message : String(error);
}

/**
 * Honest degradation (glossary: Degraded analysis): a transient provider failure keeps
 * riding the existing job retry/backoff; the retry-exhausting final attempt falls back
 * to the deterministic rule analyzer with explicit provenance instead of dead-lettering.
 * Only a failing fallback continues into the existing failure/dead-letter path.
 * Exported for the behavior-layer eval harness, which exercises the same chain.
 */
export async function analyzeWithDegradation(input: {
  analyzer: LogAnalysisAdapter;
  analyzeInput: AnalyzeLogInput;
  job: Pick<ClaimedLogAnalysisJobDto, "attemptCount">;
  maxAttempts: number;
  retryBaseDelayMs: number;
  now: () => Date;
  metrics?: LogWorkerMetrics;
}): Promise<AnalyzeLogOutput> {
  try {
    return await input.analyzer.analyze(input.analyzeInput);
  } catch (error) {
    if (!(error instanceof LogAnalysisProviderError)) {
      throw error;
    }
    const decision = decideRetry({
      attemptCount: input.job.attemptCount,
      maxAttempts: input.maxAttempts,
      baseDelayMs: input.retryBaseDelayMs,
      now: input.now()
    });
    if (decision.action === "retry") {
      throw error;
    }

    input.metrics?.recordLogAnalysisDegraded?.({
      reason: "provider-unavailable",
      model: error.modelLabel ?? "unknown"
    });
    const fallback = await createRuleBasedLogAnalyzer().analyze(input.analyzeInput);
    return {
      ...fallback,
      analysisSource: "rules-fallback",
      degradedReason: "provider-unavailable",
      promptVersion: LOG_ANALYSIS_PROMPT_VERSION,
      model: error.modelLabel
    };
  }
}

async function processClaimedLogAnalysisJob(
  {
    db,
    objectStore,
    analyzer,
    workerId,
    maxAttempts,
    retryBaseDelayMs,
    now,
    metrics,
    webhooks
  }: Required<Pick<ProcessLogWorkerOptions, "analyzer" | "workerId" | "maxAttempts" | "retryBaseDelayMs" | "now">> &
    Pick<ProcessLogWorkerOptions, "db" | "objectStore" | "metrics" | "webhooks">,
  job: ClaimedLogAnalysisJobDto
): Promise<ProcessLogWorkerResult> {
  const leaseOwner = job.leaseOwner ?? workerId;
  const startedAtMs = now().getTime();

  const options = { db, objectStore, analyzer };
  const jobSnapshot = await getJobSnapshot(db, job.id);
  const snapshot = await getActiveLogWorkerRunSnapshot(db, job.id);
  const recordMetric = (input: {
    status: "complete" | "retry" | "dead_lettered" | "failed";
    stage: LogStage;
    failureReason?: LogAnalysisJobFailureReason;
    endedAt?: Date;
  }) => {
    metrics?.recordLogAnalysisJobResult({
      status: input.status,
      stage: input.stage,
      durationMs: Math.max(0, (input.endedAt ?? now()).getTime() - startedAtMs),
      ...(input.failureReason ? { failureReason: input.failureReason } : {})
    });
  };

  if (!snapshot) {
    const staleReason = jobSnapshot
      ? "Log analysis job is stale because its run is no longer current."
      : "Unable to load log analysis job target.";

    const failedJob = await failJob(db, {
      organizationId: job.organizationId,
      jobId: job.id,
      currentStage: "parse",
      error: staleReason,
      leaseOwner
    });
    if (!failedJob) return { status: "idle" };

    if (jobSnapshot) {
      await updateRunStageProgress(db, {
        organizationId: jobSnapshot.organizationId,
        runId: jobSnapshot.runId,
        status: "failed",
        stageStatus: "failed",
        stage: jobSnapshot.currentStage,
        progress: jobSnapshot.progress,
        message: staleReason
      });
      await failRun(db, {
        organizationId: jobSnapshot.organizationId,
        logId: jobSnapshot.logId,
        runId: jobSnapshot.runId,
        currentStage: jobSnapshot.currentStage,
        error: staleReason
      });
    }
    recordMetric({ status: "failed", stage: jobSnapshot?.currentStage ?? "parse", failureReason: "stale_run" });
    return { status: "processed" };
  }

  let currentStage: LogStage = "parse";
  let currentProgress = 0;
  let currentFailureReason: LogAnalysisJobFailureReason = "unknown";

  try {
    await markProgress(options, {
      organizationId: snapshot.organizationId,
      jobId: snapshot.jobId,
      runId: snapshot.runId,
      stage: "parse",
      status: "processing",
      progress: 10,
      message: "Reading and parsing the uploaded log.",
      leaseOwner
    });
    currentProgress = 10;

    currentFailureReason = "object_store_error";
    const bytes = await objectStore.get(snapshot.storageKey);
    currentFailureReason = "parse_error";
    const formatProfile = readStoredLogFormatProfile(snapshot.logDomain?.formatProfile ?? undefined);
    const parsed = parseLogText({ fileName: snapshot.fileName, content: bytes }, { profile: formatProfile });
    if (!parsed.ok) {
      throw new Error(parsed.reason);
    }
    currentFailureReason = "unknown";

    await markProgress(options, {
      organizationId: snapshot.organizationId,
      jobId: snapshot.jobId,
      runId: snapshot.runId,
      stage: "parse",
      status: "complete",
      progress: 30,
      message: "Log parsing complete.",
      leaseOwner
    });
    currentProgress = 30;

    currentStage = "pattern";
    await markProgress(options, {
      organizationId: snapshot.organizationId,
      jobId: snapshot.jobId,
      runId: snapshot.runId,
      stage: "pattern",
      status: "processing",
      progress: 40,
      message: "Finding known operational patterns.",
      leaseOwner
    });
    currentProgress = 40;

    await markProgress(options, {
      organizationId: snapshot.organizationId,
      jobId: snapshot.jobId,
      runId: snapshot.runId,
      stage: "pattern",
      status: "complete",
      progress: 55,
      message: "Pattern analysis complete.",
      leaseOwner
    });
    currentProgress = 55;

    currentStage = "rootcause";
    await markProgress(options, {
      organizationId: snapshot.organizationId,
      jobId: snapshot.jobId,
      runId: snapshot.runId,
      stage: "rootcause",
      status: "processing",
      progress: 65,
      message: "Linking evidence to likely root causes.",
      leaseOwner
    });
    currentProgress = 65;

    // P2: the analysis kernel runs inside the rootcause stage (the agent loop's
    // natural home); loop steps advance the progress bar inside the 65→80 range.
    const analysis = await analyzeWithDegradation({
      analyzer,
      analyzeInput: {
        parsed,
        analysisQuestion: snapshot.analysisQuestion ?? undefined,
        logDomain: snapshot.logDomain
          ? {
              name: snapshot.logDomain.name,
              description: snapshot.logDomain.description ?? undefined,
              modelOverride: snapshot.logDomain.modelOverride ?? undefined
            }
          : undefined,
        organizationId: snapshot.organizationId,
        logDomainId: snapshot.logDomain?.id,
        relatedParameterId: snapshot.relatedParameterId ?? undefined,
        onProgress: async ({ step, maxSteps }) => {
          const boundedStep = Math.min(Math.max(step, 1), Math.max(maxSteps, 1));
          const progress = 65 + Math.min(14, Math.floor(((boundedStep - 1) / Math.max(maxSteps, 1)) * 15));
          if (progress <= currentProgress) {
            return;
          }
          await markProgress(options, {
            organizationId: snapshot.organizationId,
            jobId: snapshot.jobId,
            runId: snapshot.runId,
            stage: "rootcause",
            status: "processing",
            progress,
            message: `Analysis step ${boundedStep}/${maxSteps}.`,
            leaseOwner
          });
          currentProgress = progress;
        }
      },
      job,
      maxAttempts,
      retryBaseDelayMs,
      now,
      metrics
    });

    await markProgress(options, {
      organizationId: snapshot.organizationId,
      jobId: snapshot.jobId,
      runId: snapshot.runId,
      stage: "rootcause",
      status: "complete",
      progress: 80,
      message: "Root cause evidence prepared.",
      leaseOwner
    });
    currentProgress = 80;

    currentStage = "report";
    await markProgress(options, {
      organizationId: snapshot.organizationId,
      jobId: snapshot.jobId,
      runId: snapshot.runId,
      stage: "report",
      status: "processing",
      progress: 90,
      message: "Writing report and evidence.",
      leaseOwner
    });
    currentProgress = 90;

    const completed = await completeLogAnalysisJobWithReport(db, {
      organizationId: snapshot.organizationId,
      logId: snapshot.logId,
      runId: snapshot.runId,
      jobId: snapshot.jobId,
      leaseOwner,
      report: {
        confidence: analysis.confidence,
        conclusion: analysis.conclusion,
        impact: analysis.impact,
        severity: analysis.severity,
        suggestedActions: analysis.suggestedActions,
        rawLines: parsed.rawLines,
        analysisSource: analysis.analysisSource,
        degradedReason: analysis.degradedReason,
        promptVersion: analysis.promptVersion,
        model: analysis.model
      },
      evidence: analysis.evidence
    });
    if (!completed) return { status: "idle" };

    if (snapshot.submittedByUserId) {
      await notifyLogAnalysisCompleted(db, {
        organizationId: snapshot.organizationId,
        logId: snapshot.logId,
        runId: snapshot.runId,
        fileName: snapshot.fileName,
        recipientUserId: snapshot.submittedByUserId,
        conclusion: analysis.conclusion
      });
    }

    // Terminal state is persisted; fire the best-effort domain result webhook
    // without blocking the worker (degraded completions included, honestly marked).
    if (snapshot.logDomain && webhooks) {
      webhooks.notifyAnalysisTerminal({
        organizationId: snapshot.organizationId,
        logDomainId: snapshot.logDomain.id,
        logId: snapshot.logId,
        runId: snapshot.runId,
        fileName: snapshot.fileName,
        status: "complete",
        analysisSource: analysis.analysisSource,
        degradedReason: analysis.degradedReason,
        severity: analysis.severity,
        confidence: analysis.confidence,
        conclusion: analysis.conclusion,
        occurredAt: now().toISOString()
      });
    }

    recordMetric({ status: "complete", stage: "report" });
    return { status: "processed" };
  } catch (error) {
    if (error instanceof JobLeaseLostError) {
      return { status: "idle" };
    }
    const message = readableError(error);
    const endedAt = now();
    const decision = decideRetry({ attemptCount: job.attemptCount, maxAttempts, baseDelayMs: retryBaseDelayMs, now: endedAt });
    if (decision.action === "retry") {
      const scheduled = await markJobRetryScheduled(db, {
        organizationId: snapshot.organizationId,
        jobId: snapshot.jobId,
        currentStage,
        error: message,
        nextRunAt: decision.nextRunAt,
        reason: decision.reason,
        leaseOwner
      });
      if (!scheduled) return { status: "idle" };
      recordMetric({ status: "retry", stage: currentStage, failureReason: currentFailureReason, endedAt });
      return { status: "retry", reason: decision.reason };
    }

    const deadLettered = await markJobDeadLettered(db, {
      organizationId: snapshot.organizationId,
      jobId: snapshot.jobId,
      currentStage,
      error: message,
      reason: decision.reason,
      leaseOwner
    });
    if (!deadLettered) return { status: "idle" };

    await updateRunStageProgress(options.db, {
      organizationId: snapshot.organizationId,
      runId: snapshot.runId,
      status: "failed",
      stageStatus: "failed",
      stage: currentStage,
      progress: currentProgress,
      message
    });
    await failRun(db, {
      organizationId: snapshot.organizationId,
      logId: snapshot.logId,
      runId: snapshot.runId,
      currentStage,
      error: decision.reason
    });
    if (snapshot.submittedByUserId) {
      await notifyLogAnalysisFailed(db, {
        organizationId: snapshot.organizationId,
        logId: snapshot.logId,
        runId: snapshot.runId,
        fileName: snapshot.fileName,
        recipientUserId: snapshot.submittedByUserId,
        failureReason: decision.reason
      });
    }
    if (snapshot.logDomain && webhooks) {
      webhooks.notifyAnalysisTerminal({
        organizationId: snapshot.organizationId,
        logDomainId: snapshot.logDomain.id,
        logId: snapshot.logId,
        runId: snapshot.runId,
        fileName: snapshot.fileName,
        status: "failed",
        conclusion: decision.reason,
        occurredAt: endedAt.toISOString()
      });
    }
    recordMetric({ status: "dead_lettered", stage: currentStage, failureReason: currentFailureReason, endedAt });
    return { status: "dead-lettered", reason: decision.reason };
  }
}

export async function processNextLogAnalysisJob({
  db,
  objectStore,
  analyzer = createRuleBasedLogAnalyzer(),
  workerId = "wiseeff-log-worker",
  leaseTtlMs = 60_000,
  maxAttempts = 4,
  retryBaseDelayMs = 1000,
  now = () => new Date(),
  metrics,
  tracing,
  webhooks
}: ProcessLogWorkerOptions): Promise<"processed" | "idle"> {
  const job = await claimNextJob(db, { kind: "log-analysis", leaseOwner: workerId, leaseTtlMs });
  if (!job) return "idle";
  const process = async () => processClaimedLogAnalysisJob({ db, objectStore, analyzer, workerId, maxAttempts, retryBaseDelayMs, now, metrics, webhooks }, job);
  const result = await traceLogAnalysisJob(tracing, "polling", process);
  return result.status === "idle" ? "idle" : "processed";
}

export async function processLogAnalysisJobById({
  db,
  objectStore,
  jobId,
  analyzer = createRuleBasedLogAnalyzer(),
  workerId = "wiseeff-log-worker",
  leaseTtlMs = 60_000,
  maxAttempts = 4,
  retryBaseDelayMs = 1000,
  now = () => new Date(),
  metrics,
  tracing,
  webhooks
}: ProcessLogWorkerByIdOptions): Promise<ProcessLogWorkerResult> {
  const job = await claimJobById(db, { kind: "log-analysis", jobId, leaseOwner: workerId, leaseTtlMs });
  if (!job) return { status: "idle" };
  const process = async () => processClaimedLogAnalysisJob({ db, objectStore, analyzer, workerId, maxAttempts, retryBaseDelayMs, now, metrics, webhooks }, job);
  return traceLogAnalysisJob(tracing, "queue", process);
}

export function startLogWorkerLoop(options: ProcessLogWorkerOptions, intervalMs = 1000): () => Promise<void> {
  let stopped = false;
  let running = false;
  let activeRun: Promise<unknown> | undefined;

  const tick = () => {
    if (stopped || running) return;
    running = true;
    activeRun = processNextLogAnalysisJob(options)
      .catch(() => {
        // Intentionally swallow unexpected loop-level failures after they have been surfaced by the worker tests.
      })
      .finally(() => {
        running = false;
        activeRun = undefined;
      });
  };

  const interval = setInterval(tick, intervalMs);
  tick();

  return async () => {
    stopped = true;
    clearInterval(interval);
    await activeRun;
  };
}
