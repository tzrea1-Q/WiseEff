# V13 legacy database capability submatrix

[Chinese](writerReachability.zh-CN.md)

This change repairs a demonstrated V13 false pass. A separate restricted LOGIN
could update a legacy driver schema while the formal PostgreSQL V13 adapter
returned `passed`. It does not establish complete P13 retirement or authorize
runtime startup, restoration, queue consumption, or release.

## Scope and source ownership

The original four entries in `catalogRoleManifest.LEGACY_STRUCTURAL_TABLES`
remain unchanged. V13 observes those four relations plus these existing legacy
structural relations:

| Relation | Existing structural writer |
| --- | --- |
| `driver_schemas` | `parameter-specs/service.ts` `reattributeParameterSpec`; `parameter-specs/repository.ts` `upsertMatchedDriverSchema` |
| `driver_schema_versions` | `upsertMatchedDriverSchema` inserts the version |
| `dts_property_specs` | `reattributeParameterSpec` updates namespace and property key |

The retired `parameterSpecs.reattribute` route is already in the frozen route
manifest in `contracts/dtoSchemas/parameterCatalog.ts`. The seven-table list is
a proven database subset, not the complete legacy source or writer inventory.
No migration, grant, shared role manifest, format, gate identifier, failure code,
trusted baseline, or boundary allowance changes here.

## Threats and observation

### Native referential actions

Migration 0048's existing `projects` DELETE cascades into
`project_parameter_bindings`. A restricted LOGIN with only project DELETE and
identifier SELECT really deleted one binding without a binding mutation ACL;
V13 nevertheless passed. Test-only `ae1f20d66111cbabb758abee48b9294f3bc16aca`
reproduced this: 32 collected, 31 passed, one failed, 5.52 seconds, exit 1,
cleanup verified. Earlier `2dd71469e` failed fixture setup because migration
0067 requires `module_id`; that result is not a gate Red. The corrected fixture
supplies an actual module without changing the schema.

The adapter follows actual FK constraints and enabled internal trigger events
back from the seven relations. DELETE CASCADE propagates DELETE; UPDATE CASCADE
and SET NULL/DEFAULT propagate affected columns. Recursive UNION follows matching
relation/event/column paths, checking only referenced key columns for an initiating
UPDATE, then uses existing LOGIN/SET/definer capabilities at the path source.
Native RI does not confer arbitrary EXECUTE or all rights of the child owner.

Fixed `c6e1f9402aa142769148cd7480498f59f8058c12`, tree
`10f8a5437de66c51135ebccf39edffe80d6dfa5f`, ran 34/34 in 5.48 seconds,
exit 0, no skipped tests, owned cleanup verified. Original 31 cases remain;
unscoped-child cascades and non-key project updates retain passed submatrix
results. Targeted strict types exited 0. Same owned command and PG16 image below;
no grant, migration, timeout, route, or seven-table scope change. Red log
`/tmp/upg824-v13-native-ri-observed-red.log` SHA256
`80c2cb6092f00aaca7794c86762fd3568ee52f1fdeb04635ea7e6580bede9fad`;
Green `/tmp/upg824-v13-native-ri-green.log` SHA256
`4c13a0c4109308d34f22be606881c70240054758ba6a897b3686165de35aed01`.

This does not revoke legitimate project deletion or rewrite its original FK.
An available path blocks retirement; preserving business semantics through
conversion/archive remains the retirement owner's obligation. RI into an
unscoped child followed by a definer trigger, rewrite rules, and role-source
exclusions remain separate work, not zero observations or complete P13.

### Direct and delegated capabilities

The original direct-ACL and definer checks remain. Additional observations root
at actual LOGIN roles, follow PostgreSQL 16 SET membership edges, and use actual
table/column privileges for PUBLIC and inherited capabilities. Ownership is
observed separately. An unreachable NOLOGIN owner is not classified as a runtime
writer merely because it owns a table; granting a reachable membership changes
the result. INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES and TRIGGER capabilities
are blocking, including applicable column grants.

Executable user SECURITY DEFINER functions with an owner capable of changing a
scoped relation are unproven and blocking. Effective EXECUTE delegation follows
additional definer owners, including private inner functions. Recursive UNION
deduplicates LOGIN/owner pairs, so cycles terminate. A restricted owner with only
read access remains permissible. SQL text absence is never a safety proof.
System-schema definers without `pg_init_privs` initialization provenance remain
in this graph; a schema name alone cannot justify the builtin exclusion.
Missing scoped relations and actual query failures return the existing typed
blocking V13 result without private diagnostics or repair writes.

Installed SECURITY DEFINER triggers add a different dispatch edge: the LOGIN
needs the triggering table/column mutation privilege, not EXECUTE on the
function. The existing owner graph now follows these edges and private inner
definers. The observation checks event bits and firing mode; a disabled trigger
is only reachable through an owner able to enable it, and replica-only firing
requires the parameter capability or a recorded replica setting. It does not
interpret function bodies or WHEN clauses as proof of safety. An inaccessible
dispatch table or a trigger owner with only read privileges does not by itself
block the submatrix. PostgreSQL's [trigger catalog](https://www.postgresql.org/docs/16/catalog-pg-trigger.html)
supplies the actual dispatch identity and firing metadata.

Replica reachability belongs to the original LOGIN/session, not a substituted
NOLOGIN role's defaults. The recursive state now retains that capability across
SET ROLE and definer calls, including reachable parameter SET capabilities and
function-local replica configuration. A dispatch-table owner can also enable a
replica-only trigger for ordinary firing. This remains a conservative capability
analysis, not a simulation proving every trigger condition will fire.
Test-only `011663f7b7ffcae321150ef43bf2f8bef1643436` reproduced both omissions
against the first implementation: 31 collected, 29 passed, two failed, zero
skipped, 5.44 seconds, exit 1, cleanup verified. Both tests independently changed
the actual legacy row before observing the erroneous passed gate. Fixed
`205dabf265510870db78264aec75eaa1278aae96`, tree
`09bb0ec01ec4f654f93a42f74fbe939b0242f834`, ran the same 31 cases successfully
in 5.48 seconds, exit 0, zero skipped, cleanup verified. Strict targeted types
and the unchanged 3509-occurrence boundary scan also exited 0. Red log SHA256:
`97f454c826a4a7c14b7f827a00d8046951a8ea0867e7f388a20f373be01080da`;
Green: `1616927f610e013329fc6047d60d603e4b0b3f8b144095df56e63f82b7856667`.
The command remains `node --import tsx scripts/run-upgrade-component-tests.ts
--expected-daemon-id <independently-observed-local-daemon> --suite
writer-reachability-pg16`; the original 15-minute parent budget and per-test
defaults are unchanged. The initial 29-case result is not relabeled as this
31-case execution, and neither establishes whole-consumer retirement.

Test-only `cfb199cbcae3eaf74c2f92e947dbd78839eb25f4`, tree
`beade877fabf61b7797730c741e66ea7dfb9170d`, reproduced a real restricted LOGIN
INSERT on an unscoped table changing `driver_schemas` through a trigger whose
EXECUTE grant had been revoked. The formal V13 adapter still passed: 25 collected,
24 passed, one failed, zero skipped, 5.25 seconds, exit 1, owned cleanup verified.
The fixed implementation `ee9bedf01ceb31656e282ed8635766adb2e72075`, tree
`94a525766f9c3489598705e7a1cfec8da5da4f0a`, ran 29/29 in 5.59 seconds,
exit 0, zero skipped, cleanup verified. This includes the original 24 cases,
the trigger Red, a private inner writer, and read-only-owner, disabled and
no-dispatch-grant cases. Targeted strict types exited 0. The unchanged trusted
baseline scan retained 3509 allowed occurrences with no new/stale/mismatched
entries or allowance growth. The original PG16 image/platform above is unchanged.
Red log SHA256: `3fce56fd49c80283228f6bc8135d97eff7665cc87e2b001255a1aa605621a813`;
Green: `d0d7d2a977daea0eaaa7b610f3ee8723f5e32c6f97ece5a1979bd3ba6fe4dffc`.
These are exact owned component executions, not full P13 or startup proof.

The inherited `postgres` and `current_user` exclusions are compatibility behavior,
not a trusted production-role manifest. Controller-proven production identities,
all legacy tables, native referential-action triggers, rewrite rules, event
triggers, other function mechanisms, HTTP/Agent/review/jobs,
scripts and background writers remain separate obligations. The evidence scope
label enters the evidence digest; the report does not interpret it as a new gate
state. A passed database submatrix must not become a complete P13 fingerprint.
The missing-table test concerns the existing pre-retirement observation window;
it does not change P16 cleanup semantics.

## Reproduction and execution identity

Run `scripts/run-upgrade-component-tests.ts` with suite
`writer-reachability-pg16` and the independently verified local daemon identity.
Use the existing runner's authorized host admission; do not supply an ambient
database URL. It creates an owned temporary PG16 cluster and runs the real
adapter using a read-only LOGIN. Tests deliberately change synthetic roles,
ACLs, ownership, functions and one system-catalog SELECT grant inside that owned
cluster. Cleanup closes clients before disposing of the temporary database and
runner resources. No production inputs are consumed.

The suite has a receipt-first exact config, rejects zero tests, retains default
timeouts, and is excluded only from the shared server suite. The mandatory
owned CI job executes it and remains required by Merge bar.

Dependency: `2b5d5ed4446a1aca56dd3d929fd15691172ba29d`, descending from main
`cda6737a8f177a8bbd2f3bc7d195f8e3037bfa74`.

| Executed code | Collected / passed / failed / skipped | Result |
| --- | --- | --- |
| `81905a346` | 12 / 1 / 11 / 0 | Initial real LOGIN Red, exit 1 |
| `9bdb6a686` | 19 / 1 / 18 / 0 | Expanded capability Red, exit 1 |
| `d135f4ce5` | 19 / 19 / 0 / 0 | First implementation, exit 0 |
| `0733f322f` | 23 / 22 / 1 / 0 | Private inner EXECUTE delegation Red, exit 1 |
| `6dca0f385365c54c4c8a2ba63c5315309e0672ca` | 23 / 23 / 0 / 0 | 5.69 seconds, exit 0 |

The 23-case execution tree is `92482fca44d08c2d51db1c5190007fe296e4465a`.
All these runs verified owned resource cleanup. Image: `postgres:16-alpine`,
`linux/arm64`, image ID
`sha256:16bc17c64a573ef34162af9298258d1aec548232985b33ed7b1eac33ba35c229`.
The 23-case Green log SHA-256 is
`6545e9c3c1d4fe9f25416958cdff2651bec2025cd48a5d57d67823d0e60d2bf5`;
the preceding delegation Red log is
`3891cc3e8dc4bb17fb0f7eb5e9344d09127348955fe2151fd531bca95132fb18`.
Targeted TypeScript checking exited 0. Boundary checking against the unchanged
trusted base `9b3ba7df7e21f5589684bc92c872da593ad4c246` exited 0:
3509 existing allowed occurrences, zero new/stale/mismatched/growing allowances.
These are local isolated component executions, not Hosted, whole-controller,
approved runtime startup, or production evidence. Later documentation commits do
not relabel these executed identities.

Independent review then identified the system-schema provenance omission. The
first execution of test-only `01da79bff` failed its unchanged 10-second setup:
24 collected, 24 skipped, one failed suite, exit 1; it is not a functional Red.
A bounded repeat of the same code and command reached all cases: 23 passed and
one failed in 5.23 seconds, proving the real LOGIN mutation through a newly
created `pg_catalog` definer while V13 passed. Both runs verified cleanup.
Fixed `d28546fad24e106625d6d176c7d23086f147e9c7`, tree
`c3f9ec4a789e524056bbeca0b19207c8ef3101e8`, ran 24/24 in 5.13 seconds,
exit 0, zero skipped, cleanup verified, with the same image identity above.
Log SHA-256: setup failure
`671b1bbc4d4c504eab0657eb3331b46049e443e2ba340d17cde0d75a30762ec9`,
effective Red `ad96d192590e8bd0c4489586746258955d40ee1092f6f5ae938dd116c93542a4`,
Green `a9668f5e5595986d517f620ec4926336069183af4e1afa162021f6db10c21eb1`.
Fixed targeted types and the same trusted-base boundary both exited 0; boundary
counts remain 3509 allowed and zero new, stale, mismatched or growing allowances.
No timeout or baseline was changed to obtain this result.
