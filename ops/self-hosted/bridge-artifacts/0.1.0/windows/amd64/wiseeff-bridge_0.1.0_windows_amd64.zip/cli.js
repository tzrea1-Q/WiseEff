#!/usr/bin/env node
import { createRequire } from 'module';
const require = createRequire(import.meta.url);
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x)(function(x) {
  if (typeof require !== "undefined") return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x + '" is not supported');
});
var __commonJS = (cb, mod) => function __require2() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// node_modules/ws/lib/constants.js
var require_constants = __commonJS({
  "node_modules/ws/lib/constants.js"(exports, module) {
    "use strict";
    var BINARY_TYPES = ["nodebuffer", "arraybuffer", "fragments"];
    var hasBlob = typeof Blob !== "undefined";
    if (hasBlob) BINARY_TYPES.push("blob");
    module.exports = {
      BINARY_TYPES,
      CLOSE_TIMEOUT: 3e4,
      EMPTY_BUFFER: Buffer.alloc(0),
      GUID: "258EAFA5-E914-47DA-95CA-C5AB0DC85B11",
      hasBlob,
      kForOnEventAttribute: /* @__PURE__ */ Symbol("kIsForOnEventAttribute"),
      kListener: /* @__PURE__ */ Symbol("kListener"),
      kStatusCode: /* @__PURE__ */ Symbol("status-code"),
      kWebSocket: /* @__PURE__ */ Symbol("websocket"),
      NOOP: () => {
      }
    };
  }
});

// node_modules/ws/lib/buffer-util.js
var require_buffer_util = __commonJS({
  "node_modules/ws/lib/buffer-util.js"(exports, module) {
    "use strict";
    var { EMPTY_BUFFER } = require_constants();
    var FastBuffer = Buffer[Symbol.species];
    function concat(list, totalLength) {
      if (list.length === 0) return EMPTY_BUFFER;
      if (list.length === 1) return list[0];
      const target = Buffer.allocUnsafe(totalLength);
      let offset = 0;
      for (let i = 0; i < list.length; i++) {
        const buf = list[i];
        target.set(buf, offset);
        offset += buf.length;
      }
      if (offset < totalLength) {
        return new FastBuffer(target.buffer, target.byteOffset, offset);
      }
      return target;
    }
    function _mask(source, mask, output, offset, length) {
      for (let i = 0; i < length; i++) {
        output[offset + i] = source[i] ^ mask[i & 3];
      }
    }
    function _unmask(buffer, mask) {
      for (let i = 0; i < buffer.length; i++) {
        buffer[i] ^= mask[i & 3];
      }
    }
    function toArrayBuffer(buf) {
      if (buf.length === buf.buffer.byteLength) {
        return buf.buffer;
      }
      return buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.length);
    }
    function toBuffer(data) {
      toBuffer.readOnly = true;
      if (Buffer.isBuffer(data)) return data;
      let buf;
      if (data instanceof ArrayBuffer) {
        buf = new FastBuffer(data);
      } else if (ArrayBuffer.isView(data)) {
        buf = new FastBuffer(data.buffer, data.byteOffset, data.byteLength);
      } else {
        buf = Buffer.from(data);
        toBuffer.readOnly = false;
      }
      return buf;
    }
    module.exports = {
      concat,
      mask: _mask,
      toArrayBuffer,
      toBuffer,
      unmask: _unmask
    };
    if (!process.env.WS_NO_BUFFER_UTIL) {
      try {
        const bufferUtil = __require("bufferutil");
        module.exports.mask = function(source, mask, output, offset, length) {
          if (length < 48) _mask(source, mask, output, offset, length);
          else bufferUtil.mask(source, mask, output, offset, length);
        };
        module.exports.unmask = function(buffer, mask) {
          if (buffer.length < 32) _unmask(buffer, mask);
          else bufferUtil.unmask(buffer, mask);
        };
      } catch (e) {
      }
    }
  }
});

// node_modules/ws/lib/limiter.js
var require_limiter = __commonJS({
  "node_modules/ws/lib/limiter.js"(exports, module) {
    "use strict";
    var kDone = /* @__PURE__ */ Symbol("kDone");
    var kRun = /* @__PURE__ */ Symbol("kRun");
    var Limiter = class {
      /**
       * Creates a new `Limiter`.
       *
       * @param {Number} [concurrency=Infinity] The maximum number of jobs allowed
       *     to run concurrently
       */
      constructor(concurrency) {
        this[kDone] = () => {
          this.pending--;
          this[kRun]();
        };
        this.concurrency = concurrency || Infinity;
        this.jobs = [];
        this.pending = 0;
      }
      /**
       * Adds a job to the queue.
       *
       * @param {Function} job The job to run
       * @public
       */
      add(job) {
        this.jobs.push(job);
        this[kRun]();
      }
      /**
       * Removes a job from the queue and runs it if possible.
       *
       * @private
       */
      [kRun]() {
        if (this.pending === this.concurrency) return;
        if (this.jobs.length) {
          const job = this.jobs.shift();
          this.pending++;
          job(this[kDone]);
        }
      }
    };
    module.exports = Limiter;
  }
});

// node_modules/ws/lib/permessage-deflate.js
var require_permessage_deflate = __commonJS({
  "node_modules/ws/lib/permessage-deflate.js"(exports, module) {
    "use strict";
    var zlib = __require("zlib");
    var bufferUtil = require_buffer_util();
    var Limiter = require_limiter();
    var { kStatusCode } = require_constants();
    var FastBuffer = Buffer[Symbol.species];
    var TRAILER = Buffer.from([0, 0, 255, 255]);
    var kPerMessageDeflate = /* @__PURE__ */ Symbol("permessage-deflate");
    var kTotalLength = /* @__PURE__ */ Symbol("total-length");
    var kCallback = /* @__PURE__ */ Symbol("callback");
    var kBuffers = /* @__PURE__ */ Symbol("buffers");
    var kError = /* @__PURE__ */ Symbol("error");
    var zlibLimiter;
    var PerMessageDeflate2 = class {
      /**
       * Creates a PerMessageDeflate instance.
       *
       * @param {Object} [options] Configuration options
       * @param {(Boolean|Number)} [options.clientMaxWindowBits] Advertise support
       *     for, or request, a custom client window size
       * @param {Boolean} [options.clientNoContextTakeover=false] Advertise/
       *     acknowledge disabling of client context takeover
       * @param {Number} [options.concurrencyLimit=10] The number of concurrent
       *     calls to zlib
       * @param {Boolean} [options.isServer=false] Create the instance in either
       *     server or client mode
       * @param {Number} [options.maxPayload=0] The maximum allowed message length
       * @param {(Boolean|Number)} [options.serverMaxWindowBits] Request/confirm the
       *     use of a custom server window size
       * @param {Boolean} [options.serverNoContextTakeover=false] Request/accept
       *     disabling of server context takeover
       * @param {Number} [options.threshold=1024] Size (in bytes) below which
       *     messages should not be compressed if context takeover is disabled
       * @param {Object} [options.zlibDeflateOptions] Options to pass to zlib on
       *     deflate
       * @param {Object} [options.zlibInflateOptions] Options to pass to zlib on
       *     inflate
       */
      constructor(options) {
        this._options = options || {};
        this._threshold = this._options.threshold !== void 0 ? this._options.threshold : 1024;
        this._maxPayload = this._options.maxPayload | 0;
        this._isServer = !!this._options.isServer;
        this._deflate = null;
        this._inflate = null;
        this.params = null;
        if (!zlibLimiter) {
          const concurrency = this._options.concurrencyLimit !== void 0 ? this._options.concurrencyLimit : 10;
          zlibLimiter = new Limiter(concurrency);
        }
      }
      /**
       * @type {String}
       */
      static get extensionName() {
        return "permessage-deflate";
      }
      /**
       * Create an extension negotiation offer.
       *
       * @return {Object} Extension parameters
       * @public
       */
      offer() {
        const params = {};
        if (this._options.serverNoContextTakeover) {
          params.server_no_context_takeover = true;
        }
        if (this._options.clientNoContextTakeover) {
          params.client_no_context_takeover = true;
        }
        if (this._options.serverMaxWindowBits) {
          params.server_max_window_bits = this._options.serverMaxWindowBits;
        }
        if (this._options.clientMaxWindowBits) {
          params.client_max_window_bits = this._options.clientMaxWindowBits;
        } else if (this._options.clientMaxWindowBits == null) {
          params.client_max_window_bits = true;
        }
        return params;
      }
      /**
       * Accept an extension negotiation offer/response.
       *
       * @param {Array} configurations The extension negotiation offers/reponse
       * @return {Object} Accepted configuration
       * @public
       */
      accept(configurations) {
        configurations = this.normalizeParams(configurations);
        this.params = this._isServer ? this.acceptAsServer(configurations) : this.acceptAsClient(configurations);
        return this.params;
      }
      /**
       * Releases all resources used by the extension.
       *
       * @public
       */
      cleanup() {
        if (this._inflate) {
          this._inflate.close();
          this._inflate = null;
        }
        if (this._deflate) {
          const callback = this._deflate[kCallback];
          this._deflate.close();
          this._deflate = null;
          if (callback) {
            callback(
              new Error(
                "The deflate stream was closed while data was being processed"
              )
            );
          }
        }
      }
      /**
       *  Accept an extension negotiation offer.
       *
       * @param {Array} offers The extension negotiation offers
       * @return {Object} Accepted configuration
       * @private
       */
      acceptAsServer(offers) {
        const opts = this._options;
        const accepted = offers.find((params) => {
          if (opts.serverNoContextTakeover === false && params.server_no_context_takeover || params.server_max_window_bits && (opts.serverMaxWindowBits === false || typeof opts.serverMaxWindowBits === "number" && opts.serverMaxWindowBits > params.server_max_window_bits) || typeof opts.clientMaxWindowBits === "number" && !params.client_max_window_bits) {
            return false;
          }
          return true;
        });
        if (!accepted) {
          throw new Error("None of the extension offers can be accepted");
        }
        if (opts.serverNoContextTakeover) {
          accepted.server_no_context_takeover = true;
        }
        if (opts.clientNoContextTakeover) {
          accepted.client_no_context_takeover = true;
        }
        if (typeof opts.serverMaxWindowBits === "number") {
          accepted.server_max_window_bits = opts.serverMaxWindowBits;
        }
        if (typeof opts.clientMaxWindowBits === "number") {
          accepted.client_max_window_bits = opts.clientMaxWindowBits;
        } else if (accepted.client_max_window_bits === true || opts.clientMaxWindowBits === false) {
          delete accepted.client_max_window_bits;
        }
        return accepted;
      }
      /**
       * Accept the extension negotiation response.
       *
       * @param {Array} response The extension negotiation response
       * @return {Object} Accepted configuration
       * @private
       */
      acceptAsClient(response) {
        const params = response[0];
        if (this._options.clientNoContextTakeover === false && params.client_no_context_takeover) {
          throw new Error('Unexpected parameter "client_no_context_takeover"');
        }
        if (!params.client_max_window_bits) {
          if (typeof this._options.clientMaxWindowBits === "number") {
            params.client_max_window_bits = this._options.clientMaxWindowBits;
          }
        } else if (this._options.clientMaxWindowBits === false || typeof this._options.clientMaxWindowBits === "number" && params.client_max_window_bits > this._options.clientMaxWindowBits) {
          throw new Error(
            'Unexpected or invalid parameter "client_max_window_bits"'
          );
        }
        return params;
      }
      /**
       * Normalize parameters.
       *
       * @param {Array} configurations The extension negotiation offers/reponse
       * @return {Array} The offers/response with normalized parameters
       * @private
       */
      normalizeParams(configurations) {
        configurations.forEach((params) => {
          Object.keys(params).forEach((key) => {
            let value = params[key];
            if (value.length > 1) {
              throw new Error(`Parameter "${key}" must have only a single value`);
            }
            value = value[0];
            if (key === "client_max_window_bits") {
              if (value !== true) {
                const num = +value;
                if (!Number.isInteger(num) || num < 8 || num > 15) {
                  throw new TypeError(
                    `Invalid value for parameter "${key}": ${value}`
                  );
                }
                value = num;
              } else if (!this._isServer) {
                throw new TypeError(
                  `Invalid value for parameter "${key}": ${value}`
                );
              }
            } else if (key === "server_max_window_bits") {
              const num = +value;
              if (!Number.isInteger(num) || num < 8 || num > 15) {
                throw new TypeError(
                  `Invalid value for parameter "${key}": ${value}`
                );
              }
              value = num;
            } else if (key === "client_no_context_takeover" || key === "server_no_context_takeover") {
              if (value !== true) {
                throw new TypeError(
                  `Invalid value for parameter "${key}": ${value}`
                );
              }
            } else {
              throw new Error(`Unknown parameter "${key}"`);
            }
            params[key] = value;
          });
        });
        return configurations;
      }
      /**
       * Decompress data. Concurrency limited.
       *
       * @param {Buffer} data Compressed data
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @public
       */
      decompress(data, fin, callback) {
        zlibLimiter.add((done) => {
          this._decompress(data, fin, (err, result) => {
            done();
            callback(err, result);
          });
        });
      }
      /**
       * Compress data. Concurrency limited.
       *
       * @param {(Buffer|String)} data Data to compress
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @public
       */
      compress(data, fin, callback) {
        zlibLimiter.add((done) => {
          this._compress(data, fin, (err, result) => {
            done();
            callback(err, result);
          });
        });
      }
      /**
       * Decompress data.
       *
       * @param {Buffer} data Compressed data
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @private
       */
      _decompress(data, fin, callback) {
        const endpoint = this._isServer ? "client" : "server";
        if (!this._inflate) {
          const key = `${endpoint}_max_window_bits`;
          const windowBits = typeof this.params[key] !== "number" ? zlib.Z_DEFAULT_WINDOWBITS : this.params[key];
          this._inflate = zlib.createInflateRaw({
            ...this._options.zlibInflateOptions,
            windowBits
          });
          this._inflate[kPerMessageDeflate] = this;
          this._inflate[kTotalLength] = 0;
          this._inflate[kBuffers] = [];
          this._inflate.on("error", inflateOnError);
          this._inflate.on("data", inflateOnData);
        }
        this._inflate[kCallback] = callback;
        this._inflate.write(data);
        if (fin) this._inflate.write(TRAILER);
        this._inflate.flush(() => {
          const err = this._inflate[kError];
          if (err) {
            this._inflate.close();
            this._inflate = null;
            callback(err);
            return;
          }
          const data2 = bufferUtil.concat(
            this._inflate[kBuffers],
            this._inflate[kTotalLength]
          );
          if (this._inflate._readableState.endEmitted) {
            this._inflate.close();
            this._inflate = null;
          } else {
            this._inflate[kTotalLength] = 0;
            this._inflate[kBuffers] = [];
            if (fin && this.params[`${endpoint}_no_context_takeover`]) {
              this._inflate.reset();
            }
          }
          callback(null, data2);
        });
      }
      /**
       * Compress data.
       *
       * @param {(Buffer|String)} data Data to compress
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @private
       */
      _compress(data, fin, callback) {
        const endpoint = this._isServer ? "server" : "client";
        if (!this._deflate) {
          const key = `${endpoint}_max_window_bits`;
          const windowBits = typeof this.params[key] !== "number" ? zlib.Z_DEFAULT_WINDOWBITS : this.params[key];
          this._deflate = zlib.createDeflateRaw({
            ...this._options.zlibDeflateOptions,
            windowBits
          });
          this._deflate[kTotalLength] = 0;
          this._deflate[kBuffers] = [];
          this._deflate.on("data", deflateOnData);
        }
        this._deflate[kCallback] = callback;
        this._deflate.write(data);
        this._deflate.flush(zlib.Z_SYNC_FLUSH, () => {
          if (!this._deflate) {
            return;
          }
          let data2 = bufferUtil.concat(
            this._deflate[kBuffers],
            this._deflate[kTotalLength]
          );
          if (fin) {
            data2 = new FastBuffer(data2.buffer, data2.byteOffset, data2.length - 4);
          }
          this._deflate[kCallback] = null;
          this._deflate[kTotalLength] = 0;
          this._deflate[kBuffers] = [];
          if (fin && this.params[`${endpoint}_no_context_takeover`]) {
            this._deflate.reset();
          }
          callback(null, data2);
        });
      }
    };
    module.exports = PerMessageDeflate2;
    function deflateOnData(chunk) {
      this[kBuffers].push(chunk);
      this[kTotalLength] += chunk.length;
    }
    function inflateOnData(chunk) {
      this[kTotalLength] += chunk.length;
      if (this[kPerMessageDeflate]._maxPayload < 1 || this[kTotalLength] <= this[kPerMessageDeflate]._maxPayload) {
        this[kBuffers].push(chunk);
        return;
      }
      this[kError] = new RangeError("Max payload size exceeded");
      this[kError].code = "WS_ERR_UNSUPPORTED_MESSAGE_LENGTH";
      this[kError][kStatusCode] = 1009;
      this.removeListener("data", inflateOnData);
      this.reset();
    }
    function inflateOnError(err) {
      this[kPerMessageDeflate]._inflate = null;
      if (this[kError]) {
        this[kCallback](this[kError]);
        return;
      }
      err[kStatusCode] = 1007;
      this[kCallback](err);
    }
  }
});

// node_modules/ws/lib/validation.js
var require_validation = __commonJS({
  "node_modules/ws/lib/validation.js"(exports, module) {
    "use strict";
    var { isUtf8 } = __require("buffer");
    var { hasBlob } = require_constants();
    var tokenChars = [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      // 0 - 15
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      // 16 - 31
      0,
      1,
      0,
      1,
      1,
      1,
      1,
      1,
      0,
      0,
      1,
      1,
      0,
      1,
      1,
      0,
      // 32 - 47
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      // 48 - 63
      0,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      // 64 - 79
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      0,
      0,
      0,
      1,
      1,
      // 80 - 95
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      // 96 - 111
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      0,
      1,
      0,
      1,
      0
      // 112 - 127
    ];
    function isValidStatusCode(code) {
      return code >= 1e3 && code <= 1014 && code !== 1004 && code !== 1005 && code !== 1006 || code >= 3e3 && code <= 4999;
    }
    function _isValidUTF8(buf) {
      const len = buf.length;
      let i = 0;
      while (i < len) {
        if ((buf[i] & 128) === 0) {
          i++;
        } else if ((buf[i] & 224) === 192) {
          if (i + 1 === len || (buf[i + 1] & 192) !== 128 || (buf[i] & 254) === 192) {
            return false;
          }
          i += 2;
        } else if ((buf[i] & 240) === 224) {
          if (i + 2 >= len || (buf[i + 1] & 192) !== 128 || (buf[i + 2] & 192) !== 128 || buf[i] === 224 && (buf[i + 1] & 224) === 128 || // Overlong
          buf[i] === 237 && (buf[i + 1] & 224) === 160) {
            return false;
          }
          i += 3;
        } else if ((buf[i] & 248) === 240) {
          if (i + 3 >= len || (buf[i + 1] & 192) !== 128 || (buf[i + 2] & 192) !== 128 || (buf[i + 3] & 192) !== 128 || buf[i] === 240 && (buf[i + 1] & 240) === 128 || // Overlong
          buf[i] === 244 && buf[i + 1] > 143 || buf[i] > 244) {
            return false;
          }
          i += 4;
        } else {
          return false;
        }
      }
      return true;
    }
    function isBlob(value) {
      return hasBlob && typeof value === "object" && typeof value.arrayBuffer === "function" && typeof value.type === "string" && typeof value.stream === "function" && (value[Symbol.toStringTag] === "Blob" || value[Symbol.toStringTag] === "File");
    }
    module.exports = {
      isBlob,
      isValidStatusCode,
      isValidUTF8: _isValidUTF8,
      tokenChars
    };
    if (isUtf8) {
      module.exports.isValidUTF8 = function(buf) {
        return buf.length < 24 ? _isValidUTF8(buf) : isUtf8(buf);
      };
    } else if (!process.env.WS_NO_UTF_8_VALIDATE) {
      try {
        const isValidUTF8 = __require("utf-8-validate");
        module.exports.isValidUTF8 = function(buf) {
          return buf.length < 32 ? _isValidUTF8(buf) : isValidUTF8(buf);
        };
      } catch (e) {
      }
    }
  }
});

// node_modules/ws/lib/receiver.js
var require_receiver = __commonJS({
  "node_modules/ws/lib/receiver.js"(exports, module) {
    "use strict";
    var { Writable } = __require("stream");
    var PerMessageDeflate2 = require_permessage_deflate();
    var {
      BINARY_TYPES,
      EMPTY_BUFFER,
      kStatusCode,
      kWebSocket
    } = require_constants();
    var { concat, toArrayBuffer, unmask } = require_buffer_util();
    var { isValidStatusCode, isValidUTF8 } = require_validation();
    var FastBuffer = Buffer[Symbol.species];
    var GET_INFO = 0;
    var GET_PAYLOAD_LENGTH_16 = 1;
    var GET_PAYLOAD_LENGTH_64 = 2;
    var GET_MASK = 3;
    var GET_DATA = 4;
    var INFLATING = 5;
    var DEFER_EVENT = 6;
    var Receiver2 = class extends Writable {
      /**
       * Creates a Receiver instance.
       *
       * @param {Object} [options] Options object
       * @param {Boolean} [options.allowSynchronousEvents=true] Specifies whether
       *     any of the `'message'`, `'ping'`, and `'pong'` events can be emitted
       *     multiple times in the same tick
       * @param {String} [options.binaryType=nodebuffer] The type for binary data
       * @param {Object} [options.extensions] An object containing the negotiated
       *     extensions
       * @param {Boolean} [options.isServer=false] Specifies whether to operate in
       *     client or server mode
       * @param {Number} [options.maxBufferedChunks=0] The maximum number of
       *     buffered data chunks
       * @param {Number} [options.maxFragments=0] The maximum number of message
       *     fragments
       * @param {Number} [options.maxPayload=0] The maximum allowed message length
       * @param {Boolean} [options.skipUTF8Validation=false] Specifies whether or
       *     not to skip UTF-8 validation for text and close messages
       */
      constructor(options = {}) {
        super();
        this._allowSynchronousEvents = options.allowSynchronousEvents !== void 0 ? options.allowSynchronousEvents : true;
        this._binaryType = options.binaryType || BINARY_TYPES[0];
        this._extensions = options.extensions || {};
        this._isServer = !!options.isServer;
        this._maxBufferedChunks = options.maxBufferedChunks | 0;
        this._maxFragments = options.maxFragments | 0;
        this._maxPayload = options.maxPayload | 0;
        this._skipUTF8Validation = !!options.skipUTF8Validation;
        this[kWebSocket] = void 0;
        this._bufferedBytes = 0;
        this._buffers = [];
        this._compressed = false;
        this._payloadLength = 0;
        this._mask = void 0;
        this._fragmented = 0;
        this._masked = false;
        this._fin = false;
        this._opcode = 0;
        this._totalPayloadLength = 0;
        this._messageLength = 0;
        this._fragments = [];
        this._errored = false;
        this._loop = false;
        this._state = GET_INFO;
      }
      /**
       * Implements `Writable.prototype._write()`.
       *
       * @param {Buffer} chunk The chunk of data to write
       * @param {String} encoding The character encoding of `chunk`
       * @param {Function} cb Callback
       * @private
       */
      _write(chunk, encoding, cb) {
        if (this._opcode === 8 && this._state == GET_INFO) return cb();
        if (this._maxBufferedChunks > 0 && this._buffers.length >= this._maxBufferedChunks) {
          cb(
            this.createError(
              RangeError,
              "Too many buffered chunks",
              false,
              1008,
              "WS_ERR_TOO_MANY_BUFFERED_PARTS"
            )
          );
          return;
        }
        this._bufferedBytes += chunk.length;
        this._buffers.push(chunk);
        this.startLoop(cb);
      }
      /**
       * Consumes `n` bytes from the buffered data.
       *
       * @param {Number} n The number of bytes to consume
       * @return {Buffer} The consumed bytes
       * @private
       */
      consume(n) {
        this._bufferedBytes -= n;
        if (n === this._buffers[0].length) return this._buffers.shift();
        if (n < this._buffers[0].length) {
          const buf = this._buffers[0];
          this._buffers[0] = new FastBuffer(
            buf.buffer,
            buf.byteOffset + n,
            buf.length - n
          );
          return new FastBuffer(buf.buffer, buf.byteOffset, n);
        }
        const dst = Buffer.allocUnsafe(n);
        do {
          const buf = this._buffers[0];
          const offset = dst.length - n;
          if (n >= buf.length) {
            dst.set(this._buffers.shift(), offset);
          } else {
            dst.set(new Uint8Array(buf.buffer, buf.byteOffset, n), offset);
            this._buffers[0] = new FastBuffer(
              buf.buffer,
              buf.byteOffset + n,
              buf.length - n
            );
          }
          n -= buf.length;
        } while (n > 0);
        return dst;
      }
      /**
       * Starts the parsing loop.
       *
       * @param {Function} cb Callback
       * @private
       */
      startLoop(cb) {
        this._loop = true;
        do {
          switch (this._state) {
            case GET_INFO:
              this.getInfo(cb);
              break;
            case GET_PAYLOAD_LENGTH_16:
              this.getPayloadLength16(cb);
              break;
            case GET_PAYLOAD_LENGTH_64:
              this.getPayloadLength64(cb);
              break;
            case GET_MASK:
              this.getMask();
              break;
            case GET_DATA:
              this.getData(cb);
              break;
            case INFLATING:
            case DEFER_EVENT:
              this._loop = false;
              return;
          }
        } while (this._loop);
        if (!this._errored) cb();
      }
      /**
       * Reads the first two bytes of a frame.
       *
       * @param {Function} cb Callback
       * @private
       */
      getInfo(cb) {
        if (this._bufferedBytes < 2) {
          this._loop = false;
          return;
        }
        const buf = this.consume(2);
        if ((buf[0] & 48) !== 0) {
          const error = this.createError(
            RangeError,
            "RSV2 and RSV3 must be clear",
            true,
            1002,
            "WS_ERR_UNEXPECTED_RSV_2_3"
          );
          cb(error);
          return;
        }
        const compressed = (buf[0] & 64) === 64;
        if (compressed && !this._extensions[PerMessageDeflate2.extensionName]) {
          const error = this.createError(
            RangeError,
            "RSV1 must be clear",
            true,
            1002,
            "WS_ERR_UNEXPECTED_RSV_1"
          );
          cb(error);
          return;
        }
        this._fin = (buf[0] & 128) === 128;
        this._opcode = buf[0] & 15;
        this._payloadLength = buf[1] & 127;
        if (this._opcode === 0) {
          if (compressed) {
            const error = this.createError(
              RangeError,
              "RSV1 must be clear",
              true,
              1002,
              "WS_ERR_UNEXPECTED_RSV_1"
            );
            cb(error);
            return;
          }
          if (!this._fragmented) {
            const error = this.createError(
              RangeError,
              "invalid opcode 0",
              true,
              1002,
              "WS_ERR_INVALID_OPCODE"
            );
            cb(error);
            return;
          }
          this._opcode = this._fragmented;
        } else if (this._opcode === 1 || this._opcode === 2) {
          if (this._fragmented) {
            const error = this.createError(
              RangeError,
              `invalid opcode ${this._opcode}`,
              true,
              1002,
              "WS_ERR_INVALID_OPCODE"
            );
            cb(error);
            return;
          }
          this._compressed = compressed;
        } else if (this._opcode > 7 && this._opcode < 11) {
          if (!this._fin) {
            const error = this.createError(
              RangeError,
              "FIN must be set",
              true,
              1002,
              "WS_ERR_EXPECTED_FIN"
            );
            cb(error);
            return;
          }
          if (compressed) {
            const error = this.createError(
              RangeError,
              "RSV1 must be clear",
              true,
              1002,
              "WS_ERR_UNEXPECTED_RSV_1"
            );
            cb(error);
            return;
          }
          if (this._payloadLength > 125 || this._opcode === 8 && this._payloadLength === 1) {
            const error = this.createError(
              RangeError,
              `invalid payload length ${this._payloadLength}`,
              true,
              1002,
              "WS_ERR_INVALID_CONTROL_PAYLOAD_LENGTH"
            );
            cb(error);
            return;
          }
        } else {
          const error = this.createError(
            RangeError,
            `invalid opcode ${this._opcode}`,
            true,
            1002,
            "WS_ERR_INVALID_OPCODE"
          );
          cb(error);
          return;
        }
        if (!this._fin && !this._fragmented) this._fragmented = this._opcode;
        this._masked = (buf[1] & 128) === 128;
        if (this._isServer) {
          if (!this._masked) {
            const error = this.createError(
              RangeError,
              "MASK must be set",
              true,
              1002,
              "WS_ERR_EXPECTED_MASK"
            );
            cb(error);
            return;
          }
        } else if (this._masked) {
          const error = this.createError(
            RangeError,
            "MASK must be clear",
            true,
            1002,
            "WS_ERR_UNEXPECTED_MASK"
          );
          cb(error);
          return;
        }
        if (this._payloadLength === 126) this._state = GET_PAYLOAD_LENGTH_16;
        else if (this._payloadLength === 127) this._state = GET_PAYLOAD_LENGTH_64;
        else this.haveLength(cb);
      }
      /**
       * Gets extended payload length (7+16).
       *
       * @param {Function} cb Callback
       * @private
       */
      getPayloadLength16(cb) {
        if (this._bufferedBytes < 2) {
          this._loop = false;
          return;
        }
        this._payloadLength = this.consume(2).readUInt16BE(0);
        this.haveLength(cb);
      }
      /**
       * Gets extended payload length (7+64).
       *
       * @param {Function} cb Callback
       * @private
       */
      getPayloadLength64(cb) {
        if (this._bufferedBytes < 8) {
          this._loop = false;
          return;
        }
        const buf = this.consume(8);
        const num = buf.readUInt32BE(0);
        if (num > Math.pow(2, 53 - 32) - 1) {
          const error = this.createError(
            RangeError,
            "Unsupported WebSocket frame: payload length > 2^53 - 1",
            false,
            1009,
            "WS_ERR_UNSUPPORTED_DATA_PAYLOAD_LENGTH"
          );
          cb(error);
          return;
        }
        this._payloadLength = num * Math.pow(2, 32) + buf.readUInt32BE(4);
        this.haveLength(cb);
      }
      /**
       * Payload length has been read.
       *
       * @param {Function} cb Callback
       * @private
       */
      haveLength(cb) {
        if (this._payloadLength && this._opcode < 8) {
          this._totalPayloadLength += this._payloadLength;
          if (this._totalPayloadLength > this._maxPayload && this._maxPayload > 0) {
            const error = this.createError(
              RangeError,
              "Max payload size exceeded",
              false,
              1009,
              "WS_ERR_UNSUPPORTED_MESSAGE_LENGTH"
            );
            cb(error);
            return;
          }
        }
        if (this._masked) this._state = GET_MASK;
        else this._state = GET_DATA;
      }
      /**
       * Reads mask bytes.
       *
       * @private
       */
      getMask() {
        if (this._bufferedBytes < 4) {
          this._loop = false;
          return;
        }
        this._mask = this.consume(4);
        this._state = GET_DATA;
      }
      /**
       * Reads data bytes.
       *
       * @param {Function} cb Callback
       * @private
       */
      getData(cb) {
        let data = EMPTY_BUFFER;
        if (this._payloadLength) {
          if (this._bufferedBytes < this._payloadLength) {
            this._loop = false;
            return;
          }
          data = this.consume(this._payloadLength);
          if (this._masked && (this._mask[0] | this._mask[1] | this._mask[2] | this._mask[3]) !== 0) {
            unmask(data, this._mask);
          }
        }
        if (this._opcode > 7) {
          this.controlMessage(data, cb);
          return;
        }
        if (this._compressed) {
          this._state = INFLATING;
          this.decompress(data, cb);
          return;
        }
        if (data.length) {
          if (this._maxFragments > 0 && this._fragments.length >= this._maxFragments) {
            const error = this.createError(
              RangeError,
              "Too many message fragments",
              false,
              1008,
              "WS_ERR_TOO_MANY_BUFFERED_PARTS"
            );
            cb(error);
            return;
          }
          this._messageLength = this._totalPayloadLength;
          this._fragments.push(data);
        }
        this.dataMessage(cb);
      }
      /**
       * Decompresses data.
       *
       * @param {Buffer} data Compressed data
       * @param {Function} cb Callback
       * @private
       */
      decompress(data, cb) {
        const perMessageDeflate = this._extensions[PerMessageDeflate2.extensionName];
        perMessageDeflate.decompress(data, this._fin, (err, buf) => {
          if (err) return cb(err);
          if (buf.length) {
            this._messageLength += buf.length;
            if (this._messageLength > this._maxPayload && this._maxPayload > 0) {
              const error = this.createError(
                RangeError,
                "Max payload size exceeded",
                false,
                1009,
                "WS_ERR_UNSUPPORTED_MESSAGE_LENGTH"
              );
              cb(error);
              return;
            }
            if (this._maxFragments > 0 && this._fragments.length >= this._maxFragments) {
              const error = this.createError(
                RangeError,
                "Too many message fragments",
                false,
                1008,
                "WS_ERR_TOO_MANY_BUFFERED_PARTS"
              );
              cb(error);
              return;
            }
            this._fragments.push(buf);
          }
          this.dataMessage(cb);
          if (this._state === GET_INFO) this.startLoop(cb);
        });
      }
      /**
       * Handles a data message.
       *
       * @param {Function} cb Callback
       * @private
       */
      dataMessage(cb) {
        if (!this._fin) {
          this._state = GET_INFO;
          return;
        }
        const messageLength = this._messageLength;
        const fragments = this._fragments;
        this._totalPayloadLength = 0;
        this._messageLength = 0;
        this._fragmented = 0;
        this._fragments = [];
        if (this._opcode === 2) {
          let data;
          if (this._binaryType === "nodebuffer") {
            data = concat(fragments, messageLength);
          } else if (this._binaryType === "arraybuffer") {
            data = toArrayBuffer(concat(fragments, messageLength));
          } else if (this._binaryType === "blob") {
            data = new Blob(fragments);
          } else {
            data = fragments;
          }
          if (this._allowSynchronousEvents) {
            this.emit("message", data, true);
            this._state = GET_INFO;
          } else {
            this._state = DEFER_EVENT;
            setImmediate(() => {
              this.emit("message", data, true);
              this._state = GET_INFO;
              this.startLoop(cb);
            });
          }
        } else {
          const buf = concat(fragments, messageLength);
          if (!this._skipUTF8Validation && !isValidUTF8(buf)) {
            const error = this.createError(
              Error,
              "invalid UTF-8 sequence",
              true,
              1007,
              "WS_ERR_INVALID_UTF8"
            );
            cb(error);
            return;
          }
          if (this._state === INFLATING || this._allowSynchronousEvents) {
            this.emit("message", buf, false);
            this._state = GET_INFO;
          } else {
            this._state = DEFER_EVENT;
            setImmediate(() => {
              this.emit("message", buf, false);
              this._state = GET_INFO;
              this.startLoop(cb);
            });
          }
        }
      }
      /**
       * Handles a control message.
       *
       * @param {Buffer} data Data to handle
       * @return {(Error|RangeError|undefined)} A possible error
       * @private
       */
      controlMessage(data, cb) {
        if (this._opcode === 8) {
          if (data.length === 0) {
            this._loop = false;
            this.emit("conclude", 1005, EMPTY_BUFFER);
            this.end();
          } else {
            const code = data.readUInt16BE(0);
            if (!isValidStatusCode(code)) {
              const error = this.createError(
                RangeError,
                `invalid status code ${code}`,
                true,
                1002,
                "WS_ERR_INVALID_CLOSE_CODE"
              );
              cb(error);
              return;
            }
            const buf = new FastBuffer(
              data.buffer,
              data.byteOffset + 2,
              data.length - 2
            );
            if (!this._skipUTF8Validation && !isValidUTF8(buf)) {
              const error = this.createError(
                Error,
                "invalid UTF-8 sequence",
                true,
                1007,
                "WS_ERR_INVALID_UTF8"
              );
              cb(error);
              return;
            }
            this._loop = false;
            this.emit("conclude", code, buf);
            this.end();
          }
          this._state = GET_INFO;
          return;
        }
        if (this._allowSynchronousEvents) {
          this.emit(this._opcode === 9 ? "ping" : "pong", data);
          this._state = GET_INFO;
        } else {
          this._state = DEFER_EVENT;
          setImmediate(() => {
            this.emit(this._opcode === 9 ? "ping" : "pong", data);
            this._state = GET_INFO;
            this.startLoop(cb);
          });
        }
      }
      /**
       * Builds an error object.
       *
       * @param {function(new:Error|RangeError)} ErrorCtor The error constructor
       * @param {String} message The error message
       * @param {Boolean} prefix Specifies whether or not to add a default prefix to
       *     `message`
       * @param {Number} statusCode The status code
       * @param {String} errorCode The exposed error code
       * @return {(Error|RangeError)} The error
       * @private
       */
      createError(ErrorCtor, message, prefix, statusCode, errorCode) {
        this._loop = false;
        this._errored = true;
        const err = new ErrorCtor(
          prefix ? `Invalid WebSocket frame: ${message}` : message
        );
        Error.captureStackTrace(err, this.createError);
        err.code = errorCode;
        err[kStatusCode] = statusCode;
        return err;
      }
    };
    module.exports = Receiver2;
  }
});

// node_modules/ws/lib/sender.js
var require_sender = __commonJS({
  "node_modules/ws/lib/sender.js"(exports, module) {
    "use strict";
    var { Duplex } = __require("stream");
    var { randomFillSync } = __require("crypto");
    var {
      types: { isUint8Array }
    } = __require("util");
    var PerMessageDeflate2 = require_permessage_deflate();
    var { EMPTY_BUFFER, kWebSocket, NOOP } = require_constants();
    var { isBlob, isValidStatusCode } = require_validation();
    var { mask: applyMask, toBuffer } = require_buffer_util();
    var kByteLength = /* @__PURE__ */ Symbol("kByteLength");
    var maskBuffer = Buffer.alloc(4);
    var RANDOM_POOL_SIZE = 8 * 1024;
    var randomPool;
    var randomPoolPointer = RANDOM_POOL_SIZE;
    var DEFAULT = 0;
    var DEFLATING = 1;
    var GET_BLOB_DATA = 2;
    var Sender2 = class _Sender {
      /**
       * Creates a Sender instance.
       *
       * @param {Duplex} socket The connection socket
       * @param {Object} [extensions] An object containing the negotiated extensions
       * @param {Function} [generateMask] The function used to generate the masking
       *     key
       */
      constructor(socket, extensions, generateMask) {
        this._extensions = extensions || {};
        if (generateMask) {
          this._generateMask = generateMask;
          this._maskBuffer = Buffer.alloc(4);
        }
        this._socket = socket;
        this._firstFragment = true;
        this._compress = false;
        this._bufferedBytes = 0;
        this._queue = [];
        this._state = DEFAULT;
        this.onerror = NOOP;
        this[kWebSocket] = void 0;
      }
      /**
       * Frames a piece of data according to the HyBi WebSocket protocol.
       *
       * @param {(Buffer|String)} data The data to frame
       * @param {Object} options Options object
       * @param {Boolean} [options.fin=false] Specifies whether or not to set the
       *     FIN bit
       * @param {Function} [options.generateMask] The function used to generate the
       *     masking key
       * @param {Boolean} [options.mask=false] Specifies whether or not to mask
       *     `data`
       * @param {Buffer} [options.maskBuffer] The buffer used to store the masking
       *     key
       * @param {Number} options.opcode The opcode
       * @param {Boolean} [options.readOnly=false] Specifies whether `data` can be
       *     modified
       * @param {Boolean} [options.rsv1=false] Specifies whether or not to set the
       *     RSV1 bit
       * @return {(Buffer|String)[]} The framed data
       * @public
       */
      static frame(data, options) {
        let mask;
        let merge = false;
        let offset = 2;
        let skipMasking = false;
        if (options.mask) {
          mask = options.maskBuffer || maskBuffer;
          if (options.generateMask) {
            options.generateMask(mask);
          } else {
            if (randomPoolPointer === RANDOM_POOL_SIZE) {
              if (randomPool === void 0) {
                randomPool = Buffer.alloc(RANDOM_POOL_SIZE);
              }
              randomFillSync(randomPool, 0, RANDOM_POOL_SIZE);
              randomPoolPointer = 0;
            }
            mask[0] = randomPool[randomPoolPointer++];
            mask[1] = randomPool[randomPoolPointer++];
            mask[2] = randomPool[randomPoolPointer++];
            mask[3] = randomPool[randomPoolPointer++];
          }
          skipMasking = (mask[0] | mask[1] | mask[2] | mask[3]) === 0;
          offset = 6;
        }
        let dataLength;
        if (typeof data === "string") {
          if ((!options.mask || skipMasking) && options[kByteLength] !== void 0) {
            dataLength = options[kByteLength];
          } else {
            data = Buffer.from(data);
            dataLength = data.length;
          }
        } else {
          dataLength = data.length;
          merge = options.mask && options.readOnly && !skipMasking;
        }
        let payloadLength = dataLength;
        if (dataLength >= 65536) {
          offset += 8;
          payloadLength = 127;
        } else if (dataLength > 125) {
          offset += 2;
          payloadLength = 126;
        }
        const target = Buffer.allocUnsafe(merge ? dataLength + offset : offset);
        target[0] = options.fin ? options.opcode | 128 : options.opcode;
        if (options.rsv1) target[0] |= 64;
        target[1] = payloadLength;
        if (payloadLength === 126) {
          target.writeUInt16BE(dataLength, 2);
        } else if (payloadLength === 127) {
          target[2] = target[3] = 0;
          target.writeUIntBE(dataLength, 4, 6);
        }
        if (!options.mask) return [target, data];
        target[1] |= 128;
        target[offset - 4] = mask[0];
        target[offset - 3] = mask[1];
        target[offset - 2] = mask[2];
        target[offset - 1] = mask[3];
        if (skipMasking) return [target, data];
        if (merge) {
          applyMask(data, mask, target, offset, dataLength);
          return [target];
        }
        applyMask(data, mask, data, 0, dataLength);
        return [target, data];
      }
      /**
       * Sends a close message to the other peer.
       *
       * @param {Number} [code] The status code component of the body
       * @param {(String|Buffer)} [data] The message component of the body
       * @param {Boolean} [mask=false] Specifies whether or not to mask the message
       * @param {Function} [cb] Callback
       * @public
       */
      close(code, data, mask, cb) {
        let buf;
        if (code === void 0) {
          buf = EMPTY_BUFFER;
        } else if (typeof code !== "number" || !isValidStatusCode(code)) {
          throw new TypeError("First argument must be a valid error code number");
        } else if (data === void 0 || !data.length) {
          buf = Buffer.allocUnsafe(2);
          buf.writeUInt16BE(code, 0);
        } else {
          const length = Buffer.byteLength(data);
          if (length > 123) {
            throw new RangeError("The message must not be greater than 123 bytes");
          }
          buf = Buffer.allocUnsafe(2 + length);
          buf.writeUInt16BE(code, 0);
          if (typeof data === "string") {
            buf.write(data, 2);
          } else if (isUint8Array(data)) {
            buf.set(data, 2);
          } else {
            throw new TypeError("Second argument must be a string or a Uint8Array");
          }
        }
        const options = {
          [kByteLength]: buf.length,
          fin: true,
          generateMask: this._generateMask,
          mask,
          maskBuffer: this._maskBuffer,
          opcode: 8,
          readOnly: false,
          rsv1: false
        };
        if (this._state !== DEFAULT) {
          this.enqueue([this.dispatch, buf, false, options, cb]);
        } else {
          this.sendFrame(_Sender.frame(buf, options), cb);
        }
      }
      /**
       * Sends a ping message to the other peer.
       *
       * @param {*} data The message to send
       * @param {Boolean} [mask=false] Specifies whether or not to mask `data`
       * @param {Function} [cb] Callback
       * @public
       */
      ping(data, mask, cb) {
        let byteLength;
        let readOnly;
        if (typeof data === "string") {
          byteLength = Buffer.byteLength(data);
          readOnly = false;
        } else if (isBlob(data)) {
          byteLength = data.size;
          readOnly = false;
        } else {
          data = toBuffer(data);
          byteLength = data.length;
          readOnly = toBuffer.readOnly;
        }
        if (byteLength > 125) {
          throw new RangeError("The data size must not be greater than 125 bytes");
        }
        const options = {
          [kByteLength]: byteLength,
          fin: true,
          generateMask: this._generateMask,
          mask,
          maskBuffer: this._maskBuffer,
          opcode: 9,
          readOnly,
          rsv1: false
        };
        if (isBlob(data)) {
          if (this._state !== DEFAULT) {
            this.enqueue([this.getBlobData, data, false, options, cb]);
          } else {
            this.getBlobData(data, false, options, cb);
          }
        } else if (this._state !== DEFAULT) {
          this.enqueue([this.dispatch, data, false, options, cb]);
        } else {
          this.sendFrame(_Sender.frame(data, options), cb);
        }
      }
      /**
       * Sends a pong message to the other peer.
       *
       * @param {*} data The message to send
       * @param {Boolean} [mask=false] Specifies whether or not to mask `data`
       * @param {Function} [cb] Callback
       * @public
       */
      pong(data, mask, cb) {
        let byteLength;
        let readOnly;
        if (typeof data === "string") {
          byteLength = Buffer.byteLength(data);
          readOnly = false;
        } else if (isBlob(data)) {
          byteLength = data.size;
          readOnly = false;
        } else {
          data = toBuffer(data);
          byteLength = data.length;
          readOnly = toBuffer.readOnly;
        }
        if (byteLength > 125) {
          throw new RangeError("The data size must not be greater than 125 bytes");
        }
        const options = {
          [kByteLength]: byteLength,
          fin: true,
          generateMask: this._generateMask,
          mask,
          maskBuffer: this._maskBuffer,
          opcode: 10,
          readOnly,
          rsv1: false
        };
        if (isBlob(data)) {
          if (this._state !== DEFAULT) {
            this.enqueue([this.getBlobData, data, false, options, cb]);
          } else {
            this.getBlobData(data, false, options, cb);
          }
        } else if (this._state !== DEFAULT) {
          this.enqueue([this.dispatch, data, false, options, cb]);
        } else {
          this.sendFrame(_Sender.frame(data, options), cb);
        }
      }
      /**
       * Sends a data message to the other peer.
       *
       * @param {*} data The message to send
       * @param {Object} options Options object
       * @param {Boolean} [options.binary=false] Specifies whether `data` is binary
       *     or text
       * @param {Boolean} [options.compress=false] Specifies whether or not to
       *     compress `data`
       * @param {Boolean} [options.fin=false] Specifies whether the fragment is the
       *     last one
       * @param {Boolean} [options.mask=false] Specifies whether or not to mask
       *     `data`
       * @param {Function} [cb] Callback
       * @public
       */
      send(data, options, cb) {
        const perMessageDeflate = this._extensions[PerMessageDeflate2.extensionName];
        let opcode = options.binary ? 2 : 1;
        let rsv1 = options.compress;
        let byteLength;
        let readOnly;
        if (typeof data === "string") {
          byteLength = Buffer.byteLength(data);
          readOnly = false;
        } else if (isBlob(data)) {
          byteLength = data.size;
          readOnly = false;
        } else {
          data = toBuffer(data);
          byteLength = data.length;
          readOnly = toBuffer.readOnly;
        }
        if (this._firstFragment) {
          this._firstFragment = false;
          if (rsv1 && perMessageDeflate && perMessageDeflate.params[perMessageDeflate._isServer ? "server_no_context_takeover" : "client_no_context_takeover"]) {
            rsv1 = byteLength >= perMessageDeflate._threshold;
          }
          this._compress = rsv1;
        } else {
          rsv1 = false;
          opcode = 0;
        }
        if (options.fin) this._firstFragment = true;
        const opts = {
          [kByteLength]: byteLength,
          fin: options.fin,
          generateMask: this._generateMask,
          mask: options.mask,
          maskBuffer: this._maskBuffer,
          opcode,
          readOnly,
          rsv1
        };
        if (isBlob(data)) {
          if (this._state !== DEFAULT) {
            this.enqueue([this.getBlobData, data, this._compress, opts, cb]);
          } else {
            this.getBlobData(data, this._compress, opts, cb);
          }
        } else if (this._state !== DEFAULT) {
          this.enqueue([this.dispatch, data, this._compress, opts, cb]);
        } else {
          this.dispatch(data, this._compress, opts, cb);
        }
      }
      /**
       * Gets the contents of a blob as binary data.
       *
       * @param {Blob} blob The blob
       * @param {Boolean} [compress=false] Specifies whether or not to compress
       *     the data
       * @param {Object} options Options object
       * @param {Boolean} [options.fin=false] Specifies whether or not to set the
       *     FIN bit
       * @param {Function} [options.generateMask] The function used to generate the
       *     masking key
       * @param {Boolean} [options.mask=false] Specifies whether or not to mask
       *     `data`
       * @param {Buffer} [options.maskBuffer] The buffer used to store the masking
       *     key
       * @param {Number} options.opcode The opcode
       * @param {Boolean} [options.readOnly=false] Specifies whether `data` can be
       *     modified
       * @param {Boolean} [options.rsv1=false] Specifies whether or not to set the
       *     RSV1 bit
       * @param {Function} [cb] Callback
       * @private
       */
      getBlobData(blob, compress, options, cb) {
        this._bufferedBytes += options[kByteLength];
        this._state = GET_BLOB_DATA;
        blob.arrayBuffer().then((arrayBuffer) => {
          if (this._socket.destroyed) {
            const err = new Error(
              "The socket was closed while the blob was being read"
            );
            process.nextTick(callCallbacks, this, err, cb);
            return;
          }
          this._bufferedBytes -= options[kByteLength];
          const data = toBuffer(arrayBuffer);
          if (!compress) {
            this._state = DEFAULT;
            this.sendFrame(_Sender.frame(data, options), cb);
            this.dequeue();
          } else {
            this.dispatch(data, compress, options, cb);
          }
        }).catch((err) => {
          process.nextTick(onError, this, err, cb);
        });
      }
      /**
       * Dispatches a message.
       *
       * @param {(Buffer|String)} data The message to send
       * @param {Boolean} [compress=false] Specifies whether or not to compress
       *     `data`
       * @param {Object} options Options object
       * @param {Boolean} [options.fin=false] Specifies whether or not to set the
       *     FIN bit
       * @param {Function} [options.generateMask] The function used to generate the
       *     masking key
       * @param {Boolean} [options.mask=false] Specifies whether or not to mask
       *     `data`
       * @param {Buffer} [options.maskBuffer] The buffer used to store the masking
       *     key
       * @param {Number} options.opcode The opcode
       * @param {Boolean} [options.readOnly=false] Specifies whether `data` can be
       *     modified
       * @param {Boolean} [options.rsv1=false] Specifies whether or not to set the
       *     RSV1 bit
       * @param {Function} [cb] Callback
       * @private
       */
      dispatch(data, compress, options, cb) {
        if (!compress) {
          this.sendFrame(_Sender.frame(data, options), cb);
          return;
        }
        const perMessageDeflate = this._extensions[PerMessageDeflate2.extensionName];
        this._bufferedBytes += options[kByteLength];
        this._state = DEFLATING;
        perMessageDeflate.compress(data, options.fin, (_, buf) => {
          if (this._socket.destroyed) {
            const err = new Error(
              "The socket was closed while data was being compressed"
            );
            callCallbacks(this, err, cb);
            return;
          }
          this._bufferedBytes -= options[kByteLength];
          this._state = DEFAULT;
          options.readOnly = false;
          this.sendFrame(_Sender.frame(buf, options), cb);
          this.dequeue();
        });
      }
      /**
       * Executes queued send operations.
       *
       * @private
       */
      dequeue() {
        while (this._state === DEFAULT && this._queue.length) {
          const params = this._queue.shift();
          this._bufferedBytes -= params[3][kByteLength];
          Reflect.apply(params[0], this, params.slice(1));
        }
      }
      /**
       * Enqueues a send operation.
       *
       * @param {Array} params Send operation parameters.
       * @private
       */
      enqueue(params) {
        this._bufferedBytes += params[3][kByteLength];
        this._queue.push(params);
      }
      /**
       * Sends a frame.
       *
       * @param {(Buffer | String)[]} list The frame to send
       * @param {Function} [cb] Callback
       * @private
       */
      sendFrame(list, cb) {
        if (list.length === 2) {
          this._socket.cork();
          this._socket.write(list[0]);
          this._socket.write(list[1], cb);
          this._socket.uncork();
        } else {
          this._socket.write(list[0], cb);
        }
      }
    };
    module.exports = Sender2;
    function callCallbacks(sender, err, cb) {
      if (typeof cb === "function") cb(err);
      for (let i = 0; i < sender._queue.length; i++) {
        const params = sender._queue[i];
        const callback = params[params.length - 1];
        if (typeof callback === "function") callback(err);
      }
    }
    function onError(sender, err, cb) {
      callCallbacks(sender, err, cb);
      sender.onerror(err);
    }
  }
});

// node_modules/ws/lib/event-target.js
var require_event_target = __commonJS({
  "node_modules/ws/lib/event-target.js"(exports, module) {
    "use strict";
    var { kForOnEventAttribute, kListener } = require_constants();
    var kCode = /* @__PURE__ */ Symbol("kCode");
    var kData = /* @__PURE__ */ Symbol("kData");
    var kError = /* @__PURE__ */ Symbol("kError");
    var kMessage = /* @__PURE__ */ Symbol("kMessage");
    var kReason = /* @__PURE__ */ Symbol("kReason");
    var kTarget = /* @__PURE__ */ Symbol("kTarget");
    var kType = /* @__PURE__ */ Symbol("kType");
    var kWasClean = /* @__PURE__ */ Symbol("kWasClean");
    var Event = class {
      /**
       * Create a new `Event`.
       *
       * @param {String} type The name of the event
       * @throws {TypeError} If the `type` argument is not specified
       */
      constructor(type) {
        this[kTarget] = null;
        this[kType] = type;
      }
      /**
       * @type {*}
       */
      get target() {
        return this[kTarget];
      }
      /**
       * @type {String}
       */
      get type() {
        return this[kType];
      }
    };
    Object.defineProperty(Event.prototype, "target", { enumerable: true });
    Object.defineProperty(Event.prototype, "type", { enumerable: true });
    var CloseEvent = class extends Event {
      /**
       * Create a new `CloseEvent`.
       *
       * @param {String} type The name of the event
       * @param {Object} [options] A dictionary object that allows for setting
       *     attributes via object members of the same name
       * @param {Number} [options.code=0] The status code explaining why the
       *     connection was closed
       * @param {String} [options.reason=''] A human-readable string explaining why
       *     the connection was closed
       * @param {Boolean} [options.wasClean=false] Indicates whether or not the
       *     connection was cleanly closed
       */
      constructor(type, options = {}) {
        super(type);
        this[kCode] = options.code === void 0 ? 0 : options.code;
        this[kReason] = options.reason === void 0 ? "" : options.reason;
        this[kWasClean] = options.wasClean === void 0 ? false : options.wasClean;
      }
      /**
       * @type {Number}
       */
      get code() {
        return this[kCode];
      }
      /**
       * @type {String}
       */
      get reason() {
        return this[kReason];
      }
      /**
       * @type {Boolean}
       */
      get wasClean() {
        return this[kWasClean];
      }
    };
    Object.defineProperty(CloseEvent.prototype, "code", { enumerable: true });
    Object.defineProperty(CloseEvent.prototype, "reason", { enumerable: true });
    Object.defineProperty(CloseEvent.prototype, "wasClean", { enumerable: true });
    var ErrorEvent = class extends Event {
      /**
       * Create a new `ErrorEvent`.
       *
       * @param {String} type The name of the event
       * @param {Object} [options] A dictionary object that allows for setting
       *     attributes via object members of the same name
       * @param {*} [options.error=null] The error that generated this event
       * @param {String} [options.message=''] The error message
       */
      constructor(type, options = {}) {
        super(type);
        this[kError] = options.error === void 0 ? null : options.error;
        this[kMessage] = options.message === void 0 ? "" : options.message;
      }
      /**
       * @type {*}
       */
      get error() {
        return this[kError];
      }
      /**
       * @type {String}
       */
      get message() {
        return this[kMessage];
      }
    };
    Object.defineProperty(ErrorEvent.prototype, "error", { enumerable: true });
    Object.defineProperty(ErrorEvent.prototype, "message", { enumerable: true });
    var MessageEvent = class extends Event {
      /**
       * Create a new `MessageEvent`.
       *
       * @param {String} type The name of the event
       * @param {Object} [options] A dictionary object that allows for setting
       *     attributes via object members of the same name
       * @param {*} [options.data=null] The message content
       */
      constructor(type, options = {}) {
        super(type);
        this[kData] = options.data === void 0 ? null : options.data;
      }
      /**
       * @type {*}
       */
      get data() {
        return this[kData];
      }
    };
    Object.defineProperty(MessageEvent.prototype, "data", { enumerable: true });
    var EventTarget = {
      /**
       * Register an event listener.
       *
       * @param {String} type A string representing the event type to listen for
       * @param {(Function|Object)} handler The listener to add
       * @param {Object} [options] An options object specifies characteristics about
       *     the event listener
       * @param {Boolean} [options.once=false] A `Boolean` indicating that the
       *     listener should be invoked at most once after being added. If `true`,
       *     the listener would be automatically removed when invoked.
       * @public
       */
      addEventListener(type, handler, options = {}) {
        for (const listener of this.listeners(type)) {
          if (!options[kForOnEventAttribute] && listener[kListener] === handler && !listener[kForOnEventAttribute]) {
            return;
          }
        }
        let wrapper;
        if (type === "message") {
          wrapper = function onMessage(data, isBinary) {
            const event = new MessageEvent("message", {
              data: isBinary ? data : data.toString()
            });
            event[kTarget] = this;
            callListener(handler, this, event);
          };
        } else if (type === "close") {
          wrapper = function onClose(code, message) {
            const event = new CloseEvent("close", {
              code,
              reason: message.toString(),
              wasClean: this._closeFrameReceived && this._closeFrameSent
            });
            event[kTarget] = this;
            callListener(handler, this, event);
          };
        } else if (type === "error") {
          wrapper = function onError(error) {
            const event = new ErrorEvent("error", {
              error,
              message: error.message
            });
            event[kTarget] = this;
            callListener(handler, this, event);
          };
        } else if (type === "open") {
          wrapper = function onOpen() {
            const event = new Event("open");
            event[kTarget] = this;
            callListener(handler, this, event);
          };
        } else {
          return;
        }
        wrapper[kForOnEventAttribute] = !!options[kForOnEventAttribute];
        wrapper[kListener] = handler;
        if (options.once) {
          this.once(type, wrapper);
        } else {
          this.on(type, wrapper);
        }
      },
      /**
       * Remove an event listener.
       *
       * @param {String} type A string representing the event type to remove
       * @param {(Function|Object)} handler The listener to remove
       * @public
       */
      removeEventListener(type, handler) {
        for (const listener of this.listeners(type)) {
          if (listener[kListener] === handler && !listener[kForOnEventAttribute]) {
            this.removeListener(type, listener);
            break;
          }
        }
      }
    };
    module.exports = {
      CloseEvent,
      ErrorEvent,
      Event,
      EventTarget,
      MessageEvent
    };
    function callListener(listener, thisArg, event) {
      if (typeof listener === "object" && listener.handleEvent) {
        listener.handleEvent.call(listener, event);
      } else {
        listener.call(thisArg, event);
      }
    }
  }
});

// node_modules/ws/lib/extension.js
var require_extension = __commonJS({
  "node_modules/ws/lib/extension.js"(exports, module) {
    "use strict";
    var { tokenChars } = require_validation();
    function push(dest, name, elem) {
      if (dest[name] === void 0) dest[name] = [elem];
      else dest[name].push(elem);
    }
    function parse(header) {
      const offers = /* @__PURE__ */ Object.create(null);
      let params = /* @__PURE__ */ Object.create(null);
      let mustUnescape = false;
      let isEscaping = false;
      let inQuotes = false;
      let extensionName;
      let paramName;
      let start = -1;
      let code = -1;
      let end = -1;
      let i = 0;
      for (; i < header.length; i++) {
        code = header.charCodeAt(i);
        if (extensionName === void 0) {
          if (end === -1 && tokenChars[code] === 1) {
            if (start === -1) start = i;
          } else if (i !== 0 && (code === 32 || code === 9)) {
            if (end === -1 && start !== -1) end = i;
          } else if (code === 59 || code === 44) {
            if (start === -1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (end === -1) end = i;
            const name = header.slice(start, end);
            if (code === 44) {
              push(offers, name, params);
              params = /* @__PURE__ */ Object.create(null);
            } else {
              extensionName = name;
            }
            start = end = -1;
          } else {
            throw new SyntaxError(`Unexpected character at index ${i}`);
          }
        } else if (paramName === void 0) {
          if (end === -1 && tokenChars[code] === 1) {
            if (start === -1) start = i;
          } else if (code === 32 || code === 9) {
            if (end === -1 && start !== -1) end = i;
          } else if (code === 59 || code === 44) {
            if (start === -1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (end === -1) end = i;
            push(params, header.slice(start, end), true);
            if (code === 44) {
              push(offers, extensionName, params);
              params = /* @__PURE__ */ Object.create(null);
              extensionName = void 0;
            }
            start = end = -1;
          } else if (code === 61 && start !== -1 && end === -1) {
            paramName = header.slice(start, i);
            start = end = -1;
          } else {
            throw new SyntaxError(`Unexpected character at index ${i}`);
          }
        } else {
          if (isEscaping) {
            if (tokenChars[code] !== 1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (start === -1) start = i;
            else if (!mustUnescape) mustUnescape = true;
            isEscaping = false;
          } else if (inQuotes) {
            if (tokenChars[code] === 1) {
              if (start === -1) start = i;
            } else if (code === 34 && start !== -1) {
              inQuotes = false;
              end = i;
            } else if (code === 92) {
              isEscaping = true;
            } else {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
          } else if (code === 34 && header.charCodeAt(i - 1) === 61) {
            inQuotes = true;
          } else if (end === -1 && tokenChars[code] === 1) {
            if (start === -1) start = i;
          } else if (start !== -1 && (code === 32 || code === 9)) {
            if (end === -1) end = i;
          } else if (code === 59 || code === 44) {
            if (start === -1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (end === -1) end = i;
            let value = header.slice(start, end);
            if (mustUnescape) {
              value = value.replace(/\\/g, "");
              mustUnescape = false;
            }
            push(params, paramName, value);
            if (code === 44) {
              push(offers, extensionName, params);
              params = /* @__PURE__ */ Object.create(null);
              extensionName = void 0;
            }
            paramName = void 0;
            start = end = -1;
          } else {
            throw new SyntaxError(`Unexpected character at index ${i}`);
          }
        }
      }
      if (start === -1 || inQuotes || code === 32 || code === 9) {
        throw new SyntaxError("Unexpected end of input");
      }
      if (end === -1) end = i;
      const token = header.slice(start, end);
      if (extensionName === void 0) {
        push(offers, token, params);
      } else {
        if (paramName === void 0) {
          push(params, token, true);
        } else if (mustUnescape) {
          push(params, paramName, token.replace(/\\/g, ""));
        } else {
          push(params, paramName, token);
        }
        push(offers, extensionName, params);
      }
      return offers;
    }
    function format(extensions) {
      return Object.keys(extensions).map((extension2) => {
        let configurations = extensions[extension2];
        if (!Array.isArray(configurations)) configurations = [configurations];
        return configurations.map((params) => {
          return [extension2].concat(
            Object.keys(params).map((k) => {
              let values = params[k];
              if (!Array.isArray(values)) values = [values];
              return values.map((v) => v === true ? k : `${k}=${v}`).join("; ");
            })
          ).join("; ");
        }).join(", ");
      }).join(", ");
    }
    module.exports = { format, parse };
  }
});

// node_modules/ws/lib/websocket.js
var require_websocket = __commonJS({
  "node_modules/ws/lib/websocket.js"(exports, module) {
    "use strict";
    var EventEmitter = __require("events");
    var https = __require("https");
    var http = __require("http");
    var net = __require("net");
    var tls = __require("tls");
    var { randomBytes, createHash: createHash2 } = __require("crypto");
    var { Duplex, Readable } = __require("stream");
    var { URL: URL2 } = __require("url");
    var PerMessageDeflate2 = require_permessage_deflate();
    var Receiver2 = require_receiver();
    var Sender2 = require_sender();
    var { isBlob } = require_validation();
    var {
      BINARY_TYPES,
      CLOSE_TIMEOUT,
      EMPTY_BUFFER,
      GUID,
      kForOnEventAttribute,
      kListener,
      kStatusCode,
      kWebSocket,
      NOOP
    } = require_constants();
    var {
      EventTarget: { addEventListener, removeEventListener }
    } = require_event_target();
    var { format, parse } = require_extension();
    var { toBuffer } = require_buffer_util();
    var kAborted = /* @__PURE__ */ Symbol("kAborted");
    var protocolVersions = [8, 13];
    var readyStates = ["CONNECTING", "OPEN", "CLOSING", "CLOSED"];
    var subprotocolRegex = /^[!#$%&'*+\-.0-9A-Z^_`|a-z~]+$/;
    var WebSocket2 = class _WebSocket extends EventEmitter {
      /**
       * Create a new `WebSocket`.
       *
       * @param {(String|URL)} address The URL to which to connect
       * @param {(String|String[])} [protocols] The subprotocols
       * @param {Object} [options] Connection options
       */
      constructor(address, protocols, options) {
        super();
        this._binaryType = BINARY_TYPES[0];
        this._closeCode = 1006;
        this._closeFrameReceived = false;
        this._closeFrameSent = false;
        this._closeMessage = EMPTY_BUFFER;
        this._closeTimer = null;
        this._errorEmitted = false;
        this._extensions = {};
        this._paused = false;
        this._protocol = "";
        this._readyState = _WebSocket.CONNECTING;
        this._receiver = null;
        this._sender = null;
        this._socket = null;
        if (address !== null) {
          this._bufferedAmount = 0;
          this._isServer = false;
          this._redirects = 0;
          if (protocols === void 0) {
            protocols = [];
          } else if (!Array.isArray(protocols)) {
            if (typeof protocols === "object" && protocols !== null) {
              options = protocols;
              protocols = [];
            } else {
              protocols = [protocols];
            }
          }
          initAsClient(this, address, protocols, options);
        } else {
          this._autoPong = options.autoPong;
          this._closeTimeout = options.closeTimeout;
          this._isServer = true;
        }
      }
      /**
       * For historical reasons, the custom "nodebuffer" type is used by the default
       * instead of "blob".
       *
       * @type {String}
       */
      get binaryType() {
        return this._binaryType;
      }
      set binaryType(type) {
        if (!BINARY_TYPES.includes(type)) return;
        this._binaryType = type;
        if (this._receiver) this._receiver._binaryType = type;
      }
      /**
       * @type {Number}
       */
      get bufferedAmount() {
        if (!this._socket) return this._bufferedAmount;
        return this._socket._writableState.length + this._sender._bufferedBytes;
      }
      /**
       * @type {String}
       */
      get extensions() {
        return Object.keys(this._extensions).join();
      }
      /**
       * @type {Boolean}
       */
      get isPaused() {
        return this._paused;
      }
      /**
       * @type {Function}
       */
      /* istanbul ignore next */
      get onclose() {
        return null;
      }
      /**
       * @type {Function}
       */
      /* istanbul ignore next */
      get onerror() {
        return null;
      }
      /**
       * @type {Function}
       */
      /* istanbul ignore next */
      get onopen() {
        return null;
      }
      /**
       * @type {Function}
       */
      /* istanbul ignore next */
      get onmessage() {
        return null;
      }
      /**
       * @type {String}
       */
      get protocol() {
        return this._protocol;
      }
      /**
       * @type {Number}
       */
      get readyState() {
        return this._readyState;
      }
      /**
       * @type {String}
       */
      get url() {
        return this._url;
      }
      /**
       * Set up the socket and the internal resources.
       *
       * @param {Duplex} socket The network socket between the server and client
       * @param {Buffer} head The first packet of the upgraded stream
       * @param {Object} options Options object
       * @param {Boolean} [options.allowSynchronousEvents=false] Specifies whether
       *     any of the `'message'`, `'ping'`, and `'pong'` events can be emitted
       *     multiple times in the same tick
       * @param {Function} [options.generateMask] The function used to generate the
       *     masking key
       * @param {Number} [options.maxBufferedChunks=0] The maximum number of
       *     buffered data chunks
       * @param {Number} [options.maxFragments=0] The maximum number of message
       *     fragments
       * @param {Number} [options.maxPayload=0] The maximum allowed message size
       * @param {Boolean} [options.skipUTF8Validation=false] Specifies whether or
       *     not to skip UTF-8 validation for text and close messages
       * @private
       */
      setSocket(socket, head, options) {
        const receiver = new Receiver2({
          allowSynchronousEvents: options.allowSynchronousEvents,
          binaryType: this.binaryType,
          extensions: this._extensions,
          isServer: this._isServer,
          maxBufferedChunks: options.maxBufferedChunks,
          maxFragments: options.maxFragments,
          maxPayload: options.maxPayload,
          skipUTF8Validation: options.skipUTF8Validation
        });
        const sender = new Sender2(socket, this._extensions, options.generateMask);
        this._receiver = receiver;
        this._sender = sender;
        this._socket = socket;
        receiver[kWebSocket] = this;
        sender[kWebSocket] = this;
        socket[kWebSocket] = this;
        receiver.on("conclude", receiverOnConclude);
        receiver.on("drain", receiverOnDrain);
        receiver.on("error", receiverOnError);
        receiver.on("message", receiverOnMessage);
        receiver.on("ping", receiverOnPing);
        receiver.on("pong", receiverOnPong);
        sender.onerror = senderOnError;
        if (socket.setTimeout) socket.setTimeout(0);
        if (socket.setNoDelay) socket.setNoDelay();
        if (head.length > 0) socket.unshift(head);
        socket.on("close", socketOnClose);
        socket.on("data", socketOnData);
        socket.on("end", socketOnEnd);
        socket.on("error", socketOnError);
        this._readyState = _WebSocket.OPEN;
        this.emit("open");
      }
      /**
       * Emit the `'close'` event.
       *
       * @private
       */
      emitClose() {
        if (!this._socket) {
          this._readyState = _WebSocket.CLOSED;
          this.emit("close", this._closeCode, this._closeMessage);
          return;
        }
        if (this._extensions[PerMessageDeflate2.extensionName]) {
          this._extensions[PerMessageDeflate2.extensionName].cleanup();
        }
        this._receiver.removeAllListeners();
        this._readyState = _WebSocket.CLOSED;
        this.emit("close", this._closeCode, this._closeMessage);
      }
      /**
       * Start a closing handshake.
       *
       *          +----------+   +-----------+   +----------+
       *     - - -|ws.close()|-->|close frame|-->|ws.close()|- - -
       *    |     +----------+   +-----------+   +----------+     |
       *          +----------+   +-----------+         |
       * CLOSING  |ws.close()|<--|close frame|<--+-----+       CLOSING
       *          +----------+   +-----------+   |
       *    |           |                        |   +---+        |
       *                +------------------------+-->|fin| - - - -
       *    |         +---+                      |   +---+
       *     - - - - -|fin|<---------------------+
       *              +---+
       *
       * @param {Number} [code] Status code explaining why the connection is closing
       * @param {(String|Buffer)} [data] The reason why the connection is
       *     closing
       * @public
       */
      close(code, data) {
        if (this.readyState === _WebSocket.CLOSED) return;
        if (this.readyState === _WebSocket.CONNECTING) {
          const msg = "WebSocket was closed before the connection was established";
          abortHandshake(this, this._req, msg);
          return;
        }
        if (this.readyState === _WebSocket.CLOSING) {
          if (this._closeFrameSent && (this._closeFrameReceived || this._receiver._writableState.errorEmitted)) {
            this._socket.end();
          }
          return;
        }
        this._readyState = _WebSocket.CLOSING;
        this._sender.close(code, data, !this._isServer, (err) => {
          if (err) return;
          this._closeFrameSent = true;
          if (this._closeFrameReceived || this._receiver._writableState.errorEmitted) {
            this._socket.end();
          }
        });
        setCloseTimer(this);
      }
      /**
       * Pause the socket.
       *
       * @public
       */
      pause() {
        if (this.readyState === _WebSocket.CONNECTING || this.readyState === _WebSocket.CLOSED) {
          return;
        }
        this._paused = true;
        this._socket.pause();
      }
      /**
       * Send a ping.
       *
       * @param {*} [data] The data to send
       * @param {Boolean} [mask] Indicates whether or not to mask `data`
       * @param {Function} [cb] Callback which is executed when the ping is sent
       * @public
       */
      ping(data, mask, cb) {
        if (this.readyState === _WebSocket.CONNECTING) {
          throw new Error("WebSocket is not open: readyState 0 (CONNECTING)");
        }
        if (typeof data === "function") {
          cb = data;
          data = mask = void 0;
        } else if (typeof mask === "function") {
          cb = mask;
          mask = void 0;
        }
        if (typeof data === "number") data = data.toString();
        if (this.readyState !== _WebSocket.OPEN) {
          sendAfterClose(this, data, cb);
          return;
        }
        if (mask === void 0) mask = !this._isServer;
        this._sender.ping(data || EMPTY_BUFFER, mask, cb);
      }
      /**
       * Send a pong.
       *
       * @param {*} [data] The data to send
       * @param {Boolean} [mask] Indicates whether or not to mask `data`
       * @param {Function} [cb] Callback which is executed when the pong is sent
       * @public
       */
      pong(data, mask, cb) {
        if (this.readyState === _WebSocket.CONNECTING) {
          throw new Error("WebSocket is not open: readyState 0 (CONNECTING)");
        }
        if (typeof data === "function") {
          cb = data;
          data = mask = void 0;
        } else if (typeof mask === "function") {
          cb = mask;
          mask = void 0;
        }
        if (typeof data === "number") data = data.toString();
        if (this.readyState !== _WebSocket.OPEN) {
          sendAfterClose(this, data, cb);
          return;
        }
        if (mask === void 0) mask = !this._isServer;
        this._sender.pong(data || EMPTY_BUFFER, mask, cb);
      }
      /**
       * Resume the socket.
       *
       * @public
       */
      resume() {
        if (this.readyState === _WebSocket.CONNECTING || this.readyState === _WebSocket.CLOSED) {
          return;
        }
        this._paused = false;
        if (!this._receiver._writableState.needDrain) this._socket.resume();
      }
      /**
       * Send a data message.
       *
       * @param {*} data The message to send
       * @param {Object} [options] Options object
       * @param {Boolean} [options.binary] Specifies whether `data` is binary or
       *     text
       * @param {Boolean} [options.compress] Specifies whether or not to compress
       *     `data`
       * @param {Boolean} [options.fin=true] Specifies whether the fragment is the
       *     last one
       * @param {Boolean} [options.mask] Specifies whether or not to mask `data`
       * @param {Function} [cb] Callback which is executed when data is written out
       * @public
       */
      send(data, options, cb) {
        if (this.readyState === _WebSocket.CONNECTING) {
          throw new Error("WebSocket is not open: readyState 0 (CONNECTING)");
        }
        if (typeof options === "function") {
          cb = options;
          options = {};
        }
        if (typeof data === "number") data = data.toString();
        if (this.readyState !== _WebSocket.OPEN) {
          sendAfterClose(this, data, cb);
          return;
        }
        const opts = {
          binary: typeof data !== "string",
          mask: !this._isServer,
          compress: true,
          fin: true,
          ...options
        };
        if (!this._extensions[PerMessageDeflate2.extensionName]) {
          opts.compress = false;
        }
        this._sender.send(data || EMPTY_BUFFER, opts, cb);
      }
      /**
       * Forcibly close the connection.
       *
       * @public
       */
      terminate() {
        if (this.readyState === _WebSocket.CLOSED) return;
        if (this.readyState === _WebSocket.CONNECTING) {
          const msg = "WebSocket was closed before the connection was established";
          abortHandshake(this, this._req, msg);
          return;
        }
        if (this._socket) {
          this._readyState = _WebSocket.CLOSING;
          this._socket.destroy();
        }
      }
    };
    Object.defineProperty(WebSocket2, "CONNECTING", {
      enumerable: true,
      value: readyStates.indexOf("CONNECTING")
    });
    Object.defineProperty(WebSocket2.prototype, "CONNECTING", {
      enumerable: true,
      value: readyStates.indexOf("CONNECTING")
    });
    Object.defineProperty(WebSocket2, "OPEN", {
      enumerable: true,
      value: readyStates.indexOf("OPEN")
    });
    Object.defineProperty(WebSocket2.prototype, "OPEN", {
      enumerable: true,
      value: readyStates.indexOf("OPEN")
    });
    Object.defineProperty(WebSocket2, "CLOSING", {
      enumerable: true,
      value: readyStates.indexOf("CLOSING")
    });
    Object.defineProperty(WebSocket2.prototype, "CLOSING", {
      enumerable: true,
      value: readyStates.indexOf("CLOSING")
    });
    Object.defineProperty(WebSocket2, "CLOSED", {
      enumerable: true,
      value: readyStates.indexOf("CLOSED")
    });
    Object.defineProperty(WebSocket2.prototype, "CLOSED", {
      enumerable: true,
      value: readyStates.indexOf("CLOSED")
    });
    [
      "binaryType",
      "bufferedAmount",
      "extensions",
      "isPaused",
      "protocol",
      "readyState",
      "url"
    ].forEach((property) => {
      Object.defineProperty(WebSocket2.prototype, property, { enumerable: true });
    });
    ["open", "error", "close", "message"].forEach((method) => {
      Object.defineProperty(WebSocket2.prototype, `on${method}`, {
        enumerable: true,
        get() {
          for (const listener of this.listeners(method)) {
            if (listener[kForOnEventAttribute]) return listener[kListener];
          }
          return null;
        },
        set(handler) {
          for (const listener of this.listeners(method)) {
            if (listener[kForOnEventAttribute]) {
              this.removeListener(method, listener);
              break;
            }
          }
          if (typeof handler !== "function") return;
          this.addEventListener(method, handler, {
            [kForOnEventAttribute]: true
          });
        }
      });
    });
    WebSocket2.prototype.addEventListener = addEventListener;
    WebSocket2.prototype.removeEventListener = removeEventListener;
    module.exports = WebSocket2;
    function initAsClient(websocket, address, protocols, options) {
      const opts = {
        allowSynchronousEvents: true,
        autoPong: true,
        closeTimeout: CLOSE_TIMEOUT,
        protocolVersion: protocolVersions[1],
        maxBufferedChunks: 1024 * 1024,
        maxFragments: 128 * 1024,
        maxPayload: 100 * 1024 * 1024,
        skipUTF8Validation: false,
        perMessageDeflate: true,
        followRedirects: false,
        maxRedirects: 10,
        ...options,
        socketPath: void 0,
        hostname: void 0,
        protocol: void 0,
        timeout: void 0,
        method: "GET",
        host: void 0,
        path: void 0,
        port: void 0
      };
      websocket._autoPong = opts.autoPong;
      websocket._closeTimeout = opts.closeTimeout;
      if (!protocolVersions.includes(opts.protocolVersion)) {
        throw new RangeError(
          `Unsupported protocol version: ${opts.protocolVersion} (supported versions: ${protocolVersions.join(", ")})`
        );
      }
      let parsedUrl;
      if (address instanceof URL2) {
        parsedUrl = address;
      } else {
        try {
          parsedUrl = new URL2(address);
        } catch {
          throw new SyntaxError(`Invalid URL: ${address}`);
        }
      }
      if (parsedUrl.protocol === "http:") {
        parsedUrl.protocol = "ws:";
      } else if (parsedUrl.protocol === "https:") {
        parsedUrl.protocol = "wss:";
      }
      websocket._url = parsedUrl.href;
      const isSecure = parsedUrl.protocol === "wss:";
      const isIpcUrl = parsedUrl.protocol === "ws+unix:";
      let invalidUrlMessage;
      if (parsedUrl.protocol !== "ws:" && !isSecure && !isIpcUrl) {
        invalidUrlMessage = `The URL's protocol must be one of "ws:", "wss:", "http:", "https:", or "ws+unix:"`;
      } else if (isIpcUrl && !parsedUrl.pathname) {
        invalidUrlMessage = "The URL's pathname is empty";
      } else if (parsedUrl.hash) {
        invalidUrlMessage = "The URL contains a fragment identifier";
      }
      if (invalidUrlMessage) {
        const err = new SyntaxError(invalidUrlMessage);
        if (websocket._redirects === 0) {
          throw err;
        } else {
          emitErrorAndClose(websocket, err);
          return;
        }
      }
      const defaultPort = isSecure ? 443 : 80;
      const key = randomBytes(16).toString("base64");
      const request = isSecure ? https.request : http.request;
      const protocolSet = /* @__PURE__ */ new Set();
      let perMessageDeflate;
      opts.createConnection = opts.createConnection || (isSecure ? tlsConnect : netConnect);
      opts.defaultPort = opts.defaultPort || defaultPort;
      opts.port = parsedUrl.port || defaultPort;
      opts.host = parsedUrl.hostname.startsWith("[") ? parsedUrl.hostname.slice(1, -1) : parsedUrl.hostname;
      opts.headers = {
        ...opts.headers,
        "Sec-WebSocket-Version": opts.protocolVersion,
        "Sec-WebSocket-Key": key,
        Connection: "Upgrade",
        Upgrade: "websocket"
      };
      opts.path = parsedUrl.pathname + parsedUrl.search;
      opts.timeout = opts.handshakeTimeout;
      if (opts.perMessageDeflate) {
        perMessageDeflate = new PerMessageDeflate2({
          ...opts.perMessageDeflate,
          isServer: false,
          maxPayload: opts.maxPayload
        });
        opts.headers["Sec-WebSocket-Extensions"] = format({
          [PerMessageDeflate2.extensionName]: perMessageDeflate.offer()
        });
      }
      if (protocols.length) {
        for (const protocol of protocols) {
          if (typeof protocol !== "string" || !subprotocolRegex.test(protocol) || protocolSet.has(protocol)) {
            throw new SyntaxError(
              "An invalid or duplicated subprotocol was specified"
            );
          }
          protocolSet.add(protocol);
        }
        opts.headers["Sec-WebSocket-Protocol"] = protocols.join(",");
      }
      if (opts.origin) {
        if (opts.protocolVersion < 13) {
          opts.headers["Sec-WebSocket-Origin"] = opts.origin;
        } else {
          opts.headers.Origin = opts.origin;
        }
      }
      if (parsedUrl.username || parsedUrl.password) {
        opts.auth = `${parsedUrl.username}:${parsedUrl.password}`;
      }
      if (isIpcUrl) {
        const parts = opts.path.split(":");
        opts.socketPath = parts[0];
        opts.path = parts[1];
      }
      let req;
      if (opts.followRedirects) {
        if (websocket._redirects === 0) {
          websocket._originalIpc = isIpcUrl;
          websocket._originalSecure = isSecure;
          websocket._originalHostOrSocketPath = isIpcUrl ? opts.socketPath : parsedUrl.host;
          const headers = options && options.headers;
          options = { ...options, headers: {} };
          if (headers) {
            for (const [key2, value] of Object.entries(headers)) {
              options.headers[key2.toLowerCase()] = value;
            }
          }
        } else if (websocket.listenerCount("redirect") === 0) {
          const isSameHost = isIpcUrl ? websocket._originalIpc ? opts.socketPath === websocket._originalHostOrSocketPath : false : websocket._originalIpc ? false : parsedUrl.host === websocket._originalHostOrSocketPath;
          if (!isSameHost || websocket._originalSecure && !isSecure) {
            delete opts.headers.authorization;
            delete opts.headers.cookie;
            if (!isSameHost) delete opts.headers.host;
            opts.auth = void 0;
          }
        }
        if (opts.auth && !options.headers.authorization) {
          options.headers.authorization = "Basic " + Buffer.from(opts.auth).toString("base64");
        }
        req = websocket._req = request(opts);
        if (websocket._redirects) {
          websocket.emit("redirect", websocket.url, req);
        }
      } else {
        req = websocket._req = request(opts);
      }
      if (opts.timeout) {
        req.on("timeout", () => {
          abortHandshake(websocket, req, "Opening handshake has timed out");
        });
      }
      req.on("error", (err) => {
        if (req === null || req[kAborted]) return;
        req = websocket._req = null;
        emitErrorAndClose(websocket, err);
      });
      req.on("response", (res) => {
        const location = res.headers.location;
        const statusCode = res.statusCode;
        if (location && opts.followRedirects && statusCode >= 300 && statusCode < 400) {
          if (++websocket._redirects > opts.maxRedirects) {
            abortHandshake(websocket, req, "Maximum redirects exceeded");
            return;
          }
          req.abort();
          let addr;
          try {
            addr = new URL2(location, address);
          } catch (e) {
            const err = new SyntaxError(`Invalid URL: ${location}`);
            emitErrorAndClose(websocket, err);
            return;
          }
          initAsClient(websocket, addr, protocols, options);
        } else if (!websocket.emit("unexpected-response", req, res)) {
          abortHandshake(
            websocket,
            req,
            `Unexpected server response: ${res.statusCode}`
          );
        }
      });
      req.on("upgrade", (res, socket, head) => {
        websocket.emit("upgrade", res);
        if (websocket.readyState !== WebSocket2.CONNECTING) return;
        req = websocket._req = null;
        const upgrade = res.headers.upgrade;
        if (upgrade === void 0 || upgrade.toLowerCase() !== "websocket") {
          abortHandshake(websocket, socket, "Invalid Upgrade header");
          return;
        }
        const digest = createHash2("sha1").update(key + GUID).digest("base64");
        if (res.headers["sec-websocket-accept"] !== digest) {
          abortHandshake(websocket, socket, "Invalid Sec-WebSocket-Accept header");
          return;
        }
        const serverProt = res.headers["sec-websocket-protocol"];
        let protError;
        if (serverProt !== void 0) {
          if (!protocolSet.size) {
            protError = "Server sent a subprotocol but none was requested";
          } else if (!protocolSet.has(serverProt)) {
            protError = "Server sent an invalid subprotocol";
          }
        } else if (protocolSet.size) {
          protError = "Server sent no subprotocol";
        }
        if (protError) {
          abortHandshake(websocket, socket, protError);
          return;
        }
        if (serverProt) websocket._protocol = serverProt;
        const secWebSocketExtensions = res.headers["sec-websocket-extensions"];
        if (secWebSocketExtensions !== void 0) {
          if (!perMessageDeflate) {
            const message = "Server sent a Sec-WebSocket-Extensions header but no extension was requested";
            abortHandshake(websocket, socket, message);
            return;
          }
          let extensions;
          try {
            extensions = parse(secWebSocketExtensions);
          } catch (err) {
            const message = "Invalid Sec-WebSocket-Extensions header";
            abortHandshake(websocket, socket, message);
            return;
          }
          const extensionNames = Object.keys(extensions);
          if (extensionNames.length !== 1 || extensionNames[0] !== PerMessageDeflate2.extensionName) {
            const message = "Server indicated an extension that was not requested";
            abortHandshake(websocket, socket, message);
            return;
          }
          try {
            perMessageDeflate.accept(extensions[PerMessageDeflate2.extensionName]);
          } catch (err) {
            const message = "Invalid Sec-WebSocket-Extensions header";
            abortHandshake(websocket, socket, message);
            return;
          }
          websocket._extensions[PerMessageDeflate2.extensionName] = perMessageDeflate;
        }
        websocket.setSocket(socket, head, {
          allowSynchronousEvents: opts.allowSynchronousEvents,
          generateMask: opts.generateMask,
          maxBufferedChunks: opts.maxBufferedChunks,
          maxFragments: opts.maxFragments,
          maxPayload: opts.maxPayload,
          skipUTF8Validation: opts.skipUTF8Validation
        });
      });
      if (opts.finishRequest) {
        opts.finishRequest(req, websocket);
      } else {
        req.end();
      }
    }
    function emitErrorAndClose(websocket, err) {
      websocket._readyState = WebSocket2.CLOSING;
      websocket._errorEmitted = true;
      websocket.emit("error", err);
      websocket.emitClose();
    }
    function netConnect(options) {
      options.path = options.socketPath;
      return net.connect(options);
    }
    function tlsConnect(options) {
      options.path = void 0;
      if (!options.servername && options.servername !== "") {
        options.servername = net.isIP(options.host) ? "" : options.host;
      }
      return tls.connect(options);
    }
    function abortHandshake(websocket, stream, message) {
      websocket._readyState = WebSocket2.CLOSING;
      const err = new Error(message);
      Error.captureStackTrace(err, abortHandshake);
      if (stream.setHeader) {
        stream[kAborted] = true;
        stream.abort();
        if (stream.socket && !stream.socket.destroyed) {
          stream.socket.destroy();
        }
        process.nextTick(emitErrorAndClose, websocket, err);
      } else {
        stream.destroy(err);
        stream.once("error", websocket.emit.bind(websocket, "error"));
        stream.once("close", websocket.emitClose.bind(websocket));
      }
    }
    function sendAfterClose(websocket, data, cb) {
      if (data) {
        const length = isBlob(data) ? data.size : toBuffer(data).length;
        if (websocket._socket) websocket._sender._bufferedBytes += length;
        else websocket._bufferedAmount += length;
      }
      if (cb) {
        const err = new Error(
          `WebSocket is not open: readyState ${websocket.readyState} (${readyStates[websocket.readyState]})`
        );
        process.nextTick(cb, err);
      }
    }
    function receiverOnConclude(code, reason) {
      const websocket = this[kWebSocket];
      websocket._closeFrameReceived = true;
      websocket._closeMessage = reason;
      websocket._closeCode = code;
      if (websocket._socket[kWebSocket] === void 0) return;
      websocket._socket.removeListener("data", socketOnData);
      process.nextTick(resume, websocket._socket);
      if (code === 1005) websocket.close();
      else websocket.close(code, reason);
    }
    function receiverOnDrain() {
      const websocket = this[kWebSocket];
      if (!websocket.isPaused) websocket._socket.resume();
    }
    function receiverOnError(err) {
      const websocket = this[kWebSocket];
      if (websocket._socket[kWebSocket] !== void 0) {
        websocket._socket.removeListener("data", socketOnData);
        process.nextTick(resume, websocket._socket);
        websocket.close(err[kStatusCode]);
      }
      if (!websocket._errorEmitted) {
        websocket._errorEmitted = true;
        websocket.emit("error", err);
      }
    }
    function receiverOnFinish() {
      this[kWebSocket].emitClose();
    }
    function receiverOnMessage(data, isBinary) {
      this[kWebSocket].emit("message", data, isBinary);
    }
    function receiverOnPing(data) {
      const websocket = this[kWebSocket];
      if (websocket._autoPong) websocket.pong(data, !this._isServer, NOOP);
      websocket.emit("ping", data);
    }
    function receiverOnPong(data) {
      this[kWebSocket].emit("pong", data);
    }
    function resume(stream) {
      stream.resume();
    }
    function senderOnError(err) {
      const websocket = this[kWebSocket];
      if (websocket.readyState === WebSocket2.CLOSED) return;
      if (websocket.readyState === WebSocket2.OPEN) {
        websocket._readyState = WebSocket2.CLOSING;
        setCloseTimer(websocket);
      }
      this._socket.end();
      if (!websocket._errorEmitted) {
        websocket._errorEmitted = true;
        websocket.emit("error", err);
      }
    }
    function setCloseTimer(websocket) {
      websocket._closeTimer = setTimeout(
        websocket._socket.destroy.bind(websocket._socket),
        websocket._closeTimeout
      );
    }
    function socketOnClose() {
      const websocket = this[kWebSocket];
      this.removeListener("close", socketOnClose);
      this.removeListener("data", socketOnData);
      this.removeListener("end", socketOnEnd);
      websocket._readyState = WebSocket2.CLOSING;
      if (!this._readableState.endEmitted && !websocket._closeFrameReceived && !websocket._receiver._writableState.errorEmitted && this._readableState.length !== 0) {
        const chunk = this.read(this._readableState.length);
        websocket._receiver.write(chunk);
      }
      websocket._receiver.end();
      this[kWebSocket] = void 0;
      clearTimeout(websocket._closeTimer);
      if (websocket._receiver._writableState.finished || websocket._receiver._writableState.errorEmitted) {
        websocket.emitClose();
      } else {
        websocket._receiver.on("error", receiverOnFinish);
        websocket._receiver.on("finish", receiverOnFinish);
      }
    }
    function socketOnData(chunk) {
      if (!this[kWebSocket]._receiver.write(chunk)) {
        this.pause();
      }
    }
    function socketOnEnd() {
      const websocket = this[kWebSocket];
      websocket._readyState = WebSocket2.CLOSING;
      websocket._receiver.end();
      this.end();
    }
    function socketOnError() {
      const websocket = this[kWebSocket];
      this.removeListener("error", socketOnError);
      this.on("error", NOOP);
      if (websocket) {
        websocket._readyState = WebSocket2.CLOSING;
        this.destroy();
      }
    }
  }
});

// node_modules/ws/lib/stream.js
var require_stream = __commonJS({
  "node_modules/ws/lib/stream.js"(exports, module) {
    "use strict";
    var WebSocket2 = require_websocket();
    var { Duplex } = __require("stream");
    function emitClose(stream) {
      stream.emit("close");
    }
    function duplexOnEnd() {
      if (!this.destroyed && this._writableState.finished) {
        this.destroy();
      }
    }
    function duplexOnError(err) {
      this.removeListener("error", duplexOnError);
      this.destroy();
      if (this.listenerCount("error") === 0) {
        this.emit("error", err);
      }
    }
    function createWebSocketStream2(ws, options) {
      let terminateOnDestroy = true;
      const duplex = new Duplex({
        ...options,
        autoDestroy: false,
        emitClose: false,
        objectMode: false,
        writableObjectMode: false
      });
      ws.on("message", function message(msg, isBinary) {
        const data = !isBinary && duplex._readableState.objectMode ? msg.toString() : msg;
        if (!duplex.push(data)) ws.pause();
      });
      ws.once("error", function error(err) {
        if (duplex.destroyed) return;
        terminateOnDestroy = false;
        duplex.destroy(err);
      });
      ws.once("close", function close() {
        if (duplex.destroyed) return;
        duplex.push(null);
      });
      duplex._destroy = function(err, callback) {
        if (ws.readyState === ws.CLOSED) {
          callback(err);
          process.nextTick(emitClose, duplex);
          return;
        }
        let called = false;
        ws.once("error", function error(err2) {
          called = true;
          callback(err2);
        });
        ws.once("close", function close() {
          if (!called) callback(err);
          process.nextTick(emitClose, duplex);
        });
        if (terminateOnDestroy) ws.terminate();
      };
      duplex._final = function(callback) {
        if (ws.readyState === ws.CONNECTING) {
          ws.once("open", function open() {
            duplex._final(callback);
          });
          return;
        }
        if (ws._socket === null) return;
        if (ws._socket._writableState.finished) {
          callback();
          if (duplex._readableState.endEmitted) duplex.destroy();
        } else {
          ws._socket.once("finish", function finish() {
            callback();
          });
          ws.close();
        }
      };
      duplex._read = function() {
        if (ws.isPaused) ws.resume();
      };
      duplex._write = function(chunk, encoding, callback) {
        if (ws.readyState === ws.CONNECTING) {
          ws.once("open", function open() {
            duplex._write(chunk, encoding, callback);
          });
          return;
        }
        ws.send(chunk, callback);
      };
      duplex.on("end", duplexOnEnd);
      duplex.on("error", duplexOnError);
      return duplex;
    }
    module.exports = createWebSocketStream2;
  }
});

// node_modules/ws/lib/subprotocol.js
var require_subprotocol = __commonJS({
  "node_modules/ws/lib/subprotocol.js"(exports, module) {
    "use strict";
    var { tokenChars } = require_validation();
    function parse(header) {
      const protocols = /* @__PURE__ */ new Set();
      let start = -1;
      let end = -1;
      let i = 0;
      for (i; i < header.length; i++) {
        const code = header.charCodeAt(i);
        if (end === -1 && tokenChars[code] === 1) {
          if (start === -1) start = i;
        } else if (i !== 0 && (code === 32 || code === 9)) {
          if (end === -1 && start !== -1) end = i;
        } else if (code === 44) {
          if (start === -1) {
            throw new SyntaxError(`Unexpected character at index ${i}`);
          }
          if (end === -1) end = i;
          const protocol2 = header.slice(start, end);
          if (protocols.has(protocol2)) {
            throw new SyntaxError(`The "${protocol2}" subprotocol is duplicated`);
          }
          protocols.add(protocol2);
          start = end = -1;
        } else {
          throw new SyntaxError(`Unexpected character at index ${i}`);
        }
      }
      if (start === -1 || end !== -1) {
        throw new SyntaxError("Unexpected end of input");
      }
      const protocol = header.slice(start, i);
      if (protocols.has(protocol)) {
        throw new SyntaxError(`The "${protocol}" subprotocol is duplicated`);
      }
      protocols.add(protocol);
      return protocols;
    }
    module.exports = { parse };
  }
});

// node_modules/ws/lib/websocket-server.js
var require_websocket_server = __commonJS({
  "node_modules/ws/lib/websocket-server.js"(exports, module) {
    "use strict";
    var EventEmitter = __require("events");
    var http = __require("http");
    var { Duplex } = __require("stream");
    var { createHash: createHash2 } = __require("crypto");
    var extension2 = require_extension();
    var PerMessageDeflate2 = require_permessage_deflate();
    var subprotocol2 = require_subprotocol();
    var WebSocket2 = require_websocket();
    var { CLOSE_TIMEOUT, GUID, kWebSocket } = require_constants();
    var keyRegex = /^[+/0-9A-Za-z]{22}==$/;
    var RUNNING = 0;
    var CLOSING = 1;
    var CLOSED = 2;
    var WebSocketServer2 = class extends EventEmitter {
      /**
       * Create a `WebSocketServer` instance.
       *
       * @param {Object} options Configuration options
       * @param {Boolean} [options.allowSynchronousEvents=true] Specifies whether
       *     any of the `'message'`, `'ping'`, and `'pong'` events can be emitted
       *     multiple times in the same tick
       * @param {Boolean} [options.autoPong=true] Specifies whether or not to
       *     automatically send a pong in response to a ping
       * @param {Number} [options.backlog=511] The maximum length of the queue of
       *     pending connections
       * @param {Boolean} [options.clientTracking=true] Specifies whether or not to
       *     track clients
       * @param {Number} [options.closeTimeout=30000] Duration in milliseconds to
       *     wait for the closing handshake to finish after `websocket.close()` is
       *     called
       * @param {Function} [options.handleProtocols] A hook to handle protocols
       * @param {String} [options.host] The hostname where to bind the server
       * @param {Number} [options.maxBufferedChunks=1048576] The maximum number of
       *     buffered data chunks
       * @param {Number} [options.maxFragments=131072] The maximum number of message
       *     fragments
       * @param {Number} [options.maxPayload=104857600] The maximum allowed message
       *     size
       * @param {Boolean} [options.noServer=false] Enable no server mode
       * @param {String} [options.path] Accept only connections matching this path
       * @param {(Boolean|Object)} [options.perMessageDeflate=false] Enable/disable
       *     permessage-deflate
       * @param {Number} [options.port] The port where to bind the server
       * @param {(http.Server|https.Server)} [options.server] A pre-created HTTP/S
       *     server to use
       * @param {Boolean} [options.skipUTF8Validation=false] Specifies whether or
       *     not to skip UTF-8 validation for text and close messages
       * @param {Function} [options.verifyClient] A hook to reject connections
       * @param {Function} [options.WebSocket=WebSocket] Specifies the `WebSocket`
       *     class to use. It must be the `WebSocket` class or class that extends it
       * @param {Function} [callback] A listener for the `listening` event
       */
      constructor(options, callback) {
        super();
        options = {
          allowSynchronousEvents: true,
          autoPong: true,
          maxBufferedChunks: 1024 * 1024,
          maxFragments: 128 * 1024,
          maxPayload: 100 * 1024 * 1024,
          skipUTF8Validation: false,
          perMessageDeflate: false,
          handleProtocols: null,
          clientTracking: true,
          closeTimeout: CLOSE_TIMEOUT,
          verifyClient: null,
          noServer: false,
          backlog: null,
          // use default (511 as implemented in net.js)
          server: null,
          host: null,
          path: null,
          port: null,
          WebSocket: WebSocket2,
          ...options
        };
        if (options.port == null && !options.server && !options.noServer || options.port != null && (options.server || options.noServer) || options.server && options.noServer) {
          throw new TypeError(
            'One and only one of the "port", "server", or "noServer" options must be specified'
          );
        }
        if (options.port != null) {
          this._server = http.createServer((req, res) => {
            const body = http.STATUS_CODES[426];
            res.writeHead(426, {
              "Content-Length": body.length,
              "Content-Type": "text/plain"
            });
            res.end(body);
          });
          this._server.listen(
            options.port,
            options.host,
            options.backlog,
            callback
          );
        } else if (options.server) {
          this._server = options.server;
        }
        if (this._server) {
          const emitConnection = this.emit.bind(this, "connection");
          this._removeListeners = addListeners(this._server, {
            listening: this.emit.bind(this, "listening"),
            error: this.emit.bind(this, "error"),
            upgrade: (req, socket, head) => {
              this.handleUpgrade(req, socket, head, emitConnection);
            }
          });
        }
        if (options.perMessageDeflate === true) options.perMessageDeflate = {};
        if (options.clientTracking) {
          this.clients = /* @__PURE__ */ new Set();
          this._shouldEmitClose = false;
        }
        this.options = options;
        this._state = RUNNING;
      }
      /**
       * Returns the bound address, the address family name, and port of the server
       * as reported by the operating system if listening on an IP socket.
       * If the server is listening on a pipe or UNIX domain socket, the name is
       * returned as a string.
       *
       * @return {(Object|String|null)} The address of the server
       * @public
       */
      address() {
        if (this.options.noServer) {
          throw new Error('The server is operating in "noServer" mode');
        }
        if (!this._server) return null;
        return this._server.address();
      }
      /**
       * Stop the server from accepting new connections and emit the `'close'` event
       * when all existing connections are closed.
       *
       * @param {Function} [cb] A one-time listener for the `'close'` event
       * @public
       */
      close(cb) {
        if (this._state === CLOSED) {
          if (cb) {
            this.once("close", () => {
              cb(new Error("The server is not running"));
            });
          }
          process.nextTick(emitClose, this);
          return;
        }
        if (cb) this.once("close", cb);
        if (this._state === CLOSING) return;
        this._state = CLOSING;
        if (this.options.noServer || this.options.server) {
          if (this._server) {
            this._removeListeners();
            this._removeListeners = this._server = null;
          }
          if (this.clients) {
            if (!this.clients.size) {
              process.nextTick(emitClose, this);
            } else {
              this._shouldEmitClose = true;
            }
          } else {
            process.nextTick(emitClose, this);
          }
        } else {
          const server = this._server;
          this._removeListeners();
          this._removeListeners = this._server = null;
          server.close(() => {
            emitClose(this);
          });
        }
      }
      /**
       * See if a given request should be handled by this server instance.
       *
       * @param {http.IncomingMessage} req Request object to inspect
       * @return {Boolean} `true` if the request is valid, else `false`
       * @public
       */
      shouldHandle(req) {
        if (this.options.path) {
          const index = req.url.indexOf("?");
          const pathname = index !== -1 ? req.url.slice(0, index) : req.url;
          if (pathname !== this.options.path) return false;
        }
        return true;
      }
      /**
       * Handle a HTTP Upgrade request.
       *
       * @param {http.IncomingMessage} req The request object
       * @param {Duplex} socket The network socket between the server and client
       * @param {Buffer} head The first packet of the upgraded stream
       * @param {Function} cb Callback
       * @public
       */
      handleUpgrade(req, socket, head, cb) {
        socket.on("error", socketOnError);
        const key = req.headers["sec-websocket-key"];
        const upgrade = req.headers.upgrade;
        const version = +req.headers["sec-websocket-version"];
        if (req.method !== "GET") {
          const message = "Invalid HTTP method";
          abortHandshakeOrEmitwsClientError(this, req, socket, 405, message);
          return;
        }
        if (upgrade === void 0 || upgrade.toLowerCase() !== "websocket") {
          const message = "Invalid Upgrade header";
          abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
          return;
        }
        if (key === void 0 || !keyRegex.test(key)) {
          const message = "Missing or invalid Sec-WebSocket-Key header";
          abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
          return;
        }
        if (version !== 13 && version !== 8) {
          const message = "Missing or invalid Sec-WebSocket-Version header";
          abortHandshakeOrEmitwsClientError(this, req, socket, 400, message, {
            "Sec-WebSocket-Version": "13, 8"
          });
          return;
        }
        if (!this.shouldHandle(req)) {
          abortHandshake(socket, 400);
          return;
        }
        const secWebSocketProtocol = req.headers["sec-websocket-protocol"];
        let protocols = /* @__PURE__ */ new Set();
        if (secWebSocketProtocol !== void 0) {
          try {
            protocols = subprotocol2.parse(secWebSocketProtocol);
          } catch (err) {
            const message = "Invalid Sec-WebSocket-Protocol header";
            abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
            return;
          }
        }
        const secWebSocketExtensions = req.headers["sec-websocket-extensions"];
        const extensions = {};
        if (this.options.perMessageDeflate && secWebSocketExtensions !== void 0) {
          const perMessageDeflate = new PerMessageDeflate2({
            ...this.options.perMessageDeflate,
            isServer: true,
            maxPayload: this.options.maxPayload
          });
          try {
            const offers = extension2.parse(secWebSocketExtensions);
            if (offers[PerMessageDeflate2.extensionName]) {
              perMessageDeflate.accept(offers[PerMessageDeflate2.extensionName]);
              extensions[PerMessageDeflate2.extensionName] = perMessageDeflate;
            }
          } catch (err) {
            const message = "Invalid or unacceptable Sec-WebSocket-Extensions header";
            abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
            return;
          }
        }
        if (this.options.verifyClient) {
          const info = {
            origin: req.headers[`${version === 8 ? "sec-websocket-origin" : "origin"}`],
            secure: !!(req.socket.authorized || req.socket.encrypted),
            req
          };
          if (this.options.verifyClient.length === 2) {
            this.options.verifyClient(info, (verified, code, message, headers) => {
              if (!verified) {
                return abortHandshake(socket, code || 401, message, headers);
              }
              this.completeUpgrade(
                extensions,
                key,
                protocols,
                req,
                socket,
                head,
                cb
              );
            });
            return;
          }
          if (!this.options.verifyClient(info)) return abortHandshake(socket, 401);
        }
        this.completeUpgrade(extensions, key, protocols, req, socket, head, cb);
      }
      /**
       * Upgrade the connection to WebSocket.
       *
       * @param {Object} extensions The accepted extensions
       * @param {String} key The value of the `Sec-WebSocket-Key` header
       * @param {Set} protocols The subprotocols
       * @param {http.IncomingMessage} req The request object
       * @param {Duplex} socket The network socket between the server and client
       * @param {Buffer} head The first packet of the upgraded stream
       * @param {Function} cb Callback
       * @throws {Error} If called more than once with the same socket
       * @private
       */
      completeUpgrade(extensions, key, protocols, req, socket, head, cb) {
        if (!socket.readable || !socket.writable) return socket.destroy();
        if (socket[kWebSocket]) {
          throw new Error(
            "server.handleUpgrade() was called more than once with the same socket, possibly due to a misconfiguration"
          );
        }
        if (this._state > RUNNING) return abortHandshake(socket, 503);
        const digest = createHash2("sha1").update(key + GUID).digest("base64");
        const headers = [
          "HTTP/1.1 101 Switching Protocols",
          "Upgrade: websocket",
          "Connection: Upgrade",
          `Sec-WebSocket-Accept: ${digest}`
        ];
        const ws = new this.options.WebSocket(null, void 0, this.options);
        if (protocols.size) {
          const protocol = this.options.handleProtocols ? this.options.handleProtocols(protocols, req) : protocols.values().next().value;
          if (protocol) {
            headers.push(`Sec-WebSocket-Protocol: ${protocol}`);
            ws._protocol = protocol;
          }
        }
        if (extensions[PerMessageDeflate2.extensionName]) {
          const params = extensions[PerMessageDeflate2.extensionName].params;
          const value = extension2.format({
            [PerMessageDeflate2.extensionName]: [params]
          });
          headers.push(`Sec-WebSocket-Extensions: ${value}`);
          ws._extensions = extensions;
        }
        this.emit("headers", headers, req);
        socket.write(headers.concat("\r\n").join("\r\n"));
        socket.removeListener("error", socketOnError);
        ws.setSocket(socket, head, {
          allowSynchronousEvents: this.options.allowSynchronousEvents,
          maxBufferedChunks: this.options.maxBufferedChunks,
          maxFragments: this.options.maxFragments,
          maxPayload: this.options.maxPayload,
          skipUTF8Validation: this.options.skipUTF8Validation
        });
        if (this.clients) {
          this.clients.add(ws);
          ws.on("close", () => {
            this.clients.delete(ws);
            if (this._shouldEmitClose && !this.clients.size) {
              process.nextTick(emitClose, this);
            }
          });
        }
        cb(ws, req);
      }
    };
    module.exports = WebSocketServer2;
    function addListeners(server, map) {
      for (const event of Object.keys(map)) server.on(event, map[event]);
      return function removeListeners() {
        for (const event of Object.keys(map)) {
          server.removeListener(event, map[event]);
        }
      };
    }
    function emitClose(server) {
      server._state = CLOSED;
      server.emit("close");
    }
    function socketOnError() {
      this.destroy();
    }
    function abortHandshake(socket, code, message, headers) {
      message = message || http.STATUS_CODES[code];
      headers = {
        Connection: "close",
        "Content-Type": "text/html",
        "Content-Length": Buffer.byteLength(message),
        ...headers
      };
      socket.once("finish", socket.destroy);
      socket.end(
        `HTTP/1.1 ${code} ${http.STATUS_CODES[code]}\r
` + Object.keys(headers).map((h) => `${h}: ${headers[h]}`).join("\r\n") + "\r\n\r\n" + message
      );
    }
    function abortHandshakeOrEmitwsClientError(server, req, socket, code, message, headers) {
      if (server.listenerCount("wsClientError")) {
        const err = new Error(message);
        Error.captureStackTrace(err, abortHandshakeOrEmitwsClientError);
        server.emit("wsClientError", err, socket, req);
      } else {
        abortHandshake(socket, code, message, headers);
      }
    }
  }
});

// packages/device-bridge/src/cli.ts
import { realpathSync } from "node:fs";
import path6 from "node:path";
import { fileURLToPath } from "node:url";

// packages/device-bridge/src/config.ts
import { mkdir, readFile, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
var BRIDGE_CONFIG_BASENAME = "bridge.json";
function normalizePlatform(platform) {
  if (platform === "win32") {
    return "windows";
  }
  if (platform === "darwin") {
    return "darwin";
  }
  return "linux";
}
function detectBridgePlatform(platform = process.platform) {
  return normalizePlatform(platform);
}
function resolveBridgeConfigPath(options = {}) {
  const platform = options.platform ?? process.platform;
  const localAppData = options.localAppData ?? process.env.LOCALAPPDATA;
  const homeDir = options.homeDir ?? os.homedir();
  if (platform === "win32" && localAppData) {
    return path.join(localAppData, "WiseEff", BRIDGE_CONFIG_BASENAME);
  }
  return path.join(homeDir, ".wiseeff", BRIDGE_CONFIG_BASENAME);
}
async function loadBridgeConfig(configPath = resolveBridgeConfigPath()) {
  try {
    const raw = await readFile(configPath, "utf8");
    const parsed = JSON.parse(raw);
    return parsed;
  } catch (error) {
    if (error.code === "ENOENT") {
      return null;
    }
    throw error;
  }
}
async function saveBridgeConfig(config, configPath = resolveBridgeConfigPath()) {
  await mkdir(path.dirname(configPath), { recursive: true });
  await writeFile(configPath, `${JSON.stringify(config, null, 2)}
`, "utf8");
}

// packages/device-command-core/src/adbRunner.ts
import { spawn as defaultSpawn } from "node:child_process";

// packages/device-command-core/src/adbTargets.ts
function parseAdbDevices(stdout) {
  return stdout.split(/\r?\n/).map((line) => line.trim()).filter((line) => line.length > 0 && !line.toLowerCase().startsWith("list of devices")).map((line) => line.split(/\s+/)).filter(([serial, state]) => Boolean(serial) && state === "device").map(([serial]) => ({
    targetRef: serial,
    online: true
  }));
}

// packages/device-command-core/src/adbRunner.ts
function durationSince(startedAt) {
  return Math.max(1, Date.now() - startedAt);
}
function createAdbCommandRunner(options = {}) {
  const spawnImpl = options.spawnImpl ?? defaultSpawn;
  const command = options.command ?? "adb";
  return (args, runOptions) => new Promise((resolve, reject) => {
    const startedAt = Date.now();
    let stdout = "";
    let stderr = "";
    let settled = false;
    const spawnOptions = { shell: false, windowsHide: true, stdio: ["ignore", "pipe", "pipe"] };
    const child = spawnImpl(command, args, spawnOptions);
    const timeout = setTimeout(() => {
      settled = true;
      child.kill();
      resolve({
        code: null,
        stdout,
        stderr,
        timedOut: true,
        durationMs: durationSince(startedAt)
      });
    }, runOptions.timeoutMs);
    child.stdout?.setEncoding("utf8");
    child.stderr?.setEncoding("utf8");
    child.stdout?.on("data", (chunk) => {
      stdout += chunk;
    });
    child.stderr?.on("data", (chunk) => {
      stderr += chunk;
    });
    child.on("error", (error) => {
      if (settled) {
        return;
      }
      settled = true;
      clearTimeout(timeout);
      reject(error);
    });
    child.on("close", (code) => {
      if (settled) {
        return;
      }
      settled = true;
      clearTimeout(timeout);
      resolve({
        code,
        stdout,
        stderr,
        durationMs: durationSince(startedAt)
      });
    });
  });
}
function createDefaultAdbCommandRunner(command = "adb") {
  return createAdbCommandRunner({ command });
}

// packages/device-command-core/src/hdcRunner.ts
import { spawn as defaultSpawn2 } from "node:child_process";

// packages/device-command-core/src/hdcTargets.ts
function parseHdcTargets(stdout) {
  return stdout.split(/\r?\n/).map((line) => line.trim()).filter(Boolean).map((line) => ({
    targetRef: line,
    online: true
  }));
}

// packages/device-command-core/src/hdcRunner.ts
function durationSince2(startedAt) {
  return Math.max(1, Date.now() - startedAt);
}
function createHdcCommandRunner(options = {}) {
  const spawnImpl = options.spawnImpl ?? defaultSpawn2;
  const command = options.command ?? "hdc";
  return (args, runOptions) => new Promise((resolve, reject) => {
    const startedAt = Date.now();
    let stdout = "";
    let stderr = "";
    let settled = false;
    const spawnOptions = { shell: false, windowsHide: true, stdio: ["ignore", "pipe", "pipe"] };
    const child = spawnImpl(command, args, spawnOptions);
    const timeout = setTimeout(() => {
      settled = true;
      child.kill();
      resolve({
        code: null,
        stdout,
        stderr,
        timedOut: true,
        durationMs: durationSince2(startedAt)
      });
    }, runOptions.timeoutMs);
    child.stdout?.setEncoding("utf8");
    child.stderr?.setEncoding("utf8");
    child.stdout?.on("data", (chunk) => {
      stdout += chunk;
    });
    child.stderr?.on("data", (chunk) => {
      stderr += chunk;
    });
    child.on("error", (error) => {
      if (settled) {
        return;
      }
      settled = true;
      clearTimeout(timeout);
      reject(error);
    });
    child.on("close", (code) => {
      if (settled) {
        return;
      }
      settled = true;
      clearTimeout(timeout);
      resolve({
        code,
        stdout,
        stderr,
        durationMs: durationSince2(startedAt)
      });
    });
  });
}
function createDefaultHdcCommandRunner(command = "hdc") {
  return createHdcCommandRunner({ command });
}

// packages/device-bridge/src/toolInstallState.ts
import { mkdir as mkdir2, readFile as readFile2, writeFile as writeFile2 } from "node:fs/promises";
import path3 from "node:path";

// packages/device-bridge/src/toolPaths.ts
import { access } from "node:fs/promises";
import { constants as fsConstants } from "node:fs";
import os2 from "node:os";
import path2 from "node:path";
function resolveToolsRoot(options = {}) {
  if (options.toolsRoot) {
    return options.toolsRoot;
  }
  const platform = options.platform ?? process.platform;
  const localAppData = options.localAppData ?? process.env.LOCALAPPDATA;
  const homeDir = options.homeDir ?? os2.homedir();
  if (platform === "win32" && localAppData) {
    return path2.join(localAppData, "WiseEff", "tools");
  }
  if (platform === "darwin") {
    return path2.join(homeDir, "Library", "Application Support", "WiseEff", "tools");
  }
  return path2.join(homeDir, ".wiseeff", "tools");
}
function executableName(protocol, platform) {
  const base = protocol === "adb" ? "adb" : "hdc";
  return platform === "win32" ? `${base}.exe` : base;
}
function managedRelativePath(protocol, version, platform) {
  const executable = executableName(protocol, platform);
  if (protocol === "adb") {
    return path2.join("adb", version, "platform-tools", executable);
  }
  return path2.join("hdc", version, executable);
}
function resolveManagedToolPath(protocol, version, options = {}) {
  const platform = options.platform ?? process.platform;
  return path2.join(resolveToolsRoot(options), managedRelativePath(protocol, version, platform));
}
async function isExecutable(filePath) {
  try {
    await access(filePath, fsConstants.X_OK);
    return true;
  } catch {
    try {
      await access(filePath);
      return process.platform === "win32";
    } catch {
      return false;
    }
  }
}
async function resolveToolBinary(protocol, input = {}) {
  const platform = input.platform ?? process.platform;
  const commandName = protocol === "adb" ? "adb" : "hdc";
  if (input.installedVersion) {
    const managedPath = resolveManagedToolPath(protocol, input.installedVersion, input);
    if (await isExecutable(managedPath)) {
      return { command: managedPath, source: "managed" };
    }
  }
  return { command: commandName, source: "system" };
}

// packages/device-bridge/src/toolInstallState.ts
function stateFilePath(options = {}) {
  const root = options.toolsRoot ?? resolveToolsRoot(options);
  return path3.join(root, "state.json");
}
async function readToolInstallState(options = {}) {
  try {
    const raw = await readFile2(stateFilePath(options), "utf8");
    const parsed = JSON.parse(raw);
    return parsed ?? {};
  } catch (error) {
    if (error.code === "ENOENT") {
      return {};
    }
    throw error;
  }
}
async function writeToolInstallState(state, options = {}) {
  const filePath = stateFilePath(options);
  await mkdir2(path3.dirname(filePath), { recursive: true });
  await writeFile2(filePath, `${JSON.stringify(state, null, 2)}
`, "utf8");
}
async function recordToolInstall(protocol, record, options = {}) {
  const current = await readToolInstallState(options);
  const next = { ...current, [protocol]: record };
  await writeToolInstallState(next, options);
  return next;
}
async function getInstalledToolVersion(protocol, options = {}) {
  const state = await readToolInstallState(options);
  return state[protocol]?.version;
}

// packages/device-bridge/src/toolProbe.ts
function toErrorMessage(error) {
  if (error instanceof Error && error.message.trim()) {
    return error.message;
  }
  return "Tool probe failed.";
}
function protocolLabel(protocol) {
  return protocol === "adb" ? "ADB" : "HDC";
}
function commandFailureMessage(protocol, result) {
  if (result.timedOut) {
    return `${protocolLabel(protocol)} command timed out.`;
  }
  return result.stderr.trim() || `${protocolLabel(protocol)} exited with ${String(result.code)}.`;
}
function extractVersion(stdout) {
  const line = stdout.split(/\r?\n/).map((entry) => entry.trim()).find(Boolean);
  return line ?? void 0;
}
async function probeProtocolAvailability(runner, protocol, timeoutMs, source) {
  try {
    const result = await runner(["version"], { timeoutMs });
    if (result.code === 0 && !result.timedOut) {
      return {
        available: true,
        source,
        version: extractVersion(result.stdout)
      };
    }
    return {
      available: false,
      source,
      reason: commandFailureMessage(protocol, result)
    };
  } catch (error) {
    return {
      available: false,
      source,
      reason: toErrorMessage(error)
    };
  }
}
async function probeTools(input) {
  const timeoutMs = input.timeoutMs ?? 2e3;
  const [adb, hdc] = await Promise.all([
    probeProtocolAvailability(input.adbRunner, "adb", timeoutMs, input.adbSource),
    probeProtocolAvailability(input.hdcRunner, "hdc", timeoutMs, input.hdcSource)
  ]);
  return { adb, hdc };
}

// packages/device-command-core/src/remoteNodeWrite.ts
function shellQuote(value) {
  return `'${value.replaceAll("'", "'\\''")}'`;
}
function shouldUseBase64Write(value) {
  return /[\r\n\u0000]/.test(value);
}
function buildRemoteWriteShellCommand(nodePath, value) {
  if (shouldUseBase64Write(value)) {
    const encoded = Buffer.from(value, "utf8").toString("base64");
    return `echo ${shellQuote(encoded)} | base64 -d > ${shellQuote(nodePath)}`;
  }
  return `printf %s ${shellQuote(value)} > ${shellQuote(nodePath)}`;
}
function normalizeRemoteReadValue(stdout, preserveExact) {
  if (preserveExact) {
    return stdout;
  }
  return stdout.trim();
}
function remoteShellDiagnostic(result) {
  const output = [result.stderr, result.stdout].map((value) => value.trim()).filter(Boolean).join("\n");
  const diagnosticLine = output.split(/\r?\n/).find(
    (line) => /(?:^|:\s)(?:cat|sh|\/bin\/sh): .*?(?:No such file or directory|Permission denied|not found|Read-only file system)/i.test(
      line
    )
  );
  return diagnosticLine?.trim();
}

// packages/device-bridge/src/rpcHandlers.ts
var RpcRequestError = class extends Error {
  code;
  constructor(code, message) {
    super(message);
    this.code = code;
  }
};
function readBoolean(value, fallback) {
  return typeof value === "boolean" ? value : fallback;
}
function readRequiredString(value, key) {
  const text = typeof value === "string" ? value.trim() : "";
  if (!text) {
    throw new RpcRequestError("BAD_REQUEST", `Expected non-empty string for "${key}".`);
  }
  return text;
}
function requireSupportedProtocol(value) {
  const protocol = readRequiredString(value, "protocol");
  if (protocol !== "adb" && protocol !== "hdc") {
    throw new RpcRequestError("UNSUPPORTED_PROTOCOL", `Protocol "${protocol}" is not supported.`);
  }
  return protocol;
}
function protocolLabel2(protocol) {
  return protocol === "adb" ? "ADB" : "HDC";
}
function commandFailureMessage2(protocol, result) {
  if (result.timedOut) {
    return `${protocolLabel2(protocol)} command timed out.`;
  }
  return result.stderr.trim() || `${protocolLabel2(protocol)} exited with ${String(result.code)}.`;
}
function readNodeFailure(protocol, result, diagnostic) {
  if (diagnostic) {
    return `${protocolLabel2(protocol)} command failed: ${diagnostic}`;
  }
  return commandFailureMessage2(protocol, result);
}
function evaluateRemoteCommand(protocol, result) {
  const diagnostic = remoteShellDiagnostic(result);
  const ok = result.code === 0 && !result.timedOut && !diagnostic;
  return {
    ok,
    stdout: result.stdout,
    stderr: result.stderr,
    error: ok ? void 0 : readNodeFailure(protocol, result, diagnostic),
    durationMs: result.durationMs
  };
}
function createRpcHandlers(options = {}) {
  const adbCommand = options.adbCommand ?? "adb";
  const hdcCommand = options.hdcCommand ?? "hdc";
  const adbRunner = options.adbRunner ?? createDefaultAdbCommandRunner(adbCommand);
  const hdcRunner = options.hdcRunner ?? createDefaultHdcCommandRunner(hdcCommand);
  const adbTimeoutMs = options.adbTimeoutMs ?? 5e3;
  const hdcTimeoutMs = options.hdcTimeoutMs ?? 5e3;
  const capabilityProbeTimeoutMs = options.capabilityProbeTimeoutMs ?? 2e3;
  async function readNode(params) {
    const protocol = requireSupportedProtocol(params.protocol);
    const targetRef = readRequiredString(params.targetRef, "targetRef");
    const nodePath = readRequiredString(params.nodePath, "nodePath");
    const preserveExactRead = readBoolean(params.preserveExactRead, false);
    if (protocol === "adb") {
      const result2 = await adbRunner(["-s", targetRef, "shell", "cat", nodePath], { timeoutMs: adbTimeoutMs });
      const evaluated2 = evaluateRemoteCommand(protocol, result2);
      if (!evaluated2.ok) {
        return evaluated2;
      }
      return {
        ok: true,
        value: normalizeRemoteReadValue(result2.stdout, preserveExactRead),
        stdout: result2.stdout,
        stderr: result2.stderr,
        durationMs: result2.durationMs
      };
    }
    const result = await hdcRunner(["-t", targetRef, "shell", `cat ${shellQuote(nodePath)}`], { timeoutMs: hdcTimeoutMs });
    const evaluated = evaluateRemoteCommand(protocol, result);
    if (!evaluated.ok) {
      return evaluated;
    }
    return {
      ok: true,
      value: normalizeRemoteReadValue(result.stdout, preserveExactRead),
      stdout: result.stdout,
      stderr: result.stderr,
      durationMs: result.durationMs
    };
  }
  return {
    async handle(method, params) {
      switch (method) {
        case "bridge.getCapabilities": {
          const tools = await probeTools({
            adbRunner,
            hdcRunner,
            adbSource: options.adbSource,
            hdcSource: options.hdcSource,
            timeoutMs: capabilityProbeTimeoutMs
          });
          return {
            protocols: tools,
            methods: ["bridge.getCapabilities", "debug.detectTargets", "debug.readNode", "debug.writeNode"]
          };
        }
        case "debug.detectTargets": {
          const protocol = requireSupportedProtocol(params.protocol);
          if (protocol === "adb") {
            const result2 = await adbRunner(["devices"], { timeoutMs: adbTimeoutMs });
            if (result2.code !== 0 || result2.timedOut) {
              return {
                targets: [],
                ok: false,
                stdout: result2.stdout,
                stderr: result2.stderr,
                error: commandFailureMessage2(protocol, result2),
                durationMs: result2.durationMs
              };
            }
            const targets2 = parseAdbDevices(result2.stdout).map((device) => ({
              targetRef: device.targetRef,
              label: device.targetRef,
              online: device.online
            }));
            return { targets: targets2, ok: true, durationMs: result2.durationMs };
          }
          const result = await hdcRunner(["list", "targets"], { timeoutMs: hdcTimeoutMs });
          if (result.code !== 0 || result.timedOut) {
            return {
              targets: [],
              ok: false,
              stdout: result.stdout,
              stderr: result.stderr,
              error: commandFailureMessage2(protocol, result),
              durationMs: result.durationMs
            };
          }
          const targets = parseHdcTargets(result.stdout).map((target) => ({
            targetRef: target.targetRef,
            label: target.targetRef,
            online: target.online
          }));
          return { targets, ok: true, durationMs: result.durationMs };
        }
        case "debug.readNode":
          return readNode(params);
        case "debug.writeNode": {
          const protocol = requireSupportedProtocol(params.protocol);
          const targetRef = readRequiredString(params.targetRef, "targetRef");
          const nodePath = readRequiredString(params.nodePath, "nodePath");
          const value = readRequiredString(params.value, "value");
          const preserveExactRead = readBoolean(params.preserveExactRead, false);
          const readBack = readBoolean(params.readBack, true);
          const remoteCommand = buildRemoteWriteShellCommand(nodePath, value);
          const writeArgs = protocol === "adb" ? ["-s", targetRef, "shell", remoteCommand] : ["-t", targetRef, "shell", remoteCommand];
          const runner = protocol === "adb" ? adbRunner : hdcRunner;
          const timeoutMs = protocol === "adb" ? adbTimeoutMs : hdcTimeoutMs;
          const writeResult = await runner(writeArgs, { timeoutMs });
          const writePayload = evaluateRemoteCommand(protocol, writeResult);
          if (!readBack || !writePayload.ok) {
            return {
              ok: writePayload.ok,
              verified: writePayload.ok && !readBack,
              error: writePayload.error,
              writeResult: writePayload
            };
          }
          const readPayload = await readNode({ protocol, targetRef, nodePath, preserveExactRead });
          const readValue = typeof readPayload.value === "string" ? readPayload.value : "";
          const expected = preserveExactRead ? value : value.trim();
          const verified = readPayload.ok === true && readValue === expected;
          return {
            ok: writePayload.ok && readPayload.ok === true && verified,
            verified,
            value: readPayload.value,
            error: verified ? void 0 : "Readback mismatch after write.",
            writeResult: writePayload,
            readResult: readPayload
          };
        }
        default:
          throw new RpcRequestError("METHOD_NOT_FOUND", `Unsupported RPC method: ${method}`);
      }
    },
    toRpcError(error) {
      if (error instanceof RpcRequestError) {
        return { code: error.code, message: error.message };
      }
      if (error instanceof Error && error.message.trim()) {
        return { code: "INTERNAL_ERROR", message: error.message };
      }
      return { code: "INTERNAL_ERROR", message: "RPC execution failed." };
    }
  };
}

// packages/device-bridge/src/createResolvedRpcHandlers.ts
async function createResolvedRpcHandlers(options = {}) {
  const [adbVersion, hdcVersion] = await Promise.all([
    getInstalledToolVersion("adb", options),
    getInstalledToolVersion("hdc", options)
  ]);
  const [adbResolved, hdcResolved] = await Promise.all([
    resolveToolBinary("adb", { ...options, installedVersion: adbVersion }),
    resolveToolBinary("hdc", { ...options, installedVersion: hdcVersion })
  ]);
  const adbRunner = createDefaultAdbCommandRunner(adbResolved.command);
  const hdcRunner = createDefaultHdcCommandRunner(hdcResolved.command);
  return {
    rpc: createRpcHandlers({
      adbRunner,
      hdcRunner,
      adbCommand: adbResolved.command,
      hdcCommand: hdcResolved.command,
      adbSource: adbResolved.source,
      hdcSource: hdcResolved.source
    }),
    probeTools: (timeoutMs) => probeTools({
      adbRunner,
      hdcRunner,
      adbSource: adbResolved.source,
      hdcSource: hdcResolved.source,
      timeoutMs
    }),
    refreshResolvedCommands: async () => createResolvedRpcHandlers(options)
  };
}

// packages/device-bridge/src/healthServer.ts
import { createServer } from "node:http";

// packages/device-bridge/src/healthState.ts
function createToolProbeCache(input) {
  const ttlMs = input.ttlMs ?? 6e4;
  const now = input.now ?? (() => Date.now());
  let cachedTools;
  let cachedAt = 0;
  let toolsInstall;
  return {
    getTools() {
      return cachedTools;
    },
    async refreshTools(force = false) {
      if (!force && cachedTools && now() - cachedAt < ttlMs) {
        return cachedTools;
      }
      cachedTools = await input.probe();
      cachedAt = now();
      return cachedTools;
    },
    setToolsInstall(next) {
      toolsInstall = next;
    },
    getToolsInstall() {
      return toolsInstall;
    }
  };
}

// packages/device-bridge/src/healthServer.ts
function isLoopbackOrigin(origin) {
  try {
    const url = new URL(origin);
    return (url.protocol === "http:" || url.protocol === "https:") && (url.hostname === "localhost" || url.hostname === "127.0.0.1");
  } catch {
    return false;
  }
}
function normalizeCorsOrigin(raw) {
  const url = new URL(raw);
  url.pathname = "";
  url.search = "";
  url.hash = "";
  return url.toString().replace(/\/$/, "");
}
function corsOriginHost(raw) {
  return new URL(raw).hostname.toLowerCase();
}
function listAllowedOrigins(allowedOrigin) {
  if (!allowedOrigin) {
    return [];
  }
  return (Array.isArray(allowedOrigin) ? allowedOrigin : [allowedOrigin]).filter(Boolean);
}
function resolveCorsOrigin(origin, allowedOrigin) {
  if (!origin) {
    return void 0;
  }
  if (isLoopbackOrigin(origin)) {
    return origin;
  }
  const normalizedOrigin = normalizeCorsOrigin(origin);
  for (const allowed of listAllowedOrigins(allowedOrigin)) {
    if (normalizeCorsOrigin(allowed) === normalizedOrigin) {
      return origin;
    }
    if (corsOriginHost(allowed) === corsOriginHost(origin)) {
      return origin;
    }
  }
  return void 0;
}
function applyCorsHeaders(res, origin, allowedOrigin) {
  const corsOrigin = resolveCorsOrigin(origin, allowedOrigin);
  if (!corsOrigin) {
    return;
  }
  res.setHeader("Access-Control-Allow-Origin", corsOrigin);
  res.setHeader("Vary", "Origin");
}
function applyOpenCorsHeaders(res, origin) {
  if (!origin) {
    return;
  }
  res.setHeader("Access-Control-Allow-Origin", origin);
  res.setHeader("Vary", "Origin");
}
function startHealthServer(input) {
  const host = input.host ?? "127.0.0.1";
  const port = input.port ?? 18787;
  const server = createServer((req, res) => {
    void (async () => {
      const requestUrl = new URL(req.url ?? "/", `http://${host}:${port}`);
      const origin = req.headers.origin;
      if (req.method === "OPTIONS" && (requestUrl.pathname === "/tools/install" || requestUrl.pathname === "/health")) {
        res.statusCode = 204;
        if (requestUrl.pathname === "/tools/install") {
          applyCorsHeaders(res, origin, input.allowedOrigin);
          res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
          res.setHeader("Access-Control-Allow-Headers", "content-type");
        } else {
          applyOpenCorsHeaders(res, origin);
          res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
        }
        res.end();
        return;
      }
      if (req.method === "POST" && requestUrl.pathname === "/tools/install") {
        applyCorsHeaders(res, origin, input.allowedOrigin);
        let body = "";
        for await (const chunk of req) {
          body += chunk.toString();
        }
        const parsed = JSON.parse(body || "{}");
        const protocol = parsed.protocol === "adb" || parsed.protocol === "hdc" || parsed.protocol === "all" ? parsed.protocol : "all";
        await input.onToolsInstall?.(protocol);
        res.statusCode = 202;
        res.setHeader("content-type", "application/json; charset=utf-8");
        res.end(`${JSON.stringify({ ok: true, accepted: true, protocol })}
`);
        return;
      }
      if (req.method === "GET" && requestUrl.pathname === "/health") {
        await input.onHealthRead?.();
        const payload = { ok: true, ...input.getState() };
        res.statusCode = 200;
        applyOpenCorsHeaders(res, origin);
        res.setHeader("content-type", "application/json; charset=utf-8");
        res.end(`${JSON.stringify(payload)}
`);
        return;
      }
      res.statusCode = 404;
      res.end("Not Found");
    })();
  });
  return new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(port, host, () => {
      server.off("error", reject);
      const address = server.address();
      const actualPort = address && typeof address === "object" ? address.port : port;
      resolve({
        url: `http://${host}:${actualPort}/health`,
        close: async () => new Promise((closeResolve, closeReject) => {
          server.closeAllConnections?.();
          server.close((error) => {
            if (error) {
              closeReject(error);
              return;
            }
            closeResolve();
          });
        })
      });
    });
  });
}

// node_modules/ws/wrapper.mjs
var import_stream = __toESM(require_stream(), 1);
var import_extension = __toESM(require_extension(), 1);
var import_permessage_deflate = __toESM(require_permessage_deflate(), 1);
var import_receiver = __toESM(require_receiver(), 1);
var import_sender = __toESM(require_sender(), 1);
var import_subprotocol = __toESM(require_subprotocol(), 1);
var import_websocket = __toESM(require_websocket(), 1);
var import_websocket_server = __toESM(require_websocket_server(), 1);
var wrapper_default = import_websocket.default;

// packages/device-bridge/src/wsClient.ts
function buildBridgeWsUrl(serverUrl) {
  const url = new URL(serverUrl);
  url.protocol = url.protocol === "https:" ? "wss:" : "ws:";
  url.pathname = "/api/v1/device-bridges/ws";
  url.search = "";
  url.hash = "";
  return url.toString();
}
function safeParseJson(payload) {
  try {
    return JSON.parse(payload);
  } catch {
    return null;
  }
}
function isBridgeHelloMessage(value) {
  return typeof value === "object" && value !== null && value.type === "bridge.hello";
}
function isBridgePongMessage(value) {
  return typeof value === "object" && value !== null && value.type === "bridge.pong";
}
function isBridgeRpcRequest(value) {
  return typeof value === "object" && value !== null && value.type === "rpc.request";
}
function createBridgeWsClient(options) {
  const reconnectDelayMs = options.reconnectDelayMs ?? 2e3;
  const fallbackPingIntervalMs = options.pingIntervalMs ?? 15e3;
  const websocketFactory = options.websocketFactory ?? ((url, init) => new wrapper_default(url, init));
  const now = options.now ?? (() => /* @__PURE__ */ new Date());
  const logger = options.logger ?? console;
  const wsUrl = buildBridgeWsUrl(options.serverUrl);
  let socket = null;
  let running = false;
  let reconnectTimer = null;
  let pingTimer = null;
  let status = {
    connected: false,
    serverUrl: options.serverUrl,
    updatedAt: now().toISOString()
  };
  function publishStatus(next) {
    status = {
      ...status,
      ...next,
      updatedAt: now().toISOString()
    };
    options.onStatusChange?.(status);
  }
  function clearPingTimer() {
    if (pingTimer) {
      clearInterval(pingTimer);
      pingTimer = null;
    }
  }
  function scheduleReconnect() {
    if (!running || reconnectTimer) {
      return;
    }
    reconnectTimer = setTimeout(() => {
      reconnectTimer = null;
      if (running) {
        connect();
      }
    }, reconnectDelayMs);
  }
  function sendJson(payload) {
    if (!socket || socket.readyState !== wrapper_default.OPEN) {
      return;
    }
    socket.send(JSON.stringify(payload));
  }
  function handleHello(message) {
    publishStatus({
      connected: true,
      bridgeId: message.bridgeId,
      lastError: void 0
    });
    clearPingTimer();
    const heartbeatIntervalMs = Number.isFinite(message.heartbeatIntervalMs) ? Math.max(1e3, message.heartbeatIntervalMs) : fallbackPingIntervalMs;
    pingTimer = setInterval(() => {
      sendJson({ type: "bridge.ping", sentAt: now().toISOString() });
    }, heartbeatIntervalMs);
  }
  async function handleRpcRequest(message) {
    try {
      const result = await options.rpc.handle(message.method, message.params ?? {});
      const response = { type: "rpc.response", id: message.id, ok: true, result };
      sendJson(response);
    } catch (error) {
      const response = {
        type: "rpc.response",
        id: message.id,
        ok: false,
        error: options.rpc.toRpcError(error)
      };
      sendJson(response);
    }
  }
  function connect() {
    const nextSocket = websocketFactory(wsUrl, {
      headers: {
        Authorization: `Bridge ${options.bridgeToken}`
      }
    });
    socket = nextSocket;
    nextSocket.on("open", () => {
      logger.info(`[wiseeff-bridge] connected ${wsUrl}`);
      publishStatus({ connected: true, lastError: void 0 });
    });
    nextSocket.on("message", (raw) => {
      const payload = typeof raw === "string" ? raw : raw.toString("utf8");
      const parsed = safeParseJson(payload);
      if (!parsed) {
        return;
      }
      if (isBridgeHelloMessage(parsed)) {
        handleHello(parsed);
        return;
      }
      if (isBridgePongMessage(parsed)) {
        publishStatus({ connected: true, lastError: void 0 });
        return;
      }
      if (isBridgeRpcRequest(parsed)) {
        void handleRpcRequest(parsed);
      }
    });
    nextSocket.on("error", (error) => {
      publishStatus({ connected: false, lastError: error.message });
      logger.error(`[wiseeff-bridge] websocket error: ${error.message}`);
    });
    nextSocket.on("close", (code, reason) => {
      const reasonText = typeof reason === "string" ? reason : reason.toString("utf8");
      if (code === 4401 && reasonText.trim()) {
        publishStatus({ connected: false, lastError: reasonText.trim() });
      } else {
        publishStatus({ connected: false });
      }
      clearPingTimer();
      scheduleReconnect();
    });
  }
  return {
    start() {
      if (running) {
        return;
      }
      running = true;
      connect();
    },
    stop() {
      running = false;
      clearPingTimer();
      if (reconnectTimer) {
        clearTimeout(reconnectTimer);
        reconnectTimer = null;
      }
      if (socket && socket.readyState <= wrapper_default.OPEN) {
        socket.close();
      }
      socket = null;
      publishStatus({ connected: false });
    },
    getStatus() {
      return { ...status };
    }
  };
}

// packages/device-bridge/src/windowsService.ts
import { execFile as defaultExecFile } from "node:child_process";
import fs from "node:fs/promises";
import os3 from "node:os";
import path4 from "node:path";
import { promisify } from "node:util";
var WISEEFF_BRIDGE_SERVICE_NAME = "WiseEffBridge";
var WISEEFF_BRIDGE_SERVICE_DISPLAY_NAME = "WiseEff Device Bridge";
var execFileAsync = promisify(defaultExecFile);
function createDefaultExecFile() {
  return async (file, args, options) => {
    const { stdout, stderr } = await execFileAsync(file, args, {
      ...options,
      encoding: "utf8"
    });
    return { stdout: String(stdout), stderr: String(stderr) };
  };
}
function isWindowsPlatform(platform) {
  return platform === "win32";
}
function getServiceWrapperPath(homedir = os3.homedir) {
  return path4.win32.join(homedir(), "AppData", "Local", "WiseEff", "device-bridge", "start-service.cmd");
}
function buildServiceWrapperContent(nodePath, cliPath) {
  return `@echo off\r
"${nodePath}" "${cliPath}" start\r
`;
}
function formatScBinPath(wrapperPath) {
  if (wrapperPath.includes(" ")) {
    return `binPath= "${wrapperPath}"`;
  }
  return `binPath= ${wrapperPath}`;
}
async function runSc(deps, args) {
  return deps.execFile("sc.exe", args, { windowsHide: true });
}
function unsupportedPlatformMessage() {
  return "Windows service commands are only supported on Windows.";
}
function assertWindowsPlatform(deps) {
  if (isWindowsPlatform(deps.platform)) {
    return true;
  }
  deps.error(unsupportedPlatformMessage());
  return false;
}
function execFailureMessage(error) {
  if (error instanceof Error) {
    return error.message;
  }
  return String(error);
}
async function installWindowsService(deps) {
  if (!assertWindowsPlatform(deps)) {
    return 1;
  }
  const wrapperPath = getServiceWrapperPath(deps.homedir);
  await deps.mkdir(path4.win32.dirname(wrapperPath), { recursive: true });
  await deps.writeFile(wrapperPath, buildServiceWrapperContent(deps.nodePath, deps.cliPath), "utf8");
  const createArgs = [
    "create",
    WISEEFF_BRIDGE_SERVICE_NAME,
    formatScBinPath(wrapperPath),
    "start=auto",
    `DisplayName=${WISEEFF_BRIDGE_SERVICE_DISPLAY_NAME}`
  ];
  try {
    await runSc(deps, createArgs);
  } catch (error) {
    const message = execFailureMessage(error);
    if (!(message.includes("1073") || message.toLowerCase().includes("already exists"))) {
      deps.error(`Failed to install Windows service: ${message}`);
      return 1;
    }
    try {
      await runSc(deps, ["stop", WISEEFF_BRIDGE_SERVICE_NAME]);
    } catch {
    }
    try {
      await runSc(deps, ["delete", WISEEFF_BRIDGE_SERVICE_NAME]);
    } catch (deleteError) {
      deps.error(`Failed to reinstall Windows service: ${execFailureMessage(deleteError)}`);
      return 1;
    }
    try {
      await runSc(deps, createArgs);
    } catch (recreateError) {
      deps.error(`Failed to reinstall Windows service: ${execFailureMessage(recreateError)}`);
      return 1;
    }
    deps.log(`Reinstalled Windows service ${WISEEFF_BRIDGE_SERVICE_NAME}.`);
    deps.log(`Wrapper script: ${wrapperPath}`);
    return 0;
  }
  deps.log(`Installed Windows service ${WISEEFF_BRIDGE_SERVICE_NAME}.`);
  deps.log(`Wrapper script: ${wrapperPath}`);
  return 0;
}
async function startWindowsService(deps) {
  if (!assertWindowsPlatform(deps)) {
    return 1;
  }
  try {
    await runSc(deps, ["start", WISEEFF_BRIDGE_SERVICE_NAME]);
  } catch (error) {
    deps.error(`Failed to start Windows service: ${execFailureMessage(error)}`);
    return 1;
  }
  deps.log(`Started Windows service ${WISEEFF_BRIDGE_SERVICE_NAME}.`);
  return 0;
}
async function stopWindowsService(deps) {
  if (!assertWindowsPlatform(deps)) {
    return 1;
  }
  try {
    await runSc(deps, ["stop", WISEEFF_BRIDGE_SERVICE_NAME]);
  } catch (error) {
    deps.error(`Failed to stop Windows service: ${execFailureMessage(error)}`);
    return 1;
  }
  deps.log(`Stopped Windows service ${WISEEFF_BRIDGE_SERVICE_NAME}.`);
  return 0;
}
async function uninstallWindowsService(deps) {
  if (!assertWindowsPlatform(deps)) {
    return 1;
  }
  try {
    await runSc(deps, ["stop", WISEEFF_BRIDGE_SERVICE_NAME]);
  } catch {
  }
  try {
    await runSc(deps, ["delete", WISEEFF_BRIDGE_SERVICE_NAME]);
  } catch (error) {
    deps.error(`Failed to uninstall Windows service: ${execFailureMessage(error)}`);
    return 1;
  }
  const wrapperPath = getServiceWrapperPath(deps.homedir);
  try {
    await deps.unlink(wrapperPath);
  } catch {
  }
  deps.log(`Uninstalled Windows service ${WISEEFF_BRIDGE_SERVICE_NAME}.`);
  return 0;
}
async function runWindowsServiceCommand(action, overrides = {}) {
  const deps = {
    execFile: overrides.execFile ?? createDefaultExecFile(),
    platform: overrides.platform ?? process.platform,
    homedir: overrides.homedir ?? os3.homedir,
    writeFile: overrides.writeFile ?? fs.writeFile,
    mkdir: overrides.mkdir ?? fs.mkdir,
    unlink: overrides.unlink ?? fs.unlink,
    nodePath: overrides.nodePath ?? process.execPath,
    cliPath: overrides.cliPath ?? "",
    log: overrides.log ?? console.log,
    error: overrides.error ?? console.error
  };
  switch (action) {
    case "install":
      return installWindowsService(deps);
    case "start":
      return startWindowsService(deps);
    case "stop":
      return stopWindowsService(deps);
    case "uninstall":
      return uninstallWindowsService(deps);
    default:
      deps.error(`Unknown service action: ${String(action)}`);
      return 1;
  }
}

// packages/device-bridge/src/connectCommand.ts
import os4 from "node:os";

// packages/device-bridge/src/localBridgeProcess.ts
import { execFile } from "node:child_process";
import { promisify as promisify2 } from "node:util";
var execFileAsync2 = promisify2(execFile);
async function stopLocalBridgeHealthListener(platform, port = 18787) {
  if (platform === "win32") {
    try {
      const { stdout } = await execFileAsync2("netstat", ["-ano", "-p", "tcp"]);
      const pids = /* @__PURE__ */ new Set();
      for (const line of stdout.split(/\r?\n/)) {
        if (!line.includes(`:${port}`) || !/LISTENING/i.test(line)) {
          continue;
        }
        const pid = Number(line.trim().split(/\s+/).at(-1));
        if (Number.isInteger(pid) && pid > 0) {
          pids.add(pid);
        }
      }
      for (const pid of pids) {
        await execFileAsync2("taskkill", ["/PID", String(pid), "/F"]);
      }
      if (pids.size > 0) {
        await new Promise((resolve) => setTimeout(resolve, 500));
      }
    } catch {
    }
    return;
  }
  try {
    const { stdout } = await execFileAsync2("lsof", ["-ti", `tcp:${port}`, "-sTCP:LISTEN"]);
    const pids = stdout.trim().split("\n").map((value) => Number(value.trim())).filter((pid) => Number.isInteger(pid) && pid > 0);
    for (const pid of pids) {
      process.kill(pid, "SIGTERM");
    }
    if (pids.length > 0) {
      await new Promise((resolve) => setTimeout(resolve, 500));
    }
  } catch {
  }
}
async function waitForLocalBridgeConnection(fetchImpl, timeoutMs = 1e4, intervalMs = 500) {
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    const health = await probeLocalBridgeHealth(fetchImpl);
    if (health?.connected) {
      return health;
    }
    await new Promise((resolve) => setTimeout(resolve, intervalMs));
  }
  return probeLocalBridgeHealth(fetchImpl);
}
async function probeLocalBridgeHealth(fetchImpl) {
  try {
    const response = await fetchImpl("http://127.0.0.1:18787/health");
    if (!response.ok) {
      return null;
    }
    const body = await response.json();
    return {
      connected: Boolean(body.connected),
      paired: typeof body.paired === "boolean" ? body.paired : void 0
    };
  } catch {
    return null;
  }
}

// packages/device-bridge/src/connectCommand.ts
var BRIDGE_VERSION = "0.1.0";
function normalizeServerUrl(raw) {
  const url = new URL(raw);
  url.pathname = "";
  url.search = "";
  url.hash = "";
  return url.toString().replace(/\/$/, "");
}
function isPairingCode(code) {
  return /^\d{6}$/.test(code);
}
function isBridgeTokenExpired(tokenExpiresAt, now = Date.now()) {
  const expires = new Date(tokenExpiresAt);
  return Number.isNaN(expires.getTime()) || expires.getTime() <= now;
}
async function runPairCommand(parsed, deps) {
  const server = parsed.flags.get("server");
  const code = parsed.flags.get("code");
  const webOrigin = parsed.flags.get("webOrigin");
  if (!server || !code) {
    deps.stdout.error("Missing required flags for pair.");
    return { exitCode: 1 };
  }
  if (!isPairingCode(code)) {
    deps.stdout.error("Pairing code must be a 6-digit number.");
    return { exitCode: 1 };
  }
  const normalizedServerUrl = normalizeServerUrl(server);
  const resolvedWebOrigin = webOrigin ? normalizeCorsOrigin(webOrigin) : new URL(normalizedServerUrl).origin;
  const requestBody = {
    code,
    machineLabel: os4.hostname(),
    platform: detectBridgePlatform(),
    arch: process.arch,
    clientVersion: BRIDGE_VERSION
  };
  const response = await deps.fetchImpl(`${normalizedServerUrl}/api/v1/device-bridges/pair`, {
    method: "POST",
    headers: {
      "content-type": "application/json"
    },
    body: JSON.stringify(requestBody)
  });
  if (!response.ok) {
    const body = await response.text();
    deps.stdout.error(`Pair request failed (${response.status}): ${body}`);
    return { exitCode: 1 };
  }
  const payload = await response.json();
  if (!payload.bridgeId || !payload.bridgeToken || !payload.tokenExpiresAt) {
    deps.stdout.error("Pair response is missing required fields.");
    return { exitCode: 1 };
  }
  const config = {
    bridgeId: payload.bridgeId,
    bridgeToken: payload.bridgeToken,
    tokenExpiresAt: payload.tokenExpiresAt,
    serverUrl: normalizedServerUrl,
    webOrigin: resolvedWebOrigin,
    machineLabel: requestBody.machineLabel,
    platform: requestBody.platform,
    arch: requestBody.arch,
    clientVersion: requestBody.clientVersion,
    pairedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  await deps.saveConfig(config);
  deps.stdout.log(`Paired bridge ${config.bridgeId} with ${config.serverUrl}`);
  return { exitCode: 0, config };
}
function waitForTerminationSignal() {
  return new Promise((resolve) => {
    const shutdown = () => {
      process.off("SIGINT", shutdown);
      process.off("SIGTERM", shutdown);
      resolve();
    };
    process.on("SIGINT", shutdown);
    process.on("SIGTERM", shutdown);
  });
}
async function runConnectCommand(deps, input) {
  const existing = await deps.loadConfig();
  const normalizedServer = normalizeServerUrl(input.server);
  const explicitWebOrigin = input.webOrigin ? normalizeCorsOrigin(input.webOrigin) : void 0;
  const derivedWebOrigin = explicitWebOrigin ?? new URL(normalizedServer).origin;
  const serverMatches = existing?.serverUrl === normalizedServer;
  const tokenValid = existing && !isBridgeTokenExpired(existing.tokenExpiresAt);
  if (input.code) {
    const pairFlags = /* @__PURE__ */ new Map([
      ["server", input.server],
      ["code", input.code]
    ]);
    if (derivedWebOrigin) {
      pairFlags.set("webOrigin", derivedWebOrigin);
    }
    const pairResult = await runPairCommand(
      {
        flags: pairFlags
      },
      deps
    );
    if (pairResult.exitCode !== 0) {
      return pairResult;
    }
  } else if (!existing || !serverMatches || !tokenValid) {
    if (existing && serverMatches && !tokenValid) {
      deps.stdout.error("Bridge token expired. Pass --code with a new 6-digit pairing code to re-pair.");
    } else {
      deps.stdout.error("Pairing code required. Pass --code with a 6-digit pairing code.");
    }
    return { exitCode: 1 };
  }
  let config = await deps.loadConfig();
  if (!config) {
    deps.stdout.error("Bridge is not paired.");
    return { exitCode: 1 };
  }
  if (explicitWebOrigin && config.webOrigin !== explicitWebOrigin) {
    config = { ...config, webOrigin: explicitWebOrigin };
    await deps.saveConfig(config);
    await stopLocalBridgeHealthListener(deps.platform);
  }
  return deps.ensureBridgeRunning({
    fetchImpl: deps.fetchImpl,
    platform: deps.platform,
    execPath: deps.execPath,
    cliPath: deps.cliPath,
    stdout: deps.stdout
  });
}

// packages/device-bridge/src/ensureBridgeRunning.ts
import { spawn } from "node:child_process";
async function probeLocalBridgeHealth2(fetchImpl) {
  try {
    const response = await fetchImpl("http://127.0.0.1:18787/health");
    if (!response.ok) {
      return null;
    }
    const body = await response.json();
    return {
      connected: Boolean(body.connected),
      paired: typeof body.paired === "boolean" ? body.paired : void 0
    };
  } catch {
    return null;
  }
}
function spawnDetachedStart(deps) {
  const child = spawn(deps.execPath, [deps.cliPath, "start"], {
    detached: true,
    stdio: "ignore",
    windowsHide: true
  });
  child.unref();
  deps.stdout.log("Started bridge in background.");
}
async function ensureBridgeRunning(deps) {
  const health = await probeLocalBridgeHealth2(deps.fetchImpl);
  if (health?.connected) {
    deps.stdout.log("Bridge already connected.");
    return { exitCode: 0 };
  }
  if (deps.platform === "win32") {
    const serviceExit = await runWindowsServiceCommand("start", {
      platform: deps.platform,
      cliPath: deps.cliPath,
      nodePath: deps.execPath,
      log: (message) => deps.stdout.log(message),
      error: (message) => deps.stdout.error(message)
    });
    if (serviceExit === 0) {
      return { exitCode: 0 };
    }
  }
  if (health && !health.connected) {
    await stopLocalBridgeHealthListener(deps.platform);
    const restarted = await waitForLocalBridgeConnection(deps.fetchImpl);
    if (restarted?.connected) {
      deps.stdout.log("Bridge reconnected.");
      return { exitCode: 0 };
    }
  }
  spawnDetachedStart(deps);
  const connected = await waitForLocalBridgeConnection(deps.fetchImpl);
  if (connected?.connected) {
    deps.stdout.log("Bridge connected.");
  }
  return { exitCode: 0 };
}

// packages/device-bridge/src/toolsInstallCommand.ts
import { createHash } from "node:crypto";
import { spawnSync } from "node:child_process";
import { chmod, mkdir as mkdir3, readFile as readFile3, writeFile as writeFile3 } from "node:fs/promises";
import path5 from "node:path";
function normalizeArch(arch) {
  if (arch === "x64" || arch === "x86_64") {
    return "amd64";
  }
  if (arch === "arm64" || arch === "aarch64") {
    return "arm64";
  }
  return arch;
}
function resolveHostArch(platform = process.platform) {
  return normalizeArch(process.arch);
}
async function sha256File(filePath) {
  const content = await readFile3(filePath);
  return createHash("sha256").update(content).digest("hex");
}
async function defaultExtractArchive(archivePath, destination) {
  await mkdir3(destination, { recursive: true });
  if (archivePath.endsWith(".zip")) {
    if (process.platform === "win32") {
      const result2 = spawnSync(
        "powershell",
        ["-NoProfile", "-Command", `Expand-Archive -Path '${archivePath.replace(/'/g, "''")}' -DestinationPath '${destination.replace(/'/g, "''")}' -Force`],
        { encoding: "utf8" }
      );
      if (result2.status !== 0) {
        throw new Error(result2.stderr || "Failed to extract zip archive.");
      }
      return;
    }
    const result = spawnSync("unzip", ["-o", archivePath, "-d", destination], { encoding: "utf8" });
    if (result.status !== 0) {
      throw new Error(result.stderr || "Failed to extract zip archive.");
    }
    return;
  }
  if (archivePath.endsWith(".tar.gz") || archivePath.endsWith(".tgz")) {
    const result = spawnSync("tar", ["-xzf", archivePath, "-C", destination], { encoding: "utf8" });
    if (result.status !== 0) {
      throw new Error(result.stderr || "Failed to extract tar.gz archive.");
    }
    return;
  }
  throw new Error(`Unsupported archive format: ${path5.basename(archivePath)}`);
}
async function chmodExecutable(filePath) {
  if (process.platform === "win32") {
    return;
  }
  await chmod(filePath, 493);
}
async function ensureManagedBinaryLayout(protocol, version, toolsRoot) {
  const managedPath = resolveManagedToolPath(protocol, version, { toolsRoot, platform: process.platform });
  if (protocol === "adb") {
    const platformToolsDir = path5.dirname(managedPath);
    const nestedAdb = path5.join(platformToolsDir, process.platform === "win32" ? "adb.exe" : "adb");
    try {
      await readFile3(nestedAdb);
      if (nestedAdb !== managedPath) {
        await mkdir3(path5.dirname(managedPath), { recursive: true });
        await writeFile3(managedPath, await readFile3(nestedAdb));
        await chmodExecutable(managedPath);
      }
    } catch {
    }
  }
  await chmodExecutable(managedPath);
}
async function fetchToolReleaseManifest(serverUrl, fetchImpl = fetch) {
  const response = await fetchImpl(`${serverUrl.replace(/\/$/, "")}/api/v1/device-bridges/tool-releases`);
  if (!response.ok) {
    throw new Error(`Tool release manifest request failed with ${response.status}.`);
  }
  return await response.json();
}
function selectToolReleaseItems(input) {
  const platform = input.platform ?? detectBridgePlatform();
  const arch = normalizeArch(input.arch ?? resolveHostArch());
  const protocols = input.protocol === "all" ? ["adb", "hdc"] : [input.protocol];
  return protocols.map((protocol) => {
    const item = input.manifest.items.find(
      (entry) => entry.platform === platform && entry.arch === arch && entry.protocol === protocol
    );
    if (!item) {
      throw new Error(`No tool artifact found for ${platform}/${arch}/${protocol}.`);
    }
    return item;
  });
}
async function installToolReleaseItem(input) {
  const fetchImpl = input.fetchImpl ?? fetch;
  const toolsRoot = input.toolsRoot ?? resolveToolsRoot();
  const extract = input.extractArchive ?? defaultExtractArchive;
  const installedVersion = await getInstalledToolVersion(input.item.protocol, { toolsRoot });
  if (!input.force && installedVersion === input.item.version) {
    const state = await readToolInstallState({ toolsRoot });
    const record = state[input.item.protocol];
    if (record?.sha256 === input.item.sha256) {
      return { skipped: true, item: input.item };
    }
  }
  const downloadUrl = new URL(input.item.downloadUrl, input.serverUrl).toString();
  const response = await fetchImpl(downloadUrl);
  if (!response.ok) {
    throw new Error(`Tool download failed with ${response.status}.`);
  }
  const tempDir = path5.join(toolsRoot, ".tmp", `${input.item.protocol}-${Date.now()}`);
  const archivePath = path5.join(tempDir, path5.basename(input.item.downloadUrl));
  await mkdir3(path5.dirname(archivePath), { recursive: true });
  await writeFile3(archivePath, Buffer.from(await response.arrayBuffer()));
  const digest = await sha256File(archivePath);
  if (digest !== input.item.sha256) {
    throw new Error(`SHA256 mismatch for ${input.item.protocol} artifact.`);
  }
  const extractRoot = path5.join(toolsRoot, input.item.protocol, input.item.version);
  await mkdir3(extractRoot, { recursive: true });
  await extract(archivePath, extractRoot);
  await ensureManagedBinaryLayout(input.item.protocol, input.item.version, toolsRoot);
  await recordToolInstall(
    input.item.protocol,
    {
      version: input.item.version,
      sha256: input.item.sha256,
      installedAt: (/* @__PURE__ */ new Date()).toISOString()
    },
    { toolsRoot }
  );
  return { skipped: false, item: input.item };
}
async function runToolsInstallCommand(input) {
  input.onStatus?.({ status: "running", protocol: input.protocol });
  try {
    const manifest = await fetchToolReleaseManifest(input.serverUrl, input.fetchImpl);
    const items = selectToolReleaseItems({
      manifest,
      protocol: input.protocol,
      platform: input.platform,
      arch: input.arch
    });
    for (const item of items) {
      await installToolReleaseItem({
        serverUrl: input.serverUrl,
        item,
        toolsRoot: input.toolsRoot,
        fetchImpl: input.fetchImpl,
        force: input.force,
        extractArchive: input.extractArchive
      });
    }
    input.onStatus?.({ status: "succeeded", protocol: input.protocol });
    return { ok: true, items };
  } catch (error) {
    const message = error instanceof Error ? error.message : "Tool install failed.";
    input.onStatus?.({ status: "failed", protocol: input.protocol, error: message });
    throw error;
  }
}

// packages/device-bridge/src/toolsInstallCli.ts
async function runToolsInstallCliCommand(deps, input) {
  const config = await deps.loadConfig();
  const serverUrl = input.server ?? config?.serverUrl;
  if (!serverUrl) {
    deps.stdout.error("Missing server URL. Pass --server or pair the bridge first.");
    return 1;
  }
  try {
    await runToolsInstallCommand({
      serverUrl,
      protocol: input.protocol,
      fetchImpl: deps.fetchImpl,
      force: input.force,
      onStatus: (status) => {
        if (status.status === "running") {
          deps.stdout.log(`Installing ${status.protocol ?? "tools"}...`);
        }
        if (status.status === "failed") {
          deps.stdout.error(status.error ?? "Tool install failed.");
        }
        if (status.status === "succeeded") {
          deps.stdout.log("Tool install completed.");
        }
      }
    });
    return 0;
  } catch (error) {
    deps.stdout.error(error instanceof Error ? error.message : "Tool install failed.");
    return 1;
  }
}
function kickOffInstallTools(input) {
  void runToolsInstallCommand({
    serverUrl: input.serverUrl,
    protocol: input.protocol,
    fetchImpl: input.fetchImpl,
    onStatus: input.onStatus
  }).catch(() => void 0);
}

// packages/device-bridge/src/urlScheme.ts
function isInstallProtocol(value) {
  return value === "adb" || value === "hdc" || value === "all";
}
function parseInstallToolsUrl(raw) {
  const url = new URL(raw);
  if (url.protocol !== "wiseeff-bridge:" || url.hostname !== "install-tools") {
    throw new Error("Unsupported bridge URL");
  }
  const server = url.searchParams.get("server");
  const protocol = url.searchParams.get("protocol") ?? "all";
  if (!server) {
    throw new Error("Missing server");
  }
  if (!isAllowedConnectServerUrl(server)) {
    throw new Error("Server URL must use https or local http");
  }
  if (!isInstallProtocol(protocol)) {
    throw new Error("Protocol must be adb, hdc, or all");
  }
  return { server: normalizeConnectServerUrl(server), protocol };
}
function parseBridgeUrl(raw) {
  const url = new URL(raw);
  if (url.protocol !== "wiseeff-bridge:") {
    throw new Error("Unsupported bridge URL");
  }
  if (url.hostname === "connect") {
    return { kind: "connect", ...parseConnectUrl(raw) };
  }
  if (url.hostname === "install-tools") {
    return { kind: "install-tools", ...parseInstallToolsUrl(raw) };
  }
  throw new Error("Unsupported bridge URL");
}
function isPairingCode2(code) {
  return /^\d{6}$/.test(code);
}
function normalizeConnectServerUrl(raw) {
  const url = new URL(raw);
  url.pathname = "";
  url.search = "";
  url.hash = "";
  return url.toString().replace(/\/$/, "");
}
function isAllowedConnectServerUrl(raw) {
  const url = new URL(raw);
  if (url.protocol === "https:") {
    return true;
  }
  if (url.protocol === "http:") {
    const host = url.hostname.toLowerCase();
    return host === "localhost" || host === "127.0.0.1" || host === "[::1]";
  }
  return false;
}
function parseConnectUrl(raw) {
  const url = new URL(raw);
  if (url.protocol !== "wiseeff-bridge:" || url.hostname !== "connect") {
    throw new Error("Unsupported bridge URL");
  }
  const server = url.searchParams.get("server");
  const webOrigin = url.searchParams.get("webOrigin") ?? void 0;
  const code = url.searchParams.get("code") ?? void 0;
  if (!server) {
    throw new Error("Missing server");
  }
  if (!isAllowedConnectServerUrl(server)) {
    throw new Error("Server URL must use https or local http");
  }
  if (webOrigin !== void 0 && !isAllowedConnectServerUrl(webOrigin)) {
    throw new Error("Web origin must use https or local http");
  }
  if (code !== void 0 && !isPairingCode2(code)) {
    throw new Error("Pairing code must be a 6-digit number");
  }
  return {
    server: normalizeConnectServerUrl(server),
    webOrigin: webOrigin ? normalizeConnectServerUrl(webOrigin) : void 0,
    code
  };
}

// packages/device-bridge/src/cli.ts
var CLI_ENTRY_PATH = fileURLToPath(import.meta.url);
var SERVICE_ACTIONS = /* @__PURE__ */ new Set(["install", "start", "stop", "uninstall"]);
function parseFlags(tokens) {
  const flags = /* @__PURE__ */ new Map();
  for (let index = 0; index < tokens.length; index += 1) {
    const token = tokens[index];
    if (!token.startsWith("--")) {
      continue;
    }
    const key = token.slice(2);
    const next = tokens[index + 1];
    if (next && !next.startsWith("--")) {
      flags.set(key, next);
      index += 1;
      continue;
    }
    flags.set(key, "true");
  }
  return flags;
}
function parseArgs(argv) {
  for (let index = 0; index < argv.length; index += 1) {
    if (argv[index] === "--handle-url" && argv[index + 1]) {
      return { flags: /* @__PURE__ */ new Map([["handle-url", argv[index + 1]]]) };
    }
  }
  const [command, ...rest] = argv;
  if (command === "service") {
    const [serviceAction, ...serviceRest] = rest;
    if (serviceAction && SERVICE_ACTIONS.has(serviceAction)) {
      return { command: "service", serviceAction, flags: parseFlags(serviceRest) };
    }
    return { command: "service", flags: parseFlags(rest) };
  }
  if (command === "tools") {
    const [toolsAction, ...toolsRest] = rest;
    if (toolsAction === "install") {
      return { command: "tools", toolsAction: "install", flags: parseFlags(toolsRest) };
    }
    return { command: "tools", flags: parseFlags(rest) };
  }
  if (command === "pair" || command === "start" || command === "status" || command === "connect") {
    return { command, flags: parseFlags(rest) };
  }
  return { flags: parseFlags(rest) };
}
function usage() {
  return [
    "wiseeff-bridge <command>",
    "",
    "Commands:",
    "  connect --server <url> [--code <6-digit-code>]",
    "  pair --server <url> --code <6-digit-code>",
    "  start",
    "  status",
    "  service install   Register background service (Windows only)",
    "  service start     Start installed service (Windows only)",
    "  service stop      Stop installed service (Windows only)",
    "  service uninstall Remove installed service (Windows only)",
    "  tools install --protocol adb|hdc|all [--server <url>] [--force]",
    "",
    "Options:",
    "  --handle-url <wiseeff-bridge://...>  Handle URL scheme activation"
  ].join("\n");
}
async function runStartCommand(deps, config) {
  const runtime = await createResolvedRpcHandlers();
  const toolProbeCache = createToolProbeCache({
    probe: () => runtime.probeTools()
  });
  await toolProbeCache.refreshTools(true);
  let status = {
    paired: true,
    connected: false,
    bridgeId: config.bridgeId,
    serverUrl: config.serverUrl,
    tokenExpiresAt: config.tokenExpiresAt,
    lastError: void 0,
    updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
    tools: toolProbeCache.getTools(),
    toolsInstall: toolProbeCache.getToolsInstall()
  };
  const wsClient = createBridgeWsClient({
    serverUrl: config.serverUrl,
    bridgeToken: config.bridgeToken,
    rpc: runtime.rpc,
    onStatusChange: (next) => {
      status = {
        paired: true,
        connected: next.connected,
        bridgeId: next.bridgeId ?? config.bridgeId,
        serverUrl: config.serverUrl,
        tokenExpiresAt: config.tokenExpiresAt,
        lastError: next.lastError,
        updatedAt: next.updatedAt,
        tools: toolProbeCache.getTools(),
        toolsInstall: toolProbeCache.getToolsInstall()
      };
    }
  });
  const health = await startHealthServer({
    getState: () => status,
    allowedOrigin: [config.webOrigin, config.serverUrl].filter(Boolean),
    onHealthRead: async () => {
      await toolProbeCache.refreshTools();
      status = {
        ...status,
        tools: toolProbeCache.getTools(),
        toolsInstall: toolProbeCache.getToolsInstall(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      };
    },
    onToolsInstall: async (protocol) => {
      toolProbeCache.setToolsInstall({
        status: "running",
        protocol,
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      });
      status = {
        ...status,
        toolsInstall: toolProbeCache.getToolsInstall(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      };
      kickOffInstallTools({
        serverUrl: config.serverUrl,
        protocol,
        fetchImpl: deps.fetchImpl,
        onStatus: (next) => {
          toolProbeCache.setToolsInstall({
            status: next.status,
            protocol: next.protocol,
            error: next.error,
            updatedAt: (/* @__PURE__ */ new Date()).toISOString()
          });
          if (next.status === "succeeded") {
            void toolProbeCache.refreshTools(true).then((tools) => {
              status = {
                ...status,
                tools,
                toolsInstall: toolProbeCache.getToolsInstall(),
                updatedAt: (/* @__PURE__ */ new Date()).toISOString()
              };
            });
            return;
          }
          status = {
            ...status,
            toolsInstall: toolProbeCache.getToolsInstall(),
            updatedAt: (/* @__PURE__ */ new Date()).toISOString()
          };
        }
      });
    }
  });
  wsClient.start();
  deps.stdout.log(`Bridge started. Health: ${health.url}`);
  deps.stdout.log("Press Ctrl+C to stop.");
  await waitForTerminationSignal();
  wsClient.stop();
  await health.close();
  deps.stdout.log("Bridge stopped.");
  return { exitCode: 0, statusLine: status.connected ? "connected" : "disconnected" };
}
async function runStandbyStartCommand(deps) {
  const existingHealth = await deps.fetchImpl("http://127.0.0.1:18787/health").catch(() => null);
  if (existingHealth?.ok) {
    deps.stdout.log("Bridge service already running.");
    return 0;
  }
  const runtime = await createResolvedRpcHandlers();
  const toolProbeCache = createToolProbeCache({
    probe: () => runtime.probeTools()
  });
  let status = {
    paired: false,
    connected: false,
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  try {
    const health = await startHealthServer({
      getState: () => status,
      onHealthRead: async () => {
        await toolProbeCache.refreshTools();
        status = {
          ...status,
          tools: toolProbeCache.getTools(),
          toolsInstall: toolProbeCache.getToolsInstall(),
          updatedAt: (/* @__PURE__ */ new Date()).toISOString()
        };
      }
    });
    await toolProbeCache.refreshTools(true);
    status = {
      ...status,
      tools: toolProbeCache.getTools(),
      toolsInstall: toolProbeCache.getToolsInstall()
    };
    deps.stdout.log(`Bridge standby started. Health: ${health.url}`);
    deps.stdout.log("Pair from the web UI to finish setup.");
    await waitForTerminationSignal();
    await health.close();
    deps.stdout.log("Bridge stopped.");
    return 0;
  } catch (error) {
    if (error instanceof Error && "code" in error && error.code === "EADDRINUSE") {
      deps.stdout.log("Bridge service already running.");
      return 0;
    }
    throw error;
  }
}
async function runStatusCommand(deps, config) {
  const response = await deps.fetchImpl("http://127.0.0.1:18787/health").catch(() => null);
  if (!response || !response.ok) {
    if (config) {
      deps.stdout.log(`paired bridge=${config.bridgeId} server=${config.serverUrl} bridgeStatus=offline`);
      return 0;
    }
    deps.stdout.log("bridgeStatus=offline paired=false");
    return 0;
  }
  const payload = await response.json();
  if (!config) {
    const bridgeStatus2 = payload.connected ? "connected" : "disconnected";
    const paired = payload.paired === true ? "true" : "false";
    deps.stdout.log(`bridgeStatus=${bridgeStatus2} paired=${paired}`);
    return 0;
  }
  const bridgeStatus = payload.connected ? "connected" : "disconnected";
  const lastError = typeof payload.lastError === "string" && payload.lastError ? ` error=${payload.lastError}` : "";
  deps.stdout.log(`paired bridge=${config.bridgeId} server=${config.serverUrl} bridgeStatus=${bridgeStatus}${lastError}`);
  return 0;
}
async function runCli(argv = process.argv.slice(2), overrides = {}) {
  const deps = {
    fetchImpl: overrides.fetchImpl ?? fetch,
    loadConfig: overrides.loadConfig ?? (() => loadBridgeConfig()),
    saveConfig: overrides.saveConfig ?? ((config2) => saveBridgeConfig(config2)),
    stdout: overrides.stdout ?? console
  };
  const startBridge = overrides.startBridge ?? ((config2) => runStartCommand(deps, config2));
  const connectDeps = {
    ...deps,
    ensureBridgeRunning: overrides.ensureBridgeRunning ?? ensureBridgeRunning,
    execPath: overrides.execPath ?? process.execPath,
    cliPath: overrides.cliPath ?? CLI_ENTRY_PATH,
    platform: overrides.platform ?? process.platform
  };
  const parsed = parseArgs(argv);
  const handleUrl = parsed.flags.get("handle-url");
  if (handleUrl) {
    try {
      const parsedUrl = parseBridgeUrl(handleUrl);
      if (parsedUrl.kind === "connect") {
        const result = await runConnectCommand(connectDeps, parsedUrl);
        return result.exitCode;
      }
      const config2 = await deps.loadConfig();
      const serverUrl = parsedUrl.server ?? config2?.serverUrl;
      if (!serverUrl) {
        deps.stdout.error("Bridge is not paired yet. Pair before installing tools.");
        return 1;
      }
      kickOffInstallTools({
        serverUrl,
        protocol: parsedUrl.protocol,
        fetchImpl: deps.fetchImpl,
        onStatus: (status) => {
          if (status.status === "failed") {
            deps.stdout.error(status.error ?? "Tool install failed.");
          }
        }
      });
      deps.stdout.log(`Installing ${parsedUrl.protocol} tools from ${serverUrl}...`);
      return 0;
    } catch (error) {
      deps.stdout.error(error instanceof Error ? error.message : "Invalid bridge URL");
      return 1;
    }
  }
  if (!parsed.command) {
    deps.stdout.log(usage());
    return 1;
  }
  if (parsed.command === "connect") {
    const server = parsed.flags.get("server");
    const code = parsed.flags.get("code");
    if (!server) {
      deps.stdout.error("Missing required flag: --server");
      deps.stdout.log(usage());
      return 1;
    }
    const result = await runConnectCommand(connectDeps, { server, code });
    return result.exitCode;
  }
  if (parsed.command === "pair") {
    const result = await runPairCommand(parsed, deps);
    return result.exitCode;
  }
  if (parsed.command === "service") {
    if (!parsed.serviceAction) {
      deps.stdout.error("Missing service action.");
      deps.stdout.log(usage());
      return 1;
    }
    return runWindowsServiceCommand(parsed.serviceAction, {
      cliPath: CLI_ENTRY_PATH,
      log: (message) => deps.stdout.log(message),
      error: (message) => deps.stdout.error(message)
    });
  }
  if (parsed.command === "tools") {
    if (parsed.toolsAction !== "install") {
      deps.stdout.error("Missing tools action.");
      deps.stdout.log(usage());
      return 1;
    }
    const protocol = parsed.flags.get("protocol") ?? "all";
    if (protocol !== "adb" && protocol !== "hdc" && protocol !== "all") {
      deps.stdout.error("Protocol must be adb, hdc, or all.");
      return 1;
    }
    return runToolsInstallCliCommand(deps, {
      server: parsed.flags.get("server"),
      protocol,
      force: parsed.flags.get("force") === "true"
    });
  }
  const config = await deps.loadConfig();
  if (parsed.command === "start") {
    if (!config) {
      return runStandbyStartCommand(deps);
    }
    const result = await runStartCommand(deps, config);
    return result.exitCode;
  }
  if (!config) {
    if (parsed.command === "status") {
      return runStatusCommand(deps, null);
    }
    deps.stdout.error("Bridge is not paired yet. Run: wiseeff-bridge pair --server <url> --code <6-digit-code>");
    return 1;
  }
  return runStatusCommand(deps, config);
}
function resolveCliEntryPath(filePath) {
  try {
    return realpathSync(filePath);
  } catch {
    return path6.resolve(filePath);
  }
}
function isCliEntryPoint(argv = process.argv) {
  const entryPath = argv[1];
  if (!entryPath) {
    return false;
  }
  return resolveCliEntryPath(fileURLToPath(import.meta.url)) === resolveCliEntryPath(entryPath);
}
if (isCliEntryPoint()) {
  const exitCode = await runCli();
  process.exit(exitCode);
}
export {
  isCliEntryPoint,
  parseArgs,
  resolveCliEntryPath,
  runCli,
  runStartCommand
};
