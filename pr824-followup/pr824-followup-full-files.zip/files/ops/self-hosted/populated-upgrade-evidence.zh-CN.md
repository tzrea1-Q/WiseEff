# 存量升级候选证据

> English: [English](populated-upgrade-evidence.md)

## PR #824 复核续工，2026-09-07

代码 `11d8147a5accf08867bfaf792346af0d555b1d05`，tree
`570163372b9b8e1cdae5a6880262d66ae0fde408`，父报告 `7fabeb8c4`。
worker 准入后初始化失败会关闭连接池并返回固定脱敏错误；清理失败不泄漏诊断。
原登录／runtime-pin 拒绝处于该处理器之外，保持原样。

修复前两个生命周期反例失败，观察到私有诊断逸出。最终 focused 命令为
`./node_modules/.bin/vitest run --config vitest.runtime-bootstrap.config.ts
server/modules/logs/workerRunnerBootstrap.test.ts server/modules/logs/workerRunner.test.ts`：
退出 0，2 文件，15 收集／通过，0 失败／跳过／过滤。这是生命周期单测，
不是实际进程合法启动验收。`npm run build` 在相同生产代码上通过（早于最后
仅测试断言的追加），保留 chunk/externalization 警告。文档治理通过；
本分片未运行 schema 文档数据库验证、新全量 scripts/server/contract/boundary/
browser/capacity/PG。独立 Standards 与 Spec 仅本生命周期分片 PASS，
不构成整 PR 或 M2 审查通过。

Hosted `34067803219` 的 head 为 `7fabeb8c4`，实际 checkout 是
`51ec49131ea542d499607021c20012ad1b39266c`（base `cda6737a8` 的 merge-ref）。
scripts 114 文件，1467 收集：1427 通过、1 失败、39 跳过。唯一失败为
`scripts/run-restore-drill.test.ts` 的 S11-RP 生产 token 禁令命中
`ops/self-hosted/storage/controlledRecovery.docker.ts` 内 `pg_restore`，
不是历史 source-lock 超时。本机同 selector：base 1 通过／12 过滤，
candidate 1 失败／12 过滤；均 Node 22.22.3/npm 10.9.8/Vitest 4.1.5，
Hosted Node 22.23.2。后续 boundary/bridge/backend/contract/log-eval 步骤跳过。
该历史 run 的 Acceptance quality/smoke job 成功，不证明生产 startup。

原 CI 日志 SHA256：`7e01dcbdd93b9cae2e21c559146b1f9b2bfcadfe36cbf6964d8f2021ff3fc115`。
候选 selector：`87ce9486226ae219a6dd23586c4c61c2c2b999a61f58c8a5c707ef60f521acd2`。
base selector：`698920a886a67deab69d33617d3e22cc12d81425ce81e8582143eea757e68143`。
原日志私有保留；校验和不等于已提供公开附件。

A/B/C 均未完成：未通过放宽扫描修 CI；未接通真实根 startup adapter／合法
进程验收；未完成 controller 升级。runtime 只读能力及恢复执行归属需要明确
合同决定。当前状态／P12/P13／报告 producer 仍是内部实现缺口，不归因于
生产未授权。本轮无新 Docker/PG、真实备份、企业网络、生产执行或批准。

## 续工检查点，2026-09-07

代码 `df644163e28d0aaa11733b9b08f398ac7d2429e4`，tree
`4690333c6d62a9c613b344d9616c473c92bcc0e9`；后续报告提交仅改变既有六个
双语计划／操作／证据文件。重新 fetch 的 origin/main 仍为
`cda6737a8f177a8bbd2f3bc7d195f8e3037bfa74`。源部署保持
`82344044b436a8dafecefbb85dfd724cecb05e3f`，历史 image ID 见下文，
不替换成本地重建镜像。本检查点没有候选 PR、Hosted checkout/job、merge-ref、
merge SHA 或生产操作。M1 因记录中的全量 scripts 失败仍为 Scratch；M2 未完成。
组件成功不等于完整升级或批准。

报告 `1190ba591` 后实现了：既有 journal 内目标级 Binding／管理持久 attempt、
真实宿主锁存活验证、fsync 未知及跨 run 准入拒绝、原应用已停止时的 handoff 观察、
完整旧 public 投影与不可变迁移清单、受控管理迁移／checkpoint、候选／run／plan
固定的 P4 receipt 及 resume／no-op 重验、物理结构／权限连续性，以及两个 bootstrap
profile 的 PG16／MinIO／AOF 独立包恢复。关键提交为 `b91c98a31`、`45e2d07cd`、
`bbefbfc25`、`0a88f831b`、`273e0b26e`、`4f3f1485c`、`aa47072bc`、`a77e0ea6a`。

| 实际执行（UTC+8） | 结果与边界 |
| --- | --- |
| `df644163e`，00:28:33，真实 PG16 Alpine 组件终端入口 | 9 文件，92 收集／通过，0 失败／跳过，71.88s，exit 0；旧 schema、canonical Binding 组件、P4、Archive 和结构测试 |
| `df644163e`，00:28:29，runtime bootstrap 配置 | 10 文件，96 收集／通过，0 失败／跳过，9.57s，exit 0；含新建自有网络／卷上的 7 个真实受限登录／checkpoint 用例 |
| `df644163e`，build | exit 0，保留 externalization／chunk 警告 |
| `df644163e`，最终 CLI／gate／Compose | 63 收集／通过，0 失败／跳过，exit 0；含真实旧七行 gate 与新 CLI，不能当作完整旧 controller 成功 |
| `df644163e`，boundary／contract／selfhost／docs | 均 exit 0；boundary 3509 全部匹配，0 unallowlisted／stale／growth／mismatch；docs 使用显式自有 PG receipt |
| `0a88f831b` 加 source-test WIP，00:03:00，受控恢复 | 3 文件，42 收集／通过，0 失败／跳过，217.28s，exit 0；两个 bootstrap 身份、原 MinIO 版本、AOF、独立包恢复；恢复代码 blob 到最终候选未变 |
| `273e0b26e` 加父集成 WIP，00:21:57，管理／controller journal | 4 文件，67 收集／通过，0 失败／跳过，2.75s，exit 0；后提交为 `4f3f1485c`，不重新标为该 SHA 执行 |
| `aa47072bc`，00:23:32，系统授权扩展前的 PG16 矩阵 | 9 文件，89 收集／通过，0 失败／跳过，68.13s，exit 0 |
| `aa47072bc` 加三项权限反例，00:25:48 | 3 失败、20 selector 过滤，exit 1：parameter SET、builtin EXECUTE、特权设置未改变 receipt |
| 同工作修改修复后，00:26:11，后提交为 `a77e0ea6a` | 23 收集／通过，0 失败／跳过，1.04s，exit 0；真实 PostgreSQL，未改阈值 |
| `27946d016` 加父 P4 WIP，00:20:06 | 1 失败、6 selector 过滤，exit 1：失效 P4 仍允许 resume |
| 同 P4 测试，暂不应用输入克隆修复，00:21 | 1 失败、6 selector 过滤，exit 1：await 后调用方修改影响 P4 |
| 同工作修改修复后，00:21 | 7 收集／通过，0 失败／跳过，exit 0；真实 S7／checkpoint／Archive 调度，receipt port 明确为合成组件端口，不是报告 |
| `f5797479b` 加修正的 controller 反例，00:09:01 | 原代码 2 失败、15 selector 过滤；修复后 49 收集／通过，0 失败／跳过，2.64s；真实 journal／宿主锁，owner spy 只检查禁调 |

失败保留：第一次恢复命令误选不存在的路径，收集 0 个用例（passWithNoTests 导致
exit 0），不记通过；改为实际 storage 路径后得到 42 项结果。新 controller 测试
曾错误地给非 Binding harness 请求 Binding scope，setup 失败；修正后才真实复现
replay 准入问题。第一批结构测试 67 通过／2 失败，分别为 typed reason 接线不一致、
controller 提前拒绝使旧的晚拒绝断言失效；下一批 PG16 为 88 通过／1 失败，原因是
克隆缺省 Archive key 抢先抛错，掩盖要求的 typed 准入拒绝。`aa47072bc` 修复顺序，
未放宽断言。Typecheck 也发现管理 journal 两处 union spread 错误，已在最终 build
之前修复。

9 月 6 日直接将 pgvector-only fixture 指向 Alpine 曾产生 7 个文件 setup 失败、
7 个纯测试通过和 60 跳过，不是迁移失败或通过；随后增加独立自有 Alpine fixture，
未放宽 Catalog lane。更早仅留工具会话输出的锁 Red/Green、部分迁移、源投影和
恢复演进执行仍保留各自身份；缺失原始日志不重建成伪造 raw log。

最终矩阵采用已独立核验 daemon 的 Docker Desktop、新建自有数据库／角色／卷／
网络，PG16 `linux/arm64` image ID 为
`sha256:16bc17c64a573ef34162af9298258d1aec548232985b33ed7b1eac33ba35c229`。
工具为 Node 22.22.3、npm 10.9.8、Vitest 4.1.5、TypeScript 5.9.3。核对旧 schema
完整 126 个迁移文件及 0129–0139 的 11 个追加文件 checksum；0140 未进入候选。
source／bundle／mapping／receipt pins 来自组件 fixture，不是生产或 runtime／
public 报告 pin。临时资源按所有权核验后清理；公开包日志脱敏路径、凭据和宿主身份，
附文件校验和。

独立增量审查关闭了 search_path／源 schema、跨 run 准入、可变 P4 输入及系统权限
连续性问题。这些是有界标准／规范／安全审查，不是整体 seal。P4 结构连续性不替代
Release Verification；持续停写仍须由根流程真实 boundary 提供，不能传 boolean。

剩余内部工作仍由父负责：完整终端交接与 P2/P3 组合、未知结果显式 reconcile、
全部消费方转换／oracle、P12/P13 和新完整报告链、真实 API／worker pool 启动、
浏览器／业务／增长验收。未跑 M2 完整 scripts／server／UI 或 Hosted。#815 仍无
权威统计或分阶段 unavailable 的已接受契约；单独备份的 0140 提案新增两项治理
EXECUTE 能力，未批准、未集成。授权真实备份及企业 CA／网络证据均缺失。
生产维护条件未就绪，不交付生产升级命令。

## M1 续工记录，2026-09-06

开发 base 仍为 `67d4a77325b6009b77c2373bd788298a6d022bcf`。
M1 实现 `9453cf442b40fe1e90dc4ffb948e7b31898568eb` 删除两个无用旧 import
以及只求值、未调用 verifier 的表达式。verification 模块没有必需初始化副作用；
另一个无用 import 已被实际 CLI transform 擦除。两个旧模块仍留给实际调用方。
仅删除四个已退休 S12-OPS allowance；历史3519项 fixture、trusted base、
23对 relocation 均未改变，重新引入任一删除项都有永久拒绝反例。

`ffc2404986918466c672450d9628834bdf899b18`，tree
`e62f9239f4d1c207d2269951417915d87afce9fb`，补齐 relocation 回归的四项
精确删除断言。独立完整 M1 Standards／Spec 在 `9453cf442` 通过，后续断言
差异也经独立复核通过。范围仅保护性拦截，不是支持 populated 升级。
本记录时尚未创建 PR、未执行 Hosted。

| 实际执行 | 结果 |
| --- | --- |
| 继承 boundary Red | 1失败，23项被 selector 过滤 |
| 退休模块加载 Red | 1失败，0跳过 |
| `9453cf442` 完整 focused 集合 | 13文件，291通过，0失败／跳过，181.69秒 |
| `9453cf442` build | exit 0，保留原构建警告 |
| `9453cf442` boundary CLI | 3509匹配，未允许／陈旧／增长／metadata差异均0，23对relocation，exit 0 |
| `9453cf442` 全量 scripts | 104文件，1299通过、3失败、5跳过，exit 1，452.82秒 |
| `9453cf442` 加精确断言差异，有界 relocation/source-lock | 37通过，0失败／跳过，exit 0，69.40秒 |
| `ffc240498` contract／selfhost | 均 exit 0 |
| `ffc240498` 最终全量 scripts | 104文件，1301通过、1失败、5跳过，exit 1，356.29秒 |
| `67d4a7732` 后 `ffc240498`，同一source-lock命令串行对照 | 各4通过，0失败／跳过，44.76秒／59.27秒，未改timeout |

全量两项失败是旧3513／6数量断言，已按精确四项删除修复；另一项是 source-lock
在原60秒限制下超时。候选较 base 约4865次 Git 子进程仅增加15次，不能据此
把明显变慢归因于提交增长。该测试自身受源锁约束，本轮未改测试或 timeout。
有界复跑通过不覆盖全量失败；最终全量批次仍在同一source-lock用例超时。
M1因此仍为Scratch，不在必需命令失败时创建PR。再次全量执行前需单独处理
runner／源锁性能决策，不再计划同样的反复重跑。5项跳过不记通过。
下文原17项失败保留原执行：15项目标路由失败、两项超时，其中 setup 超时过滤了
后续用例。当前正确路由的批次是新证据，不能重新标注旧批次。

本轮专用 PG 为新建且核验归属的 Docker Desktop 集群，镜像
`pgvector/pgvector:pg16`，数据库 `wiseeff_lane_734`，随机私有凭据并固定实际
容器身份；未使用共享 Compose 应用数据库。旧 schema 回归另建独立
`postgres:16-alpine` 容器。未连接生产机。M1全文包现已发布到
[交付备份分支](https://github.com/tzrea1-Q/WiseEff/blob/codex/populated-upgrade-delivery-20260906/m1-full-files.zip)，
含报告head `a9a8858ab713cfca5bc605d35e04fbfd602acaa6` 的全部33个修改文件、
diff、manifest和选定日志。上传后重新下载验证，SHA256为
`43d254419c11d1aa0cec79fadbd06ec4ac8cd549aaa4cbba53721515b78d010c`。
这是源码／证据备份，不是发布镜像或PR批准。

## M2 续工记录，2026-09-06

最终代码候选为 `21f5aa4a8bdbb7208504396bce62796cf55875da`，tree为
`abcaeb43726145608d0a80edd5b5cdc52724fbee`。后续报告提交只改六份既有双语
计划／手册／证据文件。当前集成base为 `cda6737a8f177a8bbd2f3bc7d195f8e3037bfa74`。
本检查点GitHub查询没有候选PR或分支Actions run；没有CI checkout、merge-ref
或merge SHA。M2全量scripts／server、API／浏览器及容量验收仍未运行。
M1全量scripts失败单独保留在上表。

父集成沿用相同开发base。下表保留实际执行时的代码身份；cherry-pick和后续报告提交
不会把旧执行重新标成集成head执行。

后续origin/main推进至`cda6737a8f177a8bbd2f3bc7d195f8e3037bfa74`，仅含纯文档
PR #823。父以`7218a43dcd5402d52b5e57166b746d0c6409642f`追加合并；原base与
先前测试身份不变。

| 精确代码／边界 | 实际结果 |
| --- | --- |
| `fa7ee0bc6c7e94e26c9d34663b1f4cc9e8c277d2`，build | exit 0，保留原externalization／chunk警告 |
| 同head，boundary CLI及原trusted base | exit 0，3509匹配；未允许／陈旧／增长／metadata差异均0 |
| `6b817a48e41a2ae14355575f7a832e840531a018`，S6收据消费端＋Archive | 父执行19:06:43，2文件12通过、0失败／跳过，2.93秒；含5项真实隔离PG用例 |
| `06ef19e2cab84cdfb375b00fe7fe28d286027db3`，handoff | 父执行19:07:42，4通过、0失败／跳过，30.99秒；此前3通过／1超时批次仍独立保留 |
| `1173071bd` 加NODE_ENV反例，修复前 | 1通过／1失败，私有API env将实际NODE_ENV覆盖为development |
| 同工作差异修复后，纳入`90f555b96` | 真实Compose config，2通过、0失败／跳过，不代表应用启动 |
| `90f555b96`，交接拒绝冲突运行模式 | 父执行19:13:02，4通过、0失败／跳过，37.62秒 |
| 未批准的独立runtime提案`cac99fba82ec4f6349afed4d27c7d642fd0064ff` | 技术评估8文件67通过、0失败／跳过，含11项真实PG；后续仅配置提交`56a838eaa`未重跑整批 |
| `cd2598d13`，恢复包v2＋真实三存储 | 2文件28通过、0失败／跳过，71.70秒；原MinIO版本、AOF、独立恢复进程、角色继承和三项恢复故障 |
| `7695ace6f`，管理CLI回归 | 14通过、0失败／跳过，749ms，含真实CLI输入拒绝 |
| `9ce8db341`，专属新PG上的实际管理CLI | exit 0；137项迁移、4张checkpoint表，production模式且无运行期秘密 |
| `7695ace6f` 加配置防护，提交`1fda481ea`前 | S6＋Archive 12通过、0失败／跳过；缺receipt的CLI在收集前exit 1 |
| `9ce8db341`，测试目标URI反例 | 2通过、0失败／跳过；query host／port／sslkey及hash在Docker调用前拒绝 |
| `9ce8db341`，boundary | exit 0，3509匹配，未允许／陈旧／增长／metadata差异均0 |
| `7218a43dc`，窄类型修复并接入最新main后的build | exit 0，保留原chunk／externalization警告；之前类型错误已解决 |
| `23e7540a7`，dump外权限恢复回归 | 2文件34通过、0失败／跳过，99.69秒；五项权限故障在自建fixture清理前验证源仍保留 |
| `b5c67723c`，数据库级设置恢复拒绝 | 2文件35通过、0失败／跳过，117.42秒；拒绝后新连接仍受原设置约束 |
| `42b906033` 加后提交为 `b5c67723c` 的runner修改 | 3文件25通过、0失败／跳过，828毫秒；CLI、receipt、migration和真实子进程终止，本批不使用Docker |
| `e73d48419` 加组件runner | 6文件42通过、4失败、0跳过，8.78秒；四项producer用例因真实受限源表权限失败 |
| `4c60f1bcc`，原build | exit 134，TypeScript的1 GiB heap耗尽 |
| 固定 `7218a43dc` 与 `42b906033` 加runner，串行冷 `tsc -b --force` | 同为1 GiB上限：base exit 0、候选exit 134；分别检查Node项目均exit 0，内存报告938938K／941585K |
| `ce9915f23`，分项目进程build | exit 0；保留原两个TypeScript项目和Vite、每进程原heap上限及已有Vite警告 |
| `17647b243`，真实组件终端入口 | 6文件48通过、0失败／跳过，8.99秒；源pool分离后的真实producer与受限导入 |
| `198054e1b`，加入未知源回滚 | 6文件49通过、0失败／跳过，8.70秒；注入响应丢失后销毁真实连接 |
| `1635060c3`，journal准入反例 | 49通过、1测试超时、0跳过；测试持有单槽pool连接又请求另一连接 |
| `21f5aa4a8`，journal准入使用独立受限登录会话 | 6文件50通过、0失败／跳过，8.53秒；缺journal、pending、unknown均在阶段动作前停止，未改timeout |
| `21f5aa4a8`，最终代码build | exit 0，保留既有Vite警告 |
| `21f5aa4a8`，最终CLI／门禁／Compose集 | 6文件63通过、0失败／跳过，3.05秒；包含真实旧gate／新CLI子进程 |
| `21f5aa4a8`，boundary／contract／selfhost | 均exit 0；3509匹配，unallowlisted／stale／growth／mismatch均为0 |

组件runner前三次因Docker Desktop未发布internal network端口而在收集前失败，
保留为失败。现使用独立owned bridge、仅发布loopback并禁用IP masquerading。
其中只运行PostgreSQL，不证明应用外联隔离。未知suite（包括继承的对象属性名）
在Docker调用前拒绝；执行有15分钟上限、TERM/KILL升级和8 MiB原始输出上限。
清理前核对精确资源归属。

独立审查发现数据库级设置不在dump或角色清单中。`42b906033`在导出前拒绝
这些设置和缺失统计字段，不RESET或猜测恢复方式。恢复仍限于声明的PostgreSQL 16、
bootstrap `postgres` 合成形态，不能冒充完整业务或生产`wiseeff`角色恢复。
另一次 `23e7540a7` 真实终端执行返回源已停止、AOF、仅消费包的恢复及清理证据，
同时明确 `fullBusinessVerification=false`、`releaseReady=false`。

`9ce8db341` 的Node typecheck发现管理parser返回的checkpoint模式类型被扩宽；
`842010159`补充明确窄类型。先前真实CLI保留实际执行SHA，不隐藏这项类型失败，
也不归给base。两次探索调用使用不存在的配置名／错误flag，均以usage／configuration
错误停止，没有收集测试或访问数据库。

S6测试使用真实旧schema，将共用Definition的两个项目转换为canonical Binding，
保留4个值ID／时间及独立显式tip，并通过现有领域reader读取revision历史。
加密源Archive保留JSON null与SQL null的区别；SQL-null项目值当前明确拒绝，
不猜值。这是管理收据消费端的canonical转换，已超出“旧表保留”。但其P0/P8收据
仍是合成管理fixture，不是完整producer或发布批准链。实际producer必须先固定P0源意图，
后生成P7 mapping／Archive随机ID，再绑定P8收据，不能反向补写P0。

后续producer已实现这段有界生成链：确定性的完整Binding意图、真实P7 head、
加密Definition证据、实际自动registration、v2收据生成，再同事务执行S6导入／checkpoint。
三个跨项目合成Binding共用两个Definition，保留六个值并独立断言tip／历史。
源读取使用独立受控管理连接及21张表的真实SHARE锁；canonical写入仍用受限
管理登录，冻结grants未变。这超出了保留public旧行，但早期P0/P7仍为夹具准备，
不是完整根入口或verifier报告链。其他消费方、SQL-null值转换、HTTP／浏览器及
运行身份下的完整业务仍未覆盖。

独立审查发现的阶段倒写及未知提交准入已在消费端修复。controller journal的
pending／unknown会拒绝普通execute，缺journal／boundary adapter在写前拒绝。
具体root adapter和显式reconciliation仍缺失。源回滚响应丢失时销毁连接，不再归还pool。
这些审查与反例不能证明一次P0–P16成功运行。

handoff使用真实PG／MinIO／Redis身份，执行现有controller的inspect、宿主锁、私有文件
descriptor和漂移拒绝；应用容器明确是身份测试桩。没有证明完整旧应用controller、
候选启动成功或停服后的分阶段resume。

运行身份提案位于[独立备份分支](https://github.com/tzrea1-Q/WiseEff/tree/codex/populated-upgrade-runtime-proposal)。
它没有向governance writer授予宽泛Catalog／audit SELECT，但两项新增writer EXECUTE
仍扩展0138冻结manifest，尚未批准。可执行集成候选中没有0140迁移。
真实生产启动callback仍缺当前目标runtime pin状态producer；普通业务角色覆盖、
隔离API／浏览器、容量仍未完成，开发责任保留在父任务。

### 重建的旧源镜像

父任务从干净旧源SHA `82344044b436a8dafecefbb85dfd724cecb05e3f`、tree
`6dd92c36c4eb41bcaaba5a7a756befb9239d9120` 使用其原Dockerfile和既有build-network
库完成TLS验证构建。实际本地Docker image ID为
`sha256:65b300d1a8b80c06b9f7b37ccc21e45973d875492f2ae60f0128937cc934dea1`，
平台`linux/arm64`。BuildKit image manifest为
`sha256:40ef0227106e6ad85e2c0d286bdeb4dddb472b6e3ff66c6e746a6dc28db93c9c`，
config digest为
`sha256:2a0d17d6a8c2c7815d1ffe35ff94a4be03fcb2d8e4432c7bd3774f2d9a0fa12b`。
lockfile SHA256为
`43adbfe23117426588694bbd209eb96997d3a73287da475a2a2d4dfab29050ea`。
构建exit 0；日志SHA256为
`220821b090936a637118d9dbddf576c774827d74157c77ec8f3870fda5eca25e`。
已保留本地重建镜像；它不是用户历史image ID、registry发布、最终候选镜像，
也不是企业网络／CA验证。

### 执行安全偏差

三次本地调用违反了显式隔离路由要求。两名子任务漏传专用URL而调用server globalSetup，
到达默认／共享开发数据库，在历史ledger缺失拒绝前执行了migration ledger bootstrap DDL；
对应目标的逐文件migration循环未执行。更早的template setup已返回，复用／新建效果
未完整观察，不能声称零写入。完整原始日志未保留，不编造checksum。另一次裸docs检查
查询默认数据库扩展能力，因vector不可用跳过schema生成；该调用未执行迁移。
未连接生产机。父已撤销子任务执行权限；后续DB／Docker／测试集中由父核验专属目标后执行。
未对未经核验的默认目标再次连接、修复或清理。这些偏差不是通过证据，保留在记录中。

M2根入口完整成功、完整业务恢复、真实备份副本、企业网络候选构建、Hosted checkout／jobs
以及生产操作均仍为**未运行／未完成**。以上组件结果不授权生产命令或维护窗口。

## 上轮身份与状态（历史）

采集日期2026-09-06，仅独立开发环境。源部署仍是 `82344044b436a8dafecefbb85dfd724cecb05e3f`；用户提供的历史镜像 ID 为 `sha256:be121540c40fbb35e774b48cefb29b7ddf27d1bb8aa0c050a17acca3b7dfbf6c`，不是 registry manifest，也不是本轮复核结果。最初开发 base 为 `1c9fa56e3eaca6e7984f35a097876772a6e4025d`；最终刷新 base 为 `67d4a77325b6009b77c2373bd788298a6d022bcf`，新增内容是纯文档 PR #822。

代码候选 `b2c150d18bb6d7a8d8d5b45bcbf9f683fdafecbf`，tree `b8eb49d3a074e00196fb89c30ba4d1cae3677b3c`，分支 `codex/populated-upgrade-candidate`。27个任务文件与保留的原 Scratch `d357a5e6538f4bac4d63ba782ce13f75fe1cf194` 逐字节一致。本报告属于后续文档提交，不重新标注旧执行。候选没有 CI checkout、merge-ref、最终merge SHA、正式 bundle/runtime pin、mapping/source冻结或获批真实目标。

| 交付状态 | 结论 |
| --- | --- |
| UPG-01缺上下文拒绝 | 已实现，真实CLI反例已验证 |
| 完整代码交付 | 未完成；仍有boundary回归和发布集成缺口 |
| 合成populated | 追加schema后旧Binding／revision行保留；尚未证明canonical业务转换 |
| 真实备份副本 | 未运行；未提供备份，接收adapter也未完成 |
| 实际恢复 | 已执行并验证合成三存储sentinel恢复；未证明完整业务／真实恢复 |
| Hosted／PR | 未运行／未创建；仍为Scratch |
| 申请生产维护窗口 | 不具备条件 |
| 生产执行／批准 | 未授权、未执行 |

## 反例与精确执行

初始base在真实隔离PostgreSQL上运行 `npm run parameter-definitions:check -- --catalog-only`，返回 typed `absent/missing`，exit 0。`8922b3884573bd5d7c3c3f2efce53f3f51d6b894` 同命令返回 exit 2、`PCAT-UPG-RELEASE-CONTEXT-UNAVAILABLE`；显式 `--verify --diagnostic --report-id missing` 仍允许诊断返回absence和exit 0。原版7行controller gate fixture与源Git字节一致，SHA256 `29c28f2b5951bf4650984ec1be07ac121b8bb61c07e29388f70b7848e8952232`。其子进程回归调用真实npm/CLI，仅Docker传输由adapter代替，不能称完整旧controller／Compose预演。新普通stack入口对canonical目标拒绝apply/no-op/resume/recover-candidate；生产固定入口交接尚缺。

工具：Node22.22.3、npm10.9.8、Vitest4.1.5、Docker29.5.3。原schema回归使用独立 `postgres:16-alpine`；verifier专属fixture为pgvector PostgreSQL16。迁移清单是126个源文件及0129–0139共11个候选后缀，核验完整filename/checksum。此结果不证明生产扩展／应用启动兼容。

| 代码SHA | 检查 | 精确结果 |
| --- | --- | --- |
| 8922b3884 | 11文件focused，真实Docker开关开启 | 266通过，0失败／跳过，exit 0 |
| 8922b3884 | 全量scripts | 103文件：99通过／4失败；1306测试：1251通过／17失败／38跳过；exit 1 |
| d357a5e65 | 恢复继承库存后的CLI及boundary | 42测试：41通过／1失败；exit 1；前一Scratch缩减库存导致恢复被拒绝 |
| 1c9fa56e3、d357a5e65分别运行 | 串行exactRelocation/source-lock，原timeout | 各37通过、0失败／跳过；exit 0；53.98s／60.40s |
| 上述两个SHA分别运行 | URL/container一致的单个真实零库存导入导出回滚selector | 各1通过、80因selector过滤；exit 0；未复跑其他失败场景 |
| b2c150d18 | 12文件focused，两个Docker开关，maxWorkers=1 | 收集290：289通过／1失败／0跳过；exit 1；83.94s |
| b2c150d18 | boundary CLI，trusted base 9b3ba7df7e21f5589684bc92c872da593ad4c246 | 3513项：3512匹配、1未允许／1陈旧，0增长／metadata差异；exit 1 |
| b2c150d18 | npm run build | exit 0；保留Node externalization／chunk警告 |
| d357a5e65 | contract:check、selfhost:check | 均通过 |
| 8922b3884 | 带专属PG的docs:check | governance及schema artifact通过 |
| 2e40a8b3d | report及role两个server integration文件 | 31通过、0失败／跳过；非全量server |

剩余boundary失败由本轮负责：保留的legacy verifier引用移动后不能绑定冻结occurrence。未修改断言、检查器上限或allowance ID来隐藏失败。原全量批次另有15个数据库／容器路由失败及两个超时，其中setup超时导致33项跳过。同环境有界对照支持路由／负载归因，但不能把原批次改成通过。全量frontend/server、浏览器业务验收、增长容量、完整consumer oracle、企业网络镜像构建和Hosted均未运行。

日志和全文件校验和在本地交付包的 `evidence/`、`manifest.json`。保留原执行SHA；合成凭据／开发机路径不构成生产证据。包内不含私有备份或原始业务值。

## 剩余工作与责任

[冻结relocation契约](../../docs/agents/catalog-boundary-relocation.md)明确禁止通过padding源文件保留身份，独立Standards已否决该路径。最小boundary决策是独立审查这一未变引用的精确映射（完整blob、字节位置、原始切片及反例），或按归属契约移除旧债务。现有23对授权不能批准本次新映射。

父实现者负责在不放宽冻结boundary的前提下修复occurrence回归。发布集成owner负责获批P12/P13归属、退休后完整复验、runtime/public门禁和固定身份交接。运行安全owner负责实际角色／pool迁移和业务验收；检查器不会切换凭据。恢复owner负责备份接收、同边界快照、目标绑定完整恢复。产品owner负责#815权威Policy引用或明确批准unavailable。构建操作员负责企业CA及真实受信镜像来源。数据owner负责真实备份授权。验收owner负责完整语义／浏览器／容量。生产批准另行处理。

独立Standards通过了有界代码审查并验证27个刷新blob；独立Spec仅接受有界helper，明确完整需求未满足。此前Docker环境可指向远端的P1已通过固定本地endpoint／daemon身份检查修复。不宣称整体seal、发布批准或OP-09关闭。参见[终端手册](populated-upgrade.zh-CN.md)，当前不提供生产升级命令。
