# Bootstrap authentication probe close evidence

Delivery: `3fa5db71efb8e4677503bd75e467c58cf547d4dc`, based directly on `4b346d6ef483d599a9449bddab44345dd11fce26`. Tree: `3ae061e170d2504d8873cff9da07db3bde537443`. Scratch: `[local-path]

Only the existing bootstrap fence source and integration test changed. Production now waits for its own native `pg.Client.end()` before `release(true)`, and always ends the pool. Authentication acceptance, guard predicates, permission scope, and unknown outcomes remain unchanged. The final test drains both inspection and delayed native close before restoring spies. Its fault-release deadline remains within the original test budget.

The delivery tree is byte-identical to independently reviewed `6630570e5799368cac5a97c26a5238224914d535`; `git diff --exit-code` returned 0. R provided Spec PASS and L provided Standards PASS for the production change and final cleanup increment. The separate diagnosis branch preserves all temporary selector and Red history; do not cherry-pick that diagnostic configuration history.

## Exact identities and observed results

- Original Hosted merge: `7affb0894c4d78446efbfaf534ff61561c44e0a4`, run `34192523701`. Forty collected, 39 passed, one failed. The independent child had already returned `not-applied`; the failing assertion was its parent's subsequent fresh-manager inspection returning `unknown`. `/tmp/pr824-ci-4b-owned.log`, SHA256 `c36cc577c9b303bde9645dcdaee1b5503de29dfef8f575d248d6f656cd5a063c`.
- The original-source local control and bounded observer each passed one selected test with 39 filtered. They did not reproduce the Hosted failure.
- Preliminary fixed-delay diagnostic `1781768807a1a542a1b51cb23075a3fbe9273a2c`: one failed, 39 filtered; preserved separately, not the final deferred mechanism proof. `/tmp/pr824-ack-reopen-17817-delayed-end-red.log`, SHA256 `8f7813c3a4794236e54709da05d34e449947b909adf9ca58adca864016693319`.
- Effective deferred Red `684708d9b6101806990ad2f0b910751bbff4348c`, tree `5865e8ed9b83cbd50b0d17a4bc3e275b7b4cb184`: one failed, 40 filtered; 3.29 seconds, exit 1, owned cleanup verified. The actual next SQL guard observed target authentication PID 107 still idle while its native end had not completed. After release, the server session list was empty; the result remained `unknown`. No query result was mocked. `/tmp/pr824-ack-reopen-68470-gated-red.log`, SHA256 `1c530dda3811f9e0bfbef73adb4710bd5a74e6e1a1b4bdb4b103ccf54002d837`.
- Historical first full Green `ef57b7dc5a067749d3d2efe29af823988a3eac72`: 41/41, 17.63 seconds, exit 0, cleanup verified. `/tmp/pr824-ack-reopen-ef57-full-green.log`, SHA256 `47de2431363344350595f74d8de38abd1d8e0dfce86685fb66d3f56fbc41d320`. This precedes the final test cleanup correction.
- Final delivery `3fa5db71efb8e4677503bd75e467c58cf547d4dc`: 41/41, zero failed/skipped/filtered, 17.65 seconds, exit 0. Both runner resource cleanup and overall cleanup were verified. Actual target probe PID 387 had an observed native end before the next guard; both guards saw zero sessions; the final session list was empty and inspection returned `not-applied`. `/tmp/pr824-bootstrap-probe-3fa5-final-green.log`, SHA256 `6e4fd6a31068c45f48222ebb97ae9477830edccae9bea5e487ba8af6bba1e704`.
- Final strict TypeScript check on the same tree passed before delivery sealing. `/tmp/pr824-ack-reopen-final-types.log` is empty, SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`. Earlier diagnostic type failures remain in their original logs.

Source blob: `281aa42b376a1d4a64543b3d3aa4166484b70f5b`. Test blob: `f3099e7d1d9a2d478b6ba03f452216c026a2127e`. Owned configuration blob: `a5b6b708885eb063e17ed17d3a2e9c3805062c3a`, unchanged from the base.

## Final actual command

Executed in the delivery Scratch; the original owned runner verified the actual local Docker daemon and its receipt before using PostgreSQL. No ambient database URL or custom final selector was used.

```sh
env -i HOME="$HOME" PATH="$PATH" node --import tsx --input-type=module -e 'import { createIsolatedUpgradeDocker } from "./scripts/isolated-upgrade-docker.ts"; import { runUpgradeComponentTests } from "./scripts/run-upgrade-component-tests.ts"; const docker = createIsolatedUpgradeDocker(); const result = await runUpgradeComponentTests(["--expected-daemon-id", docker.daemonId, "--suite", "bootstrap-credential-pg16"]); console.log(JSON.stringify(result)); process.exitCode = result.exitCode;' > /tmp/pr824-bootstrap-probe-3fa5-final-green.log 2>&1
```

These results establish the injected real PostgreSQL lifecycle mechanism and the final local component regression. They do not identify the original Hosted guard refusal, prove Hosted stability, or authorize production startup, retirement completion, or release. No full build was rerun by this subagent; the parent owns final integrated build and Hosted validation. The PG/Docker lane was returned after the process exited and owned cleanup was verified.
