PR #821 审查返修浏览器证据

代码候选：be610b7addcbe144fdfc0b07018d9be4e5db8f75
Tree：5aa6f82e18070378f786e83d28af482fb388ec01
本包包含实际隔离本地 API/PostgreSQL 浏览器产物，不代表生产或目标机证据。

catalog-specs/：21 个 Catalog 业务用例通过，另有 1 个单独标识的 runtime warmup，无跳过。三个实际 spec 路径、起止时间与退出码在 catalog-specs-meta.json；截图、操作/网络/审计附件及 Playwright 结果和报告保留在 artifacts/。

playwright-cli/：1440x900、768x1024、390x844 的实际 snapshot/screenshot，以及键盘、焦点、取消、输入保留、确认和滚动检查。summary.json 区分认证后零 console error 与先前未登录时的 401；也保留一次响应监听路径误写造成的超时。真实 POST 仅返回一次 201，后续只读 UI/网络核验确认仅一条草稿。该超时的辅助断言不计为通过。

这些结果不代表 Policy 计数、完整容量、Gate 0、Hosted 或合并获批。guest、真实 Agent、拦截 409、真实冲突和操作 parity 在主证据索引中分别标识。本包不含凭据、认证 storage state、生产数据或私有归属上下文。逐文件哈希见 MANIFEST.json。英文伴随文件：README-en.txt。
