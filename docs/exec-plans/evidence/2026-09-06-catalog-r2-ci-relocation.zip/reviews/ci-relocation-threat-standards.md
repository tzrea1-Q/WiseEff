# CI relocation — independent Standards R3 preflight

**PASS for the bounded authorization assessment and design constraints below.** This is not implementation approval by a reviewer, a completed executable threat matrix, a seal, merge approval or a passing CI result. Read-only checkout: `e2b305d026a0e90cbed32bb8e851de279aae09f1`.

## Current authority, distinguished from historical pending state

The parent reports that the user was explicitly told the sole CI failure was the 23 occurrence relocations and then instructed **“修复ci报错”**. On that stated conversation record, the bounded repair is authorized. No repository provision located in this review requires a second named external authority to approve this implementation after that user instruction. Do not repeat the earlier lack-of-instruction blocker as though authorization had not changed.

The actual mandatory gates remain:

- `docs/agents/agent-delivery-protocol.md:126`: “For R3, a Spec reviewer challenges the invariant before production implementation begins.” Standards alone does not fulfill that independent Spec challenge.
- Same document `:136`: each matrix row has its observation/evidence owner and “Executable cases begin red in Scratch”; `:140` requires both independent reviews against the same Scratch SHA before sealing.
- `docs/agents/catalog-launch-operating-rules.md:49`: “Lock occurrence counts, allow-lists, schema fingerprints, and lock files once at THREAT-READY” and treats a second patch of the invariant as a circuit breaker. Re-entering this threat/design review is appropriate; regenerating the old inventory is not.

The old `boundary-relocation-proposal.md` and exact packet's unapproved status document the earlier state and reviewer-proposed process, not an additional superior authority. Preserve those bytes/history. Add a separate, truthful authorization/scope record referencing the new user instruction; do not backdate or rewrite the old packet as already approved. This authorization does not cover Policy replacement, merge, production, OP-09, new debt or a general relocation mechanism.

## Exact object and minimum implementation boundary

The historical packet SHA-256 remains `ecde795be9211db187380c950d0d96ef3a4e060e8a4e4d0bbc9719f40b5bd4df`. Its destination file blob `1854772393388a8778b27594d2789b8635bfa3de` still matches current HEAD. The original fixture hash remains `fe3cd2abe9181517332612938f00082db864d66f6f9b284d5f43b3051b5fe951`; all 11 current shard blobs match be610. The source blob remains `dd0168f369b615f45eeb1e5539557fb63967e1dd`. Only the 23 previously verified slices are unchanged; the surrounding DTS fixture is a semantic UPDATE-versus-duplicate-INSERT repair, not a whole-file translation.

Freeze exact editable filenames before Scratch: existing checker and its test, dedicated `exactRelocations.ts` and test, one exact relocation fixture, and explicitly named bilingual plan/evidence documentation. Keep original fixture, all 11 shards, domain/product code and generic ancestry/anti-growth logic read-only. A new record should contain only the executable exact contract and provenance, with its **entire raw file hash** pinned in reviewed code; editable `approved: true` flags, environment variables, CLI switches or arbitrary paths cannot grant authority.

Run the ordinary full discovery and existing trusted-base/ancestor/anti-growth checks. Validate relocation against original inventory and current allowance membership, then bind only the exact listed discovered destinations back to their original identities. Preserve current-location evidence separately if needed. Never discard an unmatched discovery. Verify both full blobs, original raw slices, metadata, byte bounds, ID suffixes, fixture/shard anchors and all bijection invariants. Validate the actual working source that was scanned, not merely HEAD's blob while ignoring dirty source. Missing/unknown records, changed bytes, future source versions and unused/reused pairs must refuse activation or fail the checker; they must never produce a pass by omission.

## Required permanent adversarial observations

Parent owns executable rows; independent Spec challenges them before implementation, Standards reviews the finished same-SHA implementation.

| Row | Input / counterexample | Required result |
| --- | --- | --- |
| R1 | Exact 23 pairs with source/destination anchors and original allowances | Actual checker passes 3513 current debts; original fixture remains 3519; original six deletions stay deleted |
| R2 | Missing/malformed/unknown record, altered raw-record hash or purported approval flag | No automatic authorization; fail closed |
| R3 | Changed whole-file blob, dirty working source, slice, token/evidence/rule/family/reason/span/ID | Reject, even if count and normalized SQL text match |
| R4 | Duplicate/reused/omitted/unused pair; cross-file or swapped identical-SQL destinations | Reject; exactly one old identity per exact observed destination |
| R5 | Old allowance absent, shard/fixture altered, deleted debt reinstated, extra new occurrence | Existing ratchet still fails; no new debt or allowlist growth |
| R6 | Wrong/missing/unrelated trusted base, changed original blob, forged lineage | Existing ancestry/integrity checks remain mandatory and fail |
| R7 | Exact descendant and actual Hosted merge topology preserve approved file bytes | Same semantics; no requirement that current HEAD equal the historical evidence SHA |
| R8 | Shallow checkout lacks required trusted objects; later full history/future source edit | Preserve established missing-evidence refusal; no fabricated fallback; future blob edit fails |

Test through the actual checker as well as parser tests; include the existing failing inventory case and explicit trusted-base CLI. No timeout/limit increase, fuzzy matching, byte padding, count-only matching, global exemption, inventory refresh or credential-bearing evidence. Record Red/Green and final checkout separately. No implementation, test execution or external mutation occurred in this review.
