# Independent CI relocation scope and Hosted expectation audit

**Scope/filter audit: PASS. Exact `164b832f` Hosted readiness: HOLD pending the explicit pre-seal digest materialization.** This report is a read-only scope/evidence audit, not approval of the relocation implementation, its authorization, merge, full-program acceptance or production work.

Fixed comparison: `e2b305d026a0e90cbed32bb8e851de279aae09f1..164b832f543433564b3f5cd75d6b9445a7b9bb8d`. Destination tree: `7da2b2afecde0e0b9af6c28e5de366d4c16f2fb0`. GitHub status below was actually read on 2026-09-06 through `gh run view`, the direct job-log endpoint, the Git commit endpoint and PR metadata. No GitHub mutation or broad test run occurred. Only this ignored report was written.

## Exact change boundary

The comparison changes nine files: four documentation files and five checker/relocation files. It adds the two language versions of `docs/agents/catalog-boundary-relocation.md`, updates the two delivery plans, changes `scripts/check-parameter-catalog-boundaries.ts` and its test, and adds `scripts/fixtures/parameter-catalog-allowlist/property-key-cutover-relocation.json`, `scripts/parameter-catalog-allowlist/exactRelocation.ts` and its test. There are no runtime, browser, SQL fixture, workflow, dependency, migration, test-configuration or path-classifier changes.

The original `scripts/fixtures/parameter-catalog-allowlist/current-violations.json` is unchanged across c3d, e2b and 164: Git blob `3175e8aef4881e916b7828004bd029d5c7d7dd5c`, SHA-256 `fe3cd2abe9181517332612938f00082db864d66f6f9b284d5f43b3051b5fe951`. The new relocation record is separate from that immutable inventory.

All **11** existing allowance shards are byte-identical across those three commits:

| Shard under scripts/parameter-catalog-allowlist/shards | Unchanged Git blob |
| --- | --- |
| s12-agt.json | `c888a59d1c7cd7e44755b1291915c77fae698610` |
| s12-cgh.json | `074a3ba451ad469b5af9fef6ce585ccc5e16166e` |
| s12-dbg.json | `3611d1829e5108ff131b49137a20f60f99d31577` |
| s12-dts.json | `f6a93019c5931d2d6fcaf4febf35a001cc559c99` |
| s12-fil.json | `977a54c38b4b598a543895fe2fce1680a35a3cb8` |
| s12-knw.json | `3550e5a472d30687716c37e8a8eeb48ef904f454` |
| s12-log.json | `d2f243a18b8debbb55017858e6490680afb6866e` |
| s12-mod.json | `31b4c3ffbab1a0e095e9059cb0a13778a764243d` |
| s12-ops.json | `208ece8dabce639fee420d8f587eaf0d9dfa9e06` |
| s12-prj.json | `7c9382ebcbd443f726fb72a6ee6754bae7161fce` |
| s12-top.json | `63bb436cfd593b9235dc6f9d679c87d010445a4c` |

The SQL-bearing `server/modules/parameter-specs/propertyKeyCutover.integration.test.ts` stays at destination blob `1854772393388a8778b27594d2789b8635bfa3de`, SHA-256 `011a144061b8f78aef58349f4c7a8f01e4bdfb7ed96dae015578f79193369708`. This repair does not edit that fixture to move, normalize or remove violations.

Whole-directory tree identities also match at c3d/e2b/164:

| Directory | Identical tree |
| --- | --- |
| server | `330d484b0f842b882cf45dd24ba576eb8f5731bf` |
| src | `e5b46cd305780f7f62723548565f58e9ce0dc0b9` |
| e2e | `9adcb2b35f70c30333848a17c8bdbaa1b6f5d6a2` |
| packages | `67c376a0087d1e92eff662b4089e56c98e281d4e` |
| ops | `3665701cef3ddb0b423aff7c9b738aa771790854` |

`.github/workflows/ci.yml`, `scripts/ci-changed-paths.ts`, `scripts/check-acceptance-ci.ts`, package.json/package-lock.json, Vite, Playwright and server/scripts Vitest configurations were each independently checked as unchanged blobs. Workflow blob is `d9ad0e3a1278a302ead406da3acd131389492794`; classifier blob is `4e1c56c06743445bf4b198599570eeb3b8ecc885`.

## c3d evidence applicability

Existing real-PG/root-HTTP and browser/CLI execution evidence remains bound to **`c3d592011d05109adb64bd295159e33ade9fd604`**, tree `8dc261d28748d86ead510f8c34c76da0d9d638e9`: 255 relevant tests, 21 Catalog business browser cases plus one warmup, and the separately recorded three CLI viewports. The unchanged runtime/test/dependency/config blobs establish applicability to those unchanged behaviors; they do **not** constitute reruns at e2b or 164, and do not validate the new relocation parser.

No new full frontend/server/test:all, capacity or Gate 0 result is inferred. Prior be610 results and blockers retain their original execution identity. A later seal digest, documentation commit, PR push or generated merge-ref must record its actual SHA and the scope of any reused evidence explicitly.

## Path classification and Hosted gates

The unchanged workflow detects a PR's **full** `BASE_SHA...github.sha` diff (`ci.yml:70–85`), not only the last commit. The unchanged classifier treats otherwise-unclassified non-documentation `scripts/` paths conservatively as product changes. A read-only execution of that classifier (`node --import tsx scripts/ci-changed-paths.ts --stdin --json`; no `--github-output`) produced:

- This exact nine-path repair: `docsOnly=false`, `ui=false`, `product=true`, `workflow=false`, `runL1=true`, `runQuality=true`, `runSmoke=true`.
- Local full PR comparison from main `27bc39d53235879afb579a86f6ee777a462e4204` to 164 (94 paths): `docsOnly=false`, `ui=true`, `product=true`, `workflow=false`, all three run flags true.

Thus the scripts-focused repair does not suppress required L1, quality or smoke work. The future actual merge-ref must still be checked when Hosted creates it; this local classification is a prediction of unchanged rules, not proof of a future job execution.

`Build and test` is gated only by `run_l1 == 'true'` and has a 20-minute job budget with a pgvector PostgreSQL 16 service. After setup/metadata/toolchain, the ordinary sequential steps are:

1. `npm run build` — **before** Script tests, not newly enabled after them.
2. `npm run docs:check`, `npm run ui:check`, `npm run lint`, `npm test` and pgvector-extension verification.
3. `npm run test:scripts`.
4. Fetch and verify the exact trusted base, then the dedicated Catalog boundary CLI.
5. `npm run bridge:test`.
6. `npm run test:server` (full backend command).
7. `npm run contract:check`.
8. `npm run logs:eval`.

Steps 4–8 have no path-level skip conditions, but ordinary failure propagation means a failed earlier step prevents their execution. Restoring Script tests only allows the next boundary step to start; it does not prove that boundary, backend or contract passed. The only advisory continue-on-error step in this sequence is the earlier DTS seed compile.

**Hosted's actual boundary parameter is the original fixture base**, not the local accepted implementation base. At `ci.yml:212–219` it is:

```sh
PARAMETER_CATALOG_TRUSTED_BASE_SHA=9b3ba7df7e21f5589684bc92c872da593ad4c246
git fetch --no-tags origin "${PARAMETER_CATALOG_TRUSTED_BASE_SHA}"
test "$(git rev-parse --verify "${PARAMETER_CATALOG_TRUSTED_BASE_SHA}^{commit}")" = "${PARAMETER_CATALOG_TRUSTED_BASE_SHA}"
npm run parameter-catalog-boundaries:check -- --trusted-base-sha "${PARAMETER_CATALOG_TRUSTED_BASE_SHA}"
```

Local approved-baseline validation uses `35cbfb18e0504d6ccf16d2fc18c72a0d2da80391`; the original fixture retains 9b3. Neither parameter nor existing fixture-integrity, ancestry or allowance-growth checks is removed by this delta. Any final candidate must be checked against the workflow's actual 9b3 invocation as well as its required local baseline; do not report a local 35 run as the Hosted 9b3 command.

Quality and smoke remain enabled. Broad local non-HDC Gate 0 is separately controlled by `run_l2`: on PRs, the workflow forces it false unless the PR carries `full-acceptance`. The actually read PR metadata has no labels. Target-synthetic runs require explicit workflow_dispatch and a target mode; they are not enabled by this repair. No label, manual dispatch or target action was performed here. Therefore this normal PR run is not expected to supply broad Gate 0, even if all its scheduled jobs turn green. Merge bar rejects failure/cancellation and requires Detect success; its green result must not be expanded into acceptance of intentionally skipped gates.

## Current pre-seal hold

At the **fixed 164 commit**, `scripts/parameter-catalog-allowlist/exactRelocation.ts:14` still sets `reviewedRecordSha256` to `pending-independent-preseal-review`. The real-file path compares a 64-character SHA-256 digest with that literal before applying any relocation, so this candidate intentionally cannot pass the real record-integrity check. Synthetic fixtures that bypass this path do not resolve that hold.

This is an explicit outstanding pre-seal step, not a request to weaken the guard. After the required independent review, the coordinator must materialize only the reviewed record's exact digest under the existing authorization, record the resulting new commit/tree, and perform the appropriate exact-candidate checks. Do not call 164 sealed or Hosted-ready, or carry any earlier result across the changed digest as if it had executed on that new SHA. This audit does not itself grant that approval or modify the digest.

## Actual latest inspected Hosted run

[Run 34011746179](https://github.com/tzrea1-Q/WiseEff/actions/runs/34011746179) is **completed/failure**, PR event, recorded head **e2b305d026a0e90cbed32bb8e851de279aae09f1**. It is not an execution of 164. PR #821 was actually read as open Draft, head e2b, base main 27bc, no labels.

The actual build job log and independent Git commit response identify checkout `refs/remotes/pull/821/merge` → **`d0adfb52afa2751740873daa1c4b35ff78f751c9`**, tree **`debce1e9fc5866aa00f9040d3a7f8d5a54857781`**, parents main 27bc and PR head e2b. Build-and-test job `101428743708` ran 2026-09-06T04:32:55Z–04:42:02Z. The direct log response was 786794 bytes, SHA-256 `794bc85b5e1f87c7fe757d3f93a8ee980b2bb5bead82de3a7860a54b7135e0b5`.

The sole failed script test remains “locks the post-refresh owner-path inventory against the reviewed S0-ID trusted base”: **93 script files, 92 passed / 1 failed; 1213 tests, 1191 passed / 1 failed / 21 skipped**. Frontend passed 438 files / 3374 tests. Job metadata marks the dedicated boundary CLI, Device bridge, Backend, Contract and Log analysis eval **skipped**. Build, docs, UI and lint succeeded earlier. Detect, Acceptance quality and Acceptance smoke succeeded; local non-HDC and target-synthetic were skipped. Merge bar `101429857823` failed.

That failure is retained as actual predecessor evidence. It establishes neither success nor failure of the new 164 relocation implementation. Future Hosted results must be recorded from their own head, actual merge checkout, job steps and conclusions. This scope audit performed no production operation, OP-09, target drill, cleanup, GitHub write or broad validation run.
