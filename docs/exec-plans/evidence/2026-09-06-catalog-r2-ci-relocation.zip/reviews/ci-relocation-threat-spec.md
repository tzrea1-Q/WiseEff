# CI relocation — independent Spec preflight

**PASS for bounded threat readiness; not implementation acceptance or a passed gate.** Review baseline: `e2b305d026a0e90cbed32bb8e851de279aae09f1`. Sources: the parent's supplied latest user instruction to fix CI, `boundary-relocation-exact-proposal.json`, `boundary-relocation-proposal.md`, current checker/inventory test and repository delivery/launch rules. No Standards report was read. No tracked file, test, environment or GitHub state was changed.

## Authority

The latest user request, as supplied in this task, explicitly asks to fix CI after the exact 23-pair blocker was explained. It authorizes implementing this particular repair. The proposal's historical `unapproved` fields record an earlier state; they are not a current prohibition and must not be silently rewritten as historical approval. Record the subsequent user authorization separately, with the exact approved object and review evidence.

The repository requires inventories to lock once (`docs/agents/catalog-launch-operating-rules.md:49`; `agent-delivery-protocol.md:242`). This repair must preserve that inventory and allowance contract, rather than regenerate either. The provenance/release-gate seam merits R3 treatment: threat cases before implementation and independent Standards/Spec before sealing (`agent-delivery-protocol.md:37,49–53`). I found no additional named external approver required before this narrowly authorized local implementation. User authorization does not supply final independent review, merge approval, or production authorization. Any broader mapping/debt change falls outside it.

## Independently verified approval object

- Exactly one path: `server/modules/parameter-specs/propertyKeyCutover.integration.test.ts`.
- Old blob `dd0168f369b615f45eeb1e5539557fb63967e1dd`, SHA-256 `7ec2aef0577d686d77ba10109db7b3285ae67a29791b07353a8b0990ab1c5d41`; new blob `1854772393388a8778b27594d2789b8635bfa3de`, SHA-256 `011a144061b8f78aef58349f4c7a8f01e4bdfb7ed96dae015578f79193369708`. The old blob matches fixture base, accepted 35cb and main 27bc; the new blob matches current e2b305.
- Fixture SHA-256 remains `fe3cd2abe9181517332612938f00082db864d66f6f9b284d5f43b3051b5fe951`, 3519 records. Current allowances remain 3513, with exactly six original records absent. Owning-shard and checker hashes match the proposal.
- All 23 old/new IDs are unique. I compared every exact UTF-8 slice, range, family/rule/file/token/evidence and current old allowance, and independently recomputed all 46 occurrence suffixes. Each slice is identical, with +216 bytes; no algorithm may infer future mappings from that delta. The pair sets exactly cover the historical report's 23 stale/23 new entries. This last comparison is to the preserved report, not a fresh scanner execution.
- Verified fixture-base `9b3ba7…` → accepted boundary base `35cbfb…` → e2b305 ancestry. The CLI trusted base remains full `35cbfb18e0504d6ccf16d2fc18c72a0d2da80391`; the fixture's original trusted SHA also stays unchanged.

## Permanent acceptance/threat matrix

| Case / counterexample | Required observation |
| --- | --- |
| Exact authorized record, current destination blob, original fixture/shards | Actual checker and unchanged inventory test pass: 3513 matches, zero stale/new/metadata mismatch/growth; fixture remains 3519. |
| Record absent, unauthorized, unknown, malformed or integrity anchor altered | No relocation authority; reject/fail closed. A JSON `approved: true` or caller-supplied digest cannot authorize itself. |
| Old/new whole blob, byte start/end, slice, ID, family/rule/path/token/evidence/reason changed | Reject even if normalized SQL or the overall count matches. Validate all pairs before applying any. |
| Duplicate old ID, duplicate destination, reused mapping, omitted pair, unused extra pair, cross-file pair | Reject; one-to-one and exact-set completeness are mandatory. |
| Two repeated SQL occurrences swapped despite equal text | Reject exact occurrence identities/positions; no fuzzy search or first match. |
| Missing old immutable record/current allowance, changed allowance metadata, reinstated removed debt | Reject; preserve all six deletions and existing shard bytes. Mapping is not a new allowance or permission to restore debt. |
| Added violation outside mapped slices, new file, future edit anywhere in the bound destination file | Normal checker still detects new debt; future whole-file hash invalidates this record. |
| Wrong/missing trusted ancestor, shallow checkout lacking proof | Fail closed or fetch required ancestry through the established mechanism; never substitute HEAD as trusted base. |
| Direct checkout, actual Hosted merge topology, later full history | Same exact source/blob identities and intact normal comparison; capture real checkout SHA and job contents. A locally simulated merge is not Hosted evidence. |

Freeze the exact parser/validator, record, integrity anchor, existing-checker integration, new adversarial-test paths and bilingual documentation ownership before writing. Add tests without changing the existing expected counts or skip conditions. Final independent review must verify the fixed bytes and all negative cases; an initially green count alone is insufficient. This preflight does not clear unrelated Policy, capacity, Gate 0, merge or OP-09 boundaries.
