# Independent Spec pre-seal review

**PASS for the bounded pre-seal implementation; no findings.**

Base `e2b305d026a0e90cbed32bb8e851de279aae09f1`; reviewed head `164b832f543433564b3f5cd75d6b9445a7b9bb8d`. I reviewed the exact nine-file diff independently of Standards, without implementing these files. No tracked/GitHub/environment changes were made.

Independent SHA-256 of the committed 45,788-byte record:

`fe2a8aa3e97193c98aafdfd06572335419e2e53854e80b33e172afa0e741e074`

All 23 complete old/new records and slice hashes exactly match the independently checked preflight proposal. Old/new blobs remain `dd0168f369b615f45eeb1e5539557fb63967e1dd` / `1854772393388a8778b27594d2789b8635bfa3de`. Original fixture and all shards are byte-identical to this review base; 3519 fixture / 3513 allowances / six deletions remain intact.

## Contract and assertions

- `exactRelocation.ts:39–73` validates the entire record before aliasing: strict schema/count, whole-file hashes, complete original/discovered records, existing allowance metadata, uniqueness, exact positions and identical raw slices. The +216 condition restricts an already enumerated pair; it does not discover mappings. JSON cannot self-authorize.
- `exactRelocation.test.ts` directly asserts altered identity/rule/token/evidence/reason/path/ranges/digests, omitted/duplicate/reused pairs, duplicate/missing discovery, missing original/allowance, already-bound source, wrong fixture base and outside-slice source edits are rejected. The repeated-SQL swap case first establishes an actual duplicate slice, then asserts rejection.
- Unmapped debt stays unallowlisted; every one of the six removed occurrences remains unallowlisted. Filesystem cases cover missing, changed and partial records. Existing checker tests retain fixture-integrity, missing/non-ancestor trusted base, allowance-growth and Hosted-fetch assertions. Real shallow/Hosted execution remains an evidence requirement, not proof supplied by a text assertion.
- `check-parameter-catalog-boundaries.ts:339–343` applies aliases only after existing integrity/ancestry/growth checks and retains normal comparison for all other discoveries. Reports expose observed locations separately. The original inventory test only gains three uniqueness/count assertions; no existing expected count, scanner rule, allowance or skip is weakened.

I ran `npm run test:scripts -- scripts/parameter-catalog-allowlist/exactRelocation.test.ts` on the clean fixed head: **1 file, 33 passed, exit 0, 13.90s**. HEAD and tracked status remained unchanged afterward.

## Remaining gate

`pending-independent-preseal-review` intentionally rejects the real checker. This PASS permits the agreed single anchor materialization after both independent reviews agree, using the digest above; it does not certify that resulting delta automatically. Review that exact delta, then run the unchanged inventory/full scripts, trusted-base-35cb checker, documentation checks and actual Hosted checkout. Missing/bad-record regressions must still pass after anchoring. No CI-green, seal, merge, program-closure or production claim is made here.
