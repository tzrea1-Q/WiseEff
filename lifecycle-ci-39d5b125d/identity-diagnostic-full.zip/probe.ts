import assert from "node:assert/strict";
import path from "node:path";
import { pathToFileURL } from "node:url";
import { performance } from "node:perf_hooks";
const root=process.argv[2];
const load=(p:string)=>import(pathToFileURL(path.join(root,p)).href);
const {withTempDatabase}=await load("server/testing/tempDatabase.ts");
const {seedCoreGraph}=await load("server/testing/fixtures.ts");
const {resolveDtsNodeCompatible}=await load("server/modules/parameter-kernel/sensitiveNode.ts");
const start=performance.now();let prepared=0,seeded=0,resolved=0;
await withTempDatabase({prefix:"identitytiming"},async({db}:any)=>{
  prepared=performance.now();
  await seedCoreGraph(db,{organization:{id:"identity-org-a"},projects:[{id:"identity-project-a"}]});
  await seedCoreGraph(db,{organization:{id:"identity-org-b"},projects:[{id:"identity-project-b"}]});
  await db.query(`insert into project_parameter_files(id,organization_id,project_id,file_name,format) values
    ('file-a','identity-org-a','identity-project-a','identity.dts','dts'),('file-b','identity-org-b','identity-project-b','identity.dts','dts')`);
  await db.query(`insert into project_parameter_file_versions(id,file_id,version_number,storage_key,checksum,size_bytes,parsed_index,origin) values
    ('locked','file-a',1,'fixture/locked','locked',1,'{}','upload'),('current','file-a',2,'fixture/current','current',1,'{}','upload'),('foreign','file-b',1,'fixture/foreign','foreign',1,'{}','upload')`);
  await db.query("update project_parameter_files set current_version_id='current' where id='file-a'");
  await db.query(`insert into dts_nodes(id,file_version_id,name,node_path,compatible) values
    ('n1','locked','fixture-node','soc/power','vendor,locked-oracle'),('n2','current','fixture-node','soc/power','vendor,current-must-not-win'),('n3','foreign','fixture-node','/soc/power','vendor,foreign-must-not-win')`);
  seeded=performance.now();
  const value=await resolveDtsNodeCompatible(db,{organizationId:"identity-org-a",projectId:"identity-project-a",sourceFileName:"identity.dts",sourceFileVersionId:"locked",sourcePath:{kind:"node-locator",value:"soc/power"}});
  resolved=performance.now();assert.equal(value,"vendor,locked-oracle");
});
const ended=performance.now();
console.log(JSON.stringify({phase:"independent-first-case-timing-probe",notPartOfSelectorCount:true,databaseAndMigrationsMs:prepared-start,seedMs:seeded-prepared,resolverMs:resolved-seeded,cleanupMs:ended-resolved,totalMs:ended-start}));
