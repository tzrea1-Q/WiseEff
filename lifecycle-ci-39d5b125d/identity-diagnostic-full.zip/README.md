# Bounded CI diagnostic (not a product change)

Chinese: [Chinese](README.zh-CN.md)

The selector runs used the retained `runner.selector.ts`. The later `runner.ts`
adds the independent timing probe and the missing-receipt routing reproduction.
All five invocations owned distinct PostgreSQL clusters, roles, volumes and
networks. Every invocation verified cleanup. Nothing contacted production.

Execution candidate: `2ce71d683f1cd3e51b657f45aafaabc34d3dd5f2`, tree
`3dee59f518a8ce6f2a7894138f4b867a7c7a6244`. Base:
`cda6737a8f177a8bbd2f3bc7d195f8e3037bfa74`, tree
`8197d2da82103320a8adb6bcd91e6b70b715dcb7`. These are local executions,
not the Hosted merge ref. Node v22.22.3, Vitest 4.1.5, linux/arm64 PG image
`sha256:a36250871de0833b8757561c72f2477ef1ddd1101afa4e617fb552e0de514c6b`.
Bootstrap LOGIN was `wiseeff`; heap 768 MB; one server test worker. Existing
per-test 30 seconds remained unchanged. The diagnostic process deadline was
120 seconds; termination never counts as success.

| Run | Result | Test/total time |
| --- | --- | --- |
| sensitiveNode identity candidate | 23 passed, 0 failed/skipped, exit 0 | 19.73 / 22.05 seconds |
| sensitiveNode identity base | 23 passed, 0 failed/skipped, exit 0 | 19.19 / 21.12 seconds |
| candidate independent first-case probe | one diagnostic assertion, exit 0; not part of 23 | 884.192 ms |
| base independent first-case probe | one diagnostic assertion, exit 0; not part of 23 | 904.916 ms |
| candidate runtimeState without receipt | beforeAll failure; 7 collected/skipped; exit 1 | 3 ms / 2.20 seconds |

Independent candidate probe: database creation/migrations 852.882 ms, seed
4.345 ms, actual resolver 1.393 ms, cleanup 25.572 ms. Base: 873.258, 4.583,
1.083 and 25.992 ms respectively. Probe seeding follows the first identity case,
using actual migrations, fixtures and resolver. It does not replace any test.

The runtimeState hook threw
`upgrade-tests-require-explicit-owned-postgres-receipt` with a real database
available, but without `UPG_TEST_TARGET_RECEIPT` or `TEST_DATABASE_URL`.
This confirms a distinct routing/admission failure; seven skipped cases are not
seven passes. It does not explain the unfinished sensitiveNode file in Hosted.

Neither standalone selector reproduced the Hosted batch stall. This does not
prove an inherited defect, a fix, or amd64 Hosted parity. The local shared
node_modules installation was reused; no base dependency installation was done.

## Reproduction scope

Keep these launchers beneath `<candidate checkout>/work/identity-diagnostic/`
so their imports resolve to the existing owned Docker guard and supervisor.
Arguments are an absolute clean checkout, its exact SHA, and the independently
verified development Docker daemon identity. Optional fourth argument is an
absolute `probe.ts` path or `runtime-state`. Never substitute a production
daemon. The launcher creates and deletes only its newly labelled resources.
It does not alter the checkout, test timeouts, migration ledger or product runner.

Logs in the delivery bundle remove workstation checkout paths and credentials.
Original private logs remain separately available to the parent coordinator.
All launcher/probe source is included; no connection string, password, backup,
database volume or private target receipt is included.
