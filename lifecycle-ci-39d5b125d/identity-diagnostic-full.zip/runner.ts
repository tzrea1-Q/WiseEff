import { spawn, spawnSync } from "node:child_process";
import { randomBytes } from "node:crypto";
import { mkdtemp, realpath, writeFile, rm } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { setTimeout as delay } from "node:timers/promises";
import { createIsolatedUpgradeDocker } from "../../scripts/isolated-upgrade-docker";
import { superviseComponentProcess } from "../../scripts/run-upgrade-component-tests";

// Diagnostic only: retained complete source. Never used as release approval.
const [cwd, expectedSha, expectedDaemon, probePath] = process.argv.slice(2);
const runtimeState = probePath === "runtime-state";
if (probePath && !runtimeState && !path.isAbsolute(probePath)) throw new Error("diagnostic-probe-path-required");
const git = (...args: string[]) => {
  const r = spawnSync("git", args, { cwd, encoding: "utf8" });
  if (r.status !== 0) throw new Error("diagnostic-source-unavailable");
  return r.stdout.trim();
};
if (!cwd || !path.isAbsolute(cwd) || git("rev-parse", "HEAD") !== expectedSha || git("status", "--porcelain")) throw new Error("diagnostic-clean-fixed-source-required");
const docker = createIsolatedUpgradeDocker();
if (docker.daemonId !== expectedDaemon) throw new Error("diagnostic-daemon-mismatch");
const run = `identity-${randomBytes(10).toString("hex")}`, label = "wiseeff.identity-diagnostic";
const privateRoot = await realpath(await mkdtemp(path.join(os.tmpdir(), "identity-private-")));
const password = randomBytes(24).toString("hex");
const image = JSON.parse(docker.command(["image", "inspect", "pgvector/pgvector:pg16"]).toString())[0];
const stamp = (phase: string, values: object = {}) => console.log(JSON.stringify({ phase, elapsedMs: Date.now()-started, ...values }));
const started = Date.now(); let network = "", volume = "", container = "", status = 1;
let supervisor: ReturnType<typeof superviseComponentProcess> | undefined;
const interrupt = () => supervisor?.stop();
process.on("SIGINT",interrupt); process.on("SIGTERM",interrupt);
try {
  network = docker.command(["network", "create", "--opt", "com.docker.network.bridge.enable_ip_masquerade=false", "--label", `${label}=${run}`, run]).toString().trim();
  volume = docker.command(["volume", "create", "--label", `${label}=${run}`, `${run}-data`]).toString().trim();
  const envFile = path.join(privateRoot,"postgres.env");
  await writeFile(envFile,`POSTGRES_USER=wiseeff\nPOSTGRES_DB=postgres\nPOSTGRES_PASSWORD=${password}\n`,{mode:0o600,flag:"wx"});
  container = docker.command(["run","-d","--network",network,"--label",`${label}=${run}`,"--mount",`type=volume,source=${volume},target=/var/lib/postgresql/data`,"--env-file",envFile,"-p","127.0.0.1::5432",image.Id]).toString().trim();
  let ready = false;
  for (let n=0;n<40;n++) {
    docker.assertOwned(container,label,run);
    try { docker.command(["exec",container,"pg_isready","-h","127.0.0.1","-U","wiseeff","-d","postgres"]);ready=true;break; }
    catch {await delay(100);}
  }
  if(!ready) throw new Error("diagnostic-postgres-unready");
  const observed = docker.assertOwned(container,label,run);
  const published = observed.NetworkSettings.Ports["5432/tcp"][0];
  if(published.HostIp!=="127.0.0.1") throw new Error("diagnostic-port-invalid");
  const url = `postgres://wiseeff:${password}@127.0.0.1:${published.HostPort}/postgres`;
  docker.command(["exec",container,"psql","-X","-v","ON_ERROR_STOP=1","-U","wiseeff","-d","postgres","-c","create extension vector"]);
  stamp("owned-postgres-ready",{sha:expectedSha,tree:git("rev-parse","HEAD^{tree}"),imageId:image.Id,platform:`${image.Os}/${image.Architecture}`,node:process.version,bootstrap:"wiseeff",heapMb:768,workers:1});
  const command = probePath && !runtimeState ? ["--import","tsx",probePath,cwd] : [path.join(cwd,"node_modules/vitest/vitest.mjs"),"run","--config","vitest.server.config.ts","--reporter=verbose","--disableConsoleIntercept",runtimeState ? "server/modules/catalog-cutover/runtimeState.test.ts" : "server/modules/parameter-kernel/sensitiveNode.identity.integration.test.ts"];
  const child = spawn(process.execPath,command,{
    cwd,env:{PATH:process.env.PATH,HOME:os.homedir(),TMPDIR:privateRoot,...(runtimeState ? {} : {TEST_DATABASE_URL:url}),DATABASE_URL:url,NODE_OPTIONS:"--max-old-space-size=768",VITEST_SERVER_MAX_WORKERS:"1"},stdio:["ignore","pipe","pipe"],detached:true,
  });
  stamp("vitest-started");
  supervisor=superviseComponentProcess(child,{deadlineMs:120000,graceMs:2000,outputBytes:8*1024*1024});
  const result=await supervisor.wait;status=result.exitCode;
  process.stdout.write(result.output.split(url).join("[REDACTED_TEST_URL]").split(password).join("[REDACTED]"));
  stamp("vitest-exited",{exitCode:status});
} catch {stamp("diagnostic-failed");status=1;}
finally {
  if(container){docker.assertOwned(container,label,run);docker.command(["rm","-f","-v",container]);}
  if(volume){const v=JSON.parse(docker.command(["volume","inspect",volume]).toString())[0];if(v.Labels?.[label]!==run)throw new Error("diagnostic-volume-owner-mismatch");docker.command(["volume","rm",volume]);}
  if(network){const n=JSON.parse(docker.command(["network","inspect",network]).toString())[0];if(n.Labels?.[label]!==run)throw new Error("diagnostic-network-owner-mismatch");docker.command(["network","rm",network]);}
  await rm(privateRoot,{recursive:true,force:true});
  process.off("SIGINT",interrupt);process.off("SIGTERM",interrupt);
  stamp("owned-cleanup-completed",{exitCode:status,cleanupVerified:true});
}
process.exitCode=status;
