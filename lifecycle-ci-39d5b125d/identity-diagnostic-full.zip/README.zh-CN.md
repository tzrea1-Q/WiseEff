# 有界 CI 诊断（不是产品修改）

英文：[English](README.md)

两次正式 selector 使用保留的 `runner.selector.ts`；后续 `runner.ts` 增加独立
计时探针及缺 receipt 的路由反例。五次运行分别拥有新的 PostgreSQL 集群、角色、
卷和网络，均已核验清理；没有生产访问。

实际本机候选为 `2ce71d683f1cd3e51b657f45aafaabc34d3dd5f2`，tree 为
`3dee59f518a8ce6f2a7894138f4b867a7c7a6244`。对照 base 为
`cda6737a8f177a8bbd2f3bc7d195f8e3037bfa74`，tree 为
`8197d2da82103320a8adb6bcd91e6b70b715dcb7`。不是 Hosted merge-ref 执行。
环境为 Node v22.22.3、Vitest 4.1.5、linux/arm64，PG 镜像 ID 为
`sha256:a36250871de0833b8757561c72f2477ef1ddd1101afa4e617fb552e0de514c6b`。
bootstrap 使用 wiseeff，heap 768 MB、一个 server worker；原每用例 30 秒不变。
诊断进程最多 120 秒，强制终止不计通过。

| 执行 | 结果 | 测试／总耗时 |
| --- | --- | --- |
| 候选 sensitiveNode identity | 23 通过、0 失败／跳过，exit 0 | 19.73／22.05 秒 |
| base 同 selector | 23 通过、0 失败／跳过，exit 0 | 19.19／21.12 秒 |
| 候选独立首例计时探针 | 单个诊断断言，exit 0，不计入 23 例 | 884.192 毫秒 |
| base 独立首例计时探针 | 单个诊断断言，exit 0，不计入 23 例 | 904.916 毫秒 |
| 候选 runtimeState 缺 receipt | beforeAll 失败、7 例收集后跳过，exit 1 | 3 毫秒／2.20 秒 |

独立候选探针：建库及迁移 852.882 毫秒、种子 4.345、真实 resolver 1.393、
清理 25.572。base 对应为 873.258、4.583、1.083、25.992 毫秒。
探针沿首例的 scope 种子使用真实迁移、fixture 和 resolver，不替代正式测试。

runtimeState 使用真实数据库及 DATABASE_URL，但没有 UPG_TEST_TARGET_RECEIPT
和 TEST_DATABASE_URL，hook 明确报
`upgrade-tests-require-explicit-owned-postgres-receipt`。这证明单独的路由／准入
失败；七项 skip 不是通过，也不能解释 Hosted sensitiveNode 文件未终结。

两次独立 selector 均未复现 Hosted 整批停滞，不能据此判为继承缺陷、已修复或
amd64 Hosted 等效。本机复用已有 node_modules，没有为 base 重新安装依赖。

## 使用范围

将完整 launcher 放在候选仓库 `work/identity-diagnostic/`，以复用仓库真实 Docker
隔离工具和进程监督器。参数为绝对干净 checkout、精确 SHA、独立确认的开发 daemon
身份；可选第四参数为绝对 probe.ts 路径或 `runtime-state`。禁止生产 daemon。
launcher 仅创建及清理自身标签绑定的新资源，不改 checkout、超时、ledger 或产品 runner。

交付包已去掉日志中的本机目录和凭据；原始私有日志独立交给父协调者。包内包含完整
launcher／probe，不含连接串、密码、业务备份、数据库卷或私有目标 receipt。
